好，本章我们继续探寻 SVG 的魅力！

在上一章节中，我们详述了 SVG 的线条动画，并且介绍了利用诸如 `stroke`、`stroke-dasharray` 等 CSS 样式去控制 SVG 元素的表现，找到了 **SVG 图形与 CSS 之间的桥梁。**

而在 SVG，除去矢量图形，勾勒曼妙线条外，还有一类非常强大的、CSS 难与之媲美的功能，那就是 **SVG 滤镜**。

在本章，我们将深入 SVG 滤镜世界，介绍 SVG 滤镜的种种强大之处，利用它们巧妙解决各种复杂难题。并且同样的，我们会介绍 SVG 滤镜与 CSS 之间的桥梁，使得我们可以快速在 CSS 中引入 SVG 滤镜效果。

初识 SVG 滤镜
---------

在小册的 10 - 13 章，我们用了 4 章去介绍 CSS 中的滤镜，滤镜整体给人的感觉就是神秘而又强大，能够实现非常多与元素色彩、变换相关的功能。

而在这些方面，SVG 滤镜无疑是更强者，**SVG 滤镜与** **CSS** **滤镜类似，是 SVG 中用于创建复杂效果的一种机制。很多人看到 SVG 滤镜复杂的语法容易心生退意。**

本文力图使用最简洁明了的方式让大家尽量弄懂 SVG 滤镜的使用方式。

> 当然，阅读本文，同样要求读者具备一定的 SVG 基础知识。

SVG 滤镜包括了如下这些种类：

    feBlend
    feColorMatrix
    feComponentTransfer
    feComposite
    feConvolveMatrix
    feDiffuseLighting
    feDisplacementMap
    feFlood
    feGaussianBlur
    feImage
    feMerge
    feMorphology
    feOffset
    feSpecularLighting
    feTile
    feTurbulence
    feDistantLight
    fePointLight
    feSpotLight
    

滤镜种类看上去非常丰富，有点类似于 CSS 滤镜中的不同功能：`blur()`、`contrast()`、`drop-shadow()` 。

简单来说，SVG 滤镜基本上能够实现 CSS 滤镜的所有功能，同时，它又具备一些 CSS 滤镜无法实现的能力，在本文中，我们会把更多的篇幅，用于讲解 SVG 滤镜中那些 CSS 滤镜无法实现的事情之上。

在深入 SVG 滤镜之前，我们快速通过一个 DEMO 来了解 SVG 滤镜。

创建并使用一个 SVG 滤镜的过程如下：

1.  定义一个 SVG 滤镜，需要使用 `<defs>` 和 `<filter>` 标签；通常而言，所有的 SVG 滤镜元素都需要定义在 `<defs>` 标记内。当然，对于现代浏览器，即使不使用 `<defs>` 包裹 `<filter>`，也能够定义一个 SVG 滤镜。这个 `<defs>` 标记是 definitions 这个单词的缩写，可以包含很多种其他标签，包括各种滤镜。
2.  其次，使用 `<filter>` 标记用来定义 SVG 滤镜。 `<filter>` 标签需要一个 id 属性，它是这个滤镜的标志。SVG 图形使用这个 id 来引用滤镜。
3.  在 `<filter>` 标签内，利用上面提到的 SVG 滤镜标签，书写实际的滤镜效果。
4.  在具体的 SVG 图形，或者 HTML 元素中使用该滤镜。

看一个最简单的 DEMO：

    <div class="cssFilter"></div>
    <div class="svgFilter"></div>
    <svg>
      <defs>
        <filter id="blur">
          <feGaussianBlur in="SourceGraphic" stdDeviation="5" />
        </filter>
      </defs>
    </svg>
    

    div {
        width: 100px;
        height: 100px;
        background: #000;
    }
    .cssblur {
        filter: blur(5px);
    }
    .svgFilter{
        filter: url(#blur);
    }
    

这里，我们在 `defs` 的 `filter` 标签内，运用了 SVG 的 `feGaussianBlur` 滤镜，也就是模糊滤镜， 该滤镜有两个属性 `in` 和 `stdDeviation`。其中 `in="SourceGraphic"` 属性指明了模糊效果要应用于整个图片，`stdDeviation` 属性定义了模糊的程度。最后，在 CSS 中，使用了 `filter: url(#blur)` 去调用 HTML 中定义的 id 为 `blur` 的滤镜。

为了方便理解，也使用 CSS 滤镜 `filter: blur(5px)` 实现了一个类似的滤镜，方便比较，结果图如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/10b8e0a2f347465ba628ba08b35008c0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=481&h=242&s=11130&e=png&b=fbfbfb)

> 完整的代码，你可以戳这里：[CodePen Demo - SVG 滤镜](https://codepen.io/Chokcoco/pen/poNqVzb "https://codepen.io/Chokcoco/pen/poNqVzb")

嘿，可以看到，使用 SVG 的模糊滤镜，实现了一个和 CSS 模糊滤镜一样的效果。

SVG 滤镜与 CSS 之间的桥梁
-----------------

那么，SVG 滤镜与 CSS 滤镜之间的桥梁是什么呢？

上文的例子中，在 CSS 代码里面使用了 `filter: url(#blur)` 这种模式引入了一个 SVG 滤镜效果，url 是 CSS 滤镜属性的关键字之一，`url` 模式是 CSS 滤镜提供的能力之一，允许我们引入特定的 SVG 过滤器，这极大地增强 CSS 中滤镜的能力。

    <svg>
      <defs>
        <filter id="blur">
          <feGaussianBlur in="SourceGraphic" stdDeviation="5" />
        </filter>
      </defs>
    </svg>
    
    // css
    .svgFilter{
        filter: url(#blur);
    }
    

**相当于所有通过** **SVG** **实现的滤镜效果，都可以快速地通过** **CSS** **滤镜** **URL** **模式一键引入。**

而这，就是 SVG 滤镜 CSS 之间的桥梁。

多个滤镜搭配工作
--------

和 CSS 滤镜一样，SVG 滤镜也是支持多个滤镜搭配混合使用的。

所以，我们经常能看到一个 `<filter>` 标签内有大量的代码。很容易就懵了~

再来看个简单的例子：

    <div></div>
    
    <svg>
        <defs>
            <!-- Filter declaration -->
            <filter id="MyFilter">
    
                <!-- offsetBlur -->
                <feGaussianBlur in="SourceAlpha" stdDeviation="5" result="blur" />
                <feOffset in="blur" dx="10" dy="10" result="offsetBlur" />
    
                <!-- merge SourceGraphic + offsetBlur -->
                <feMerge>
                    <feMergeNode in="offsetBlur" />
                    <feMergeNode in="SourceGraphic" />
                </feMerge>
            </filter>
        </defs>
    </svg>
    

    div {
        width: 200px;
        height: 200px;
        background: url(xxx);
        filter: url(#MyFilter);
    }
    

我们先来看看整个滤镜的最终结果，结果长这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b27d5829764e43e491539574ae5bc6f0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=196&h=189&s=54161&e=png&b=f9f3f2)

CSS 可能一行代码就能实现的事情，SVG 居然用了这么多代码。（当然，这里 CSS 也不好实现，不是简单容器的阴影，而是 PNG 图片图形的轮廓阴影。）

我们来分解一下上面的步骤，首先看这一段：

    <!-- offsetBlur -->
    <feGaussianBlur in="SourceAlpha" stdDeviation="5" result="blur" />
    <feOffset in="blur" dx="10" dy="10" result="offsetBlur" />
    

首先 `<feGaussianBlur in="SourceAlpha" stdDeviation="5" result="blur" />` 这一段，我们上面也讲到了，会生成一个模糊效果，这里多了一个新的属性 `result='blur'`，这个就是 SVG 的一个特性，不同滤镜作用的效果可以通过 `result` 产出一个中间结果（也称为 primitives 图元），其他滤镜可以使用 `in` 属性导入不同滤镜产出的 `result`，继续操作。

紧接着，`<feOffset>` 滤镜还是很好理解的，使用 `in` 拿到了上一步的结果 `result = 'blur'`，然后做了一个简单的位移。

这里就有一个非常重要的知识点：**在不同滤镜中利用** **`result`** **和** **`in`** **属性，可以实现在前一个基本变换操作上建立另一个操作**，比如我们的例子中就是添加模糊后又添加位移效果。

结合两个滤镜，产生的图形效果，其实是这样的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e16d7b20814e4c848a7c22ef7837dc6a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=166&h=170&s=17186&e=png&b=090909)

实际效果中还出现了原图，所以这里我们还使用了 `<feMerge>` 标签，合并了多个效果。也就是上述这段代码：

    <!-- merge SourceGraphic + offsetBlur --><feMerge><feMergeNode in="offsetBlur" />
        <feMergeNode in="SourceGraphic" />
    </feMerge>
    

`feMerge` 滤镜允许同时应用滤镜效果而不是按顺序应用滤镜效果。利用 `result` 存储别的滤镜的输出可以实现这一点，然后在一个 `<feMergeNode>` 子元素中访问它。

*   `<feMergeNode in="offsetBlur" />` 表示了上述两个滤镜的最终输出结果 `offsetBlur` ，也就是阴影的部分；
*   `<feMergeNode in="SourceGraphic" />` 中的 `in="SourceGraphic"` 关键词表示图形元素自身将作为 `<filter>` 原语的原始输入。

整体再遵循后输入的层级越高的原则，最终得到上述结果。示意流程图如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/07c908552aa24d65a4c84e0145f97905~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=346&h=622&s=90460&e=png&b=fefdfd)

至此，基本就掌握了 SVG 滤镜的工作原理，及多个滤镜如何搭配使用。接下来，只需要搞懂不同的滤镜能产生什么样的效果、有什么不同的属性，就能大致对 SVG 滤镜有个基本的掌握！

关于 SVG 滤镜还需要知道的
---------------

上面大致过了一下 SVG 滤镜的使用流程，下面再补充一下 SVG 滤镜标签特有的一些写法。

譬如，有一些元素属性是每一个滤镜都有，都可以进行设置的：

属性

作用

x, y

提供左上角的坐标来定义在哪里渲染滤镜效果。 （默认值：0）

width, height

绘制滤镜容器框的高宽（默认都为 100%）

result

用于定义一个滤镜效果的输出名字，以便将其用作另一个滤镜效果的输入（in）

in

指定滤镜效果的输入源，可以是某个滤镜导出的 result，也可以是下面 6 个值

SVG filter 中的 `in` 属性，指定滤镜效果的输入源，可以是某个滤镜导出的 `result`，也可以是下面 6 个值：

in 取值

作用

SourceGraphic

该关键词表示图形元素自身将作为 <filter> 原语的原始输入

SourceAlpha

该关键词表示图形元素自身将作为 <filter> 原语的原始输入。SourceAlpha 与 SourceGraphic 具有相同的规则除了 SourceAlpha 只使用元素的非透明部分

BackgroundImage

与 SourceGraphic 类似，但可在背景上使用。 需要显式设置

BackgroundAlpha

与 SourceAlpha 类似，但可在背景上使用。 需要显式设置

FillPaint

将其放置在无限平面上一样使用填充油漆

StrokePaint

将其放在无限平面上一样使用描边绘画

着重注意这两个 `SourceGraphic` 和 `SourceAlpha`，其核心就是，我们可以把某种滤镜的结果作为接下来效果的初始输入。其核心就在于能够让多个滤镜效果搭配实现，逐步地最终完成某一个效果。

接下来，我们就将进入最为核心的部分，一起看看，**利用** **SVG** **滤镜，可以实现哪些仅仅依靠** **CSS** **无法实现的效果**。

feMorphology 滤镜
---------------

feMorphology 为形态滤镜，它的输入源通常是图形的 alpha 通道，它的两个操作可以使源图形腐蚀（变薄）或扩张（加粗）。

使用属性 `operator` 确定是要腐蚀效果还是扩张效果。使用属性 `radius` 表示效果的程度，可以理解为笔触的大小。

*   operator：`erode` 腐蚀模式，`dilate` 为扩张模式，默认为 `erode`。
*   radius：笔触的大小，接受一个数字，表示该模式下的效果程度，默认为 0。

我们将这个滤镜简单地应用到文字上看看效果：

    <div class="g-text">
        <p>Normal Text</p>
        <p class="dilate">Normal Text</p>
        <p class="erode">Normal Text</p>
    </div>
    
    <svg width="0" height="0">
        <filter id="dilate">
            <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="3"></feMorphology>
        </filter>
        <filter id="erode">
            <feMorphology in="SourceAlpha" result="ERODE" operator="erode" radius="1"></feMorphology>
        </filter>
    </svg>
    

    p {
        font-size: 64px;
    }
    .dilate {
        filter: url(#dilate);
    }
    .erode {
        filter: url(#erode);
    }
    

效果如下：

![image.png](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/12727feb6dcf4c79b45bcc08ac87450e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.jpg#?w=1010&h=118&e=png&b=fdfdfd)

最左边的是正常文字，中间的是扩张的模式，右边的是腐蚀模式，看看效果，非常好理解。

当然，我们还可以将其运用在图片之上，这时，并非是简单地让图像的笔触变粗或者变细：

*   对于 `erode` 模式，会将图片的每一个像素向更暗更透明的方向变化；
*   而 `dilate` 模式，则是将每个向像素周围附近更亮更不透明的方向变化。

简单看个示例动画 DEMO，我们有两张图，分别作用 `operator="erode"` 和 `operator="dilate"`，并且动态地去改变它们的 `radius`，其中一个的代码示意如下：

    <svg width="450" height="300" viewBox="0 0 450 300">
        <filter id="morphology">
            <feMorphology operator="erode" radius="0">
                <animate attributeName="radius" from="0" to="5" dur="5s" repeatCount="indefinite" />
            </feMorphology>
        </filter>
    
        <image xlink:href="image.jpg" width="90%" height="90%" x="10" y="10" filter="url(#morphology)"></image>
    </svg>
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/03d37abb9fef41289d8f53d0e6787a40~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=742&h=283&s=663079&e=gif&f=7&b=ece2dd)

上图左边是扩张模式，右边是腐蚀模式，玩的代码及效果图，你可以戳这里：[CodePen Demo -- SVG feMorphology Animation](https://codepen.io/Chokcoco/pen/GRrKqPR "https://codepen.io/Chokcoco/pen/GRrKqPR") 。

### feMorphology 滤镜实战 —— 生成不规则元素的边框

那么，**feMorphology 滤镜在实战中能够做些什么呢？**

我们来看这么一个例子，在之前的 `drop-shadow` 章节，我们有提到，利用 `drop-shadow()`生成不规则图形的边框：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4391d65a1f004bbcb7996a347fa71b50~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=234&h=82&s=4394&e=png&b=f49416)

利用多重 `drop-shadow()` 勉强能实现上述效果，但是仔细看还是能看到阴影的痕迹。但是，利用 feMorphology 滤镜，则能够非常完美地解决这个问题。

利用 `feMorphology` 的扩张能力，也就是 `operator="dilate"` 模式，可以巧妙地给任意元素及形状，添加一层边框效果。大致步骤如下：

1.  提前准备好一个 `feMorphology` 滤镜效果，设置好扩张模式；
2.  将我们需要添加边框的元素，复制一个；
3.  将上述滤镜效果，添加给复制的图形，利用滤镜的扩张能力，让整个图形的轮廓变大一圈，并且，可以设置颜色；
4.  将两个图形叠加在一起，作用了滤镜的元素在下方，原本的元素在上方，组合在一起，就能够生成一个带边框的不规则图形了。

假设，我们有这么一个用 HTML + CSS 实现的箭头图形：

    <div class="arrow"></div>
    

    .arrow {
        position: relative;
        width: 180px;
        height: 64px;
    
        &::before {
            content: "";
            position: absolute;
            background: #f49714;
            clip-path: polygon(0 0, 80% 0, 100% 50%, 80% 100%, 0 100%);    
        }
    }
    

效果如下，利用 `clip-path` 可以得到一个简单的箭头图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c47f5b852cdd4efba106a5819c2129e0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=384&h=154&s=6694&e=png&b=e8973b)

该滤镜的简单代码如下：

    <svg width="0" height="0">
        <filter id="outline">
            <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="1"></feMorphology>
        </filter>
    </svg>
    

简单浅析一下这段 SVG 滤镜代码：

`<feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="1"></feMorphology>` 将原图的不透明部分作为输入，采用了 `dilate` 扩张模式且程度为 `radius="1"`，生成了一个比原图大 1px 的黑色图块。

我们再改造一下上面的 HTML 代码，生成两个一模一样的箭头图形，并且给其中一个添加上上述滤镜效果：

    <div class="g-container">
        <div class="arrow"></div>
        <div class="arrow arrow-copy"></div>
    </div>
    

    .arrow {
        position: relative;
        width: 180px;
        height: 64px;
        z-index: 2;
    
        &::before {
            content: "";
            position: absolute;
            background: #f49714;
            clip-path: polygon(0 0, 80% 0, 100% 50%, 80% 100%, 0 100%);    
        }
    }
    .arrow-copy {
        position: absolute;
        inset: 0;
        filter: url(#outline);
        z-index: 1;
    }
    

这样，我们就实现了一个完美的不规则图形的边框效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/46426dfc6e5d41958b4532e24e58d4b5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=234&h=82&s=4394&e=png&b=f49416)

当然，如果对 SVG 足够熟练，可以使用 `feMerge` 将黑色图块和原图叠加在一起，这样就无需多叠加一层原图效果。此时，完整的代码如下：

    <div class="arrow"></div>
    
    <svg>
        <filter id="outline">
            <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="1"></feMorphology>
    
             <feMerge>
                <feMergeNode in="DILATED" />
                <feMergeNode in="SourceGraphic" />
            </feMerge>
        </filter>
    </svg>
    

此时，CSS 中直接给 `.arrow` 元素添加一个 CSS filter `filter: url(#outline)` 即可，无需引入额外的元素：

    .arrow {
        position: relative;
        width: 180px;
        height: 64px;
        filter: url(#outline);
        &::before {
            content: "";
            position: absolute;
            inset: 2px;
            background: #f49714;
            clip-path: polygon(0 0, 80% 0, 100% 50%, 80% 100%, 0 100%);    
        }
    }
    

最终呈现的效果如下，和上述效果是一致的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b2038facb6cb42af9ef963317fec70e4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=234&h=82&s=1156&e=png&b=f49416)

> 完整的代码，你可以戳这里：[CodePen Demo -- transparent 配合 SVG feMorphology 滤镜生成不规则边框](https://codepen.io/Chokcoco/pen/ExOXZgE "https://codepen.io/Chokcoco/pen/ExOXZgE")

并且，可以通过控制滤镜中的 `radius="1"` 来控制边框的大小。再将上述滤镜运用在各种不规则图形下看看效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c3edc5f7cea84e06a7dc735e513e1859~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1288&h=81&s=6479&e=png&b=f49416)

效果还算可以，就是颜色是黑色的。如果我们希望边框的颜色是其他颜色，有没有办法呢？

通过 `feFlood` 和 `feComposite` 两个 SVG 滤镜，可以给生成的图块上不同的颜色，代码如下：

    <svg width="0" height="0">
        <filter id="outline">
            <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="1"></feMorphology>
    
            <feFlood flood-color="green" flood-opacity="1" result="flood"></feFlood>
            <feComposite in="flood" in2="DILATED" operator="in" result="OUTLINE"></feComposite>
    
            <feMerge>
                <feMergeNode in="OUTLINE" />
                <feMergeNode in="SourceGraphic" />
            </feMerge>
        </filter>
    </svg>
    

通过 `feFlood` 中的 `flood-color="green"`，即可控制生成的边框（图块）的颜色，这里设置为了绿色。应用到各个图形上的效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/249ec3c6a3b045a49c5090fa6dee3607~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1278&h=84&s=7530&e=png&b=f49416)

至此，我们实现了通过 SVG 滤镜实现对不规则图形添加不同颜色以及不同粗细的边框。

并且 SVG 滤镜可以非常简单地通过 CSS Filter 的 url 模式引入到各个不同的图形当中去，这一套方案的复用性是非常高的。

> 完整的 DEMO，你可以戳这里：[transparent 配合 SVG feMorphology 滤镜生成不规则边框](https://codepen.io/Chokcoco/pen/ExZPpQq "https://codepen.io/Chokcoco/pen/ExZPpQq")

### feMorphology 滤镜实战 —— 文字加粗

feMorphology 滤镜另外一个有意思的实用场景就是文字加粗，其实也非常好理解，想象一下，我们只需要把上面的不规则图形替换成文字即可。

> 是的，文字也可以理解为一种不规则图形。

譬如，我们有这么一段文字：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1f97bbe27ad64ff1abe69bde13ca14b9~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=528&h=138&s=18274&e=png&b=dd8e33)

想实现这样一种效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/72491ea9423142688754749df9b68325~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=556&h=158&s=27586&e=png&b=dd8e33)

我们可以利用 `-webkit-text-stroke` 给文字添加边框进行描边，但是文字本身会变细，像是这样：

    <p>にほんご</p>
    

    p {
        font-size: 120px;
        color: #e98b00;
        -webkit-text-stroke: 5px #f3e8c9;
     }
    

效果如下，字体的整体粗细，其实是没有变化的（因此不符合我们的需求）：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3b9b6cc9bd8843df9d529bf087663f3a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=528&h=130&s=32381&e=png&b=dd8e34)

此时，使用 `feMorphology` 滤镜就非常合适，它能够在原有粗细度之上，额外向外绘制新的边框内容。

代码也非常简单：

    <p>にほんご</p>
    
    <svg width="0" height="0">
        <filter id="outline">
            <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="10"></feMorphology>
    
            <feFlood flood-color="#f3e8c9" flood-opacity="1" result="flood"></feFlood>
            <feComposite in="flood" in2="DILATED" operator="in" result="OUTLINE"></feComposite>
    
            <feMerge>
                <feMergeNode in="OUTLINE" />
                <feMergeNode in="SourceGraphic" />
            </feMerge>
        </filter>
    </svg>
    

    div {
        position: relative;
        font-size: 120px;
        color: #e98b00;
        
        &::before {
            content: "にほんご";
            position: absolute;
            inset: 0;
            filter: url(#outline);
            z-index: 0;
        }
    }
    

这样，我们就能完美的实现文字的加粗效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/506e9ebe3fca4da59fb76863a93a4af3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=556&h=158&s=25461&e=png&b=dd8e33)

> 完整的代码，你可以戳这里：[CodePen Demo -- 文字超级加粗](https://codepen.io/Chokcoco/pen/WNYQVNO?editors=1100 "https://codepen.io/Chokcoco/pen/WNYQVNO?editors=1100")

feTurbulence 滤镜
---------------

turbulence 意为湍流，不稳定气流，而 SVG `<feTurbulence>` 滤镜能够实现半透明的烟熏或波状图像。 通常用于实现一些特殊的纹理。滤镜利用 Perlin 噪声函数创建了一个图像。噪声在模拟云雾效果时非常有用，能产生非常复杂的质感，利用它可以实现人造纹理比如说云纹、大理石纹的合成。

有了 `feTurbulence`，我们可以自使用 SVG 创建纹理图形作为置换图，而不需要借助外部图形的纹理效果，即可创建复杂的图形效果。

这个滤镜，我个人认为是 SVG 滤镜中最有意思的一个，因为它允许我们自己去创造出一些纹理，并且叠加在其他效果之上，生成出非常有意思的动效。

`feTurbulence` 有三个属性是我们特别需要注意的：**type**、**baseFrequency**、**numOctaves**。

*   type：实现的滤镜的类型，可选 **fractalNoise** 分形噪声，或者是 **turbulence** 湍流噪声。
    
    *   fractalNoise：分形噪声更加的平滑，它产生的噪声质感更接近云雾。
    *   turbulence：湍流噪声。
*   baseFrequency：表示噪声函数的基本频率的参数，频率越小，产生的图形越大，频率越大，产生的噪声越复杂，其图形也越小越精细，通常的取值范围在 0.02 ~ 0.2。
    
*   numOctaves：表示噪声函数的精细度，数值越高，产生的噪声更详细。默认值为 1。
    

这里有一个非常好的网站，用于示意 `feTurbulence` 所产生的两种噪声的效果：[apike.ca/ - feTurbul…](http://apike.ca/prog_svg_filter_feTurbulence.html "http://apike.ca/prog_svg_filter_feTurbulence.html") 。

两种噪声的代码基本一致，只是 `type` 类型不同：

    <filter id="fractal" >
      <feTurbulence id="fe-turb-fractal" type="fractalNoise" baseFrequency="0.00025" numOctaves="1"/>
    </filter>
    
    <filter id="turbu">
      <feTurbulence id="fe-turb-turbulence" type="turbulence" baseFrequency="0.00025" numOctaves="1"/>
    </filter>
    

我们通过改变 `baseFrequency` 和 `numOctaves` 参数看看实际产生的两种噪声的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/355e799461744575987c3e73875754bf~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=639&h=262&s=5079578&e=gif&f=139&b=f4f3f3)

同时，`baseFrequency` 允许我们传入两个值，我们可以只改变某一方向上的频率，具体的你可以戳这个 Demo 看看：[CodePen -- feTurbulence baseFrequency & numOctaves](https://codepen.io/Chokcoco/pen/wvgwjEr "https://codepen.io/Chokcoco/pen/wvgwjEr") 。

单单一个 `<feTurbulence>` 滤镜其实是比较难搞懂这滤镜想干什么的，需要将这个滤镜作为纹理或者输入，和其他滤镜一起搭配使用，实现一些效果，下面我们来看看。

### 使用 feTurbulence 滤镜实现文字流动的效果

首先，尝试将 `feTurbulence` 所产生的纹理和文字相结合。

简单的代码如下：

    <div>Coco</div>
    <div class="turbulence">Coco</div>
    
    <svg>
        <filter id="fractal" filterUnits="objectBoundingBox" x="0%" y="0%" width="100%" height="100%">
            <feTurbulence id="turbulence" type="fractalNoise" baseFrequency="0.03" numOctaves="1" />
            <feDisplacementMap in="SourceGraphic" scale="50"></feDisplacementMap>
        </filter>
    </svg>
    

左边是正常的效果，后边是应用了 `<feTurbulence>` 的效果，你可以试着点进 Demo，更改 `baseFrequency` 和 `numOctaves` 参数的大小，可以看到不同的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9771d188def84f6ca8bc75a6274ac950~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=751&h=149&s=18665&e=png&b=fefefe)

上面的 Demo 还用到了 `feDisplacementMap` 滤镜，也需要简单讲解下。

feDisplacementMap 为映射置换滤镜，想要用好这个滤镜不太容易，需要掌握非常多的关于 PhotoShop 纹理创建或者是图形色彩相关的知识。该滤镜用来自图像中从 in2 的输入值到空间的像素值置换图像从 in 输入值到空间的像素值。

说人话就是 `feDisplacementMap` 实际上是用于改变元素和图形的像素位置的。该滤镜通过遍历原图形的所有像素点，使用 `feDisplacementMap` 重新映射到一个新的位置，形成一个新的图形。

在上述的 `feTurbulence` 滤镜与文字的结合使用中，我们通过 `feTurbulence` 噪声得到了噪声图形，然后通过 `feDisplacementMap` 滤镜根据 `feTurbulence` 所产生的噪声图形进行形变，扭曲，液化，得到最终的效果。

在 [MDN](https://developer.mozilla.org/en-US/docs/Web/SVG/Element/feDisplacementMap "https://developer.mozilla.org/en-US/docs/Web/SVG/Element/feDisplacementMap") 上有这个滤镜转化的一个公式，感兴趣的可以研究下：

    P'(x,y) ← P( x + scale * (XC(x,y) - 0.5), y + scale * (YC(x,y) - 0.5))
    

当然，不了解上面的原理，其实不影响我们去使用它们。

上面让文字扭曲液态化的核心滤镜就是 `feTurbulence` 滤镜，此时，我们可以再动态地改变这个滤镜中的 `baseFrequency` 或者 `numOctaves` 参数，就可以实现动态效果。

我们再补充一段 JavaScript 代码：

    var filter = document.querySelector("#turbulence");
    var frames = 0;
    var rad = Math.PI / 180;
    
    function freqAnimation() {
      bfx = 0.03;
      bfy = 0.03;
      frames += 0.5;
      bfx += 0.01 * Math.cos(frames * rad);
      bfy += 0.01 * Math.sin(frames * rad);
    
      bf = bfx.toString() + ' ' + bfy.toString();
      filter.setAttributeNS(null, 'baseFrequency', bf);
      window.requestAnimationFrame(freqAnimation);
    }
    
    window.requestAnimationFrame(freqAnimation);
    

这段代码也非常好理解，其核心就是利用了 `requestAnimationFrame` API，每一帧动态设置 `#turbulence` 元素，也就是 `<feTurbulence>` 滤镜的 `baseFrequency` 参数，如此以一来，静态的效果就能神奇地动起来：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e5bbefb7c57e4a5c9b1c0f7722f57055~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=480&h=196&s=466123&e=gif&f=88&b=fcfbfe)

> 最终，完整的代码，你可以戳这里：[CodePen Demo -- feTurbulence text demo](https://codepen.io/Chokcoco/pen/dyNbedP "https://codepen.io/Chokcoco/pen/dyNbedP")

结束了吗？没有。我们再来尝试点有意思的事情。

如果尝试把上述 DEMO 中的文字转换成图片，会发生什么呢？

随便找一张静态的哭的表情包：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b7edde794114421d95db2c97cdff7000~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=200&h=199&s=59296&e=png&b=eff2e6)

简单改造下代码：

    <div></div>
    <svg>
        <filter id="fractal" filterUnits="objectBoundingBox" x="0%" y="0%" width="100%" height="100%">
            <feTurbulence id="turbulence" type="fractalNoise" baseFrequency="0.09" numOctaves="1" ></feTurbulence>
            <feDisplacementMap in="SourceGraphic" scale="15"></feDisplacementMap>
        </filter>
    </svg>
    

    div {
        background: url(image.jpg);
        filter: url(#fractal);
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d528a2ecc80e4c8c9f79cfdef5044833~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=212&h=211&s=73749&e=png&b=f5f5eb)

有点那个意思了，我们通过 `feTurbulence` 滤镜得到了噪声图形，然后通过 `feDisplacementMap` 滤镜根据 `feTurbulence` 所产生的噪声图形进行形变，扭曲，液化，得到最终的效果。

接下来，还是刚刚的技巧，利用 JavaScript 代码，动态地改变 `baseFrequency` 参数，**并且利用了三角函数，让整个动画是能够无限衔接循环的**：

    var filter = document.querySelector("#turbulence");
    var frames = 0;
    var rad = Math.PI / 180;
    
    function freqAnimation() {
      bfx = 0.05;
      bfy = 0.05;
      frames += 0.3;
      bfx += 0.02 * Math.cos(frames * rad);
      bfy += 0.05 * Math.sin(frames * rad);
    
      bf = bfx.toString() + ' ' + bfy.toString();
      filter.setAttributeNS(null, 'baseFrequency', bf);
      window.requestAnimationFrame(freqAnimation);
    }
    
    window.requestAnimationFrame(freqAnimation);
    

添加了动画之后，同样作用于图片之上，我们就可以得到如下的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/acc8b629e8d9425db3049adb2dbce50e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=230&h=209&s=514790&e=gif&f=48&b=f1f3e5)

由于截图软件的帧率问题，看着有点慢，你可以戳进 DEMO 看看实际效果，还是挺有意思的。至此我们就简单地利用 CSS 配合 SVG 的方式，通过一张静态图得到了一个动态的表情包啦。

> 完整代码，戳这里：[CodePen Demo -- 使用 SVG 滤镜 feTurbulence 让图片动起来](https://codepen.io/Chokcoco/pen/eYgJbmO "https://codepen.io/Chokcoco/pen/eYgJbmO")

### 使用 feTurbulence 滤镜实现褶皱纸张的纹理

好，我们继续 `feTurbulence` ，使用这个滤镜，我们可以生成各种不同的纹理，我们可以尝试使用 `feTurbulence` 滤镜搭配光照滤镜实现褶皱的纸张纹理效果，代码也非常少：

    <div></div>
    <svg>
        <filter id='roughpaper'>
            <feTurbulence type="fractalNoise" baseFrequency='0.04' result='noise' numOctaves="5" />
    
            <feDiffuseLighting in='noise' lighting-color='#fff' surfaceScale='2'>
                <feDistantLight azimuth='45' elevation='60' />
            </feDiffuseLighting>
        </filter>
    </svg>
    

    div {
        width: 650px;
        height: 500px;
        filter: url(#roughpaper);
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bebad0e686c34937b61f8ae5974c62e8~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=453&h=258&s=106071&e=png&b=ececec)

> 完整代码，戳这里：[CodePen Demo -- Rough Paper Texture with SVG Filters](https://codepen.io/Chokcoco/pen/OJWLXPY "https://codepen.io/Chokcoco/pen/OJWLXPY")

你可以在 [Sara Soueidan](https://www.sarasoueidan.com/ "https://www.sarasoueidan.com/") 的一次关于 SVG Filter 的分享上，找到制作它的教程：[Youtube -- SVG Filters Crash Course](https://www.youtube.com/watch?v=n7y0y_8zTo4 "https://www.youtube.com/watch?v=n7y0y_8zTo4") 。

### 使用 feTurbulence 滤镜实现按钮 hover 效果

使用 `feTurbulence` 滤镜搭配 `feDisplacementMap` 滤镜，还可以制作一些非常有意思的按钮效果。

尝试实现一些故障风格的按钮，其中一个按钮的代码如下：

    <div class="fe1">Button</div>
    <div class="fe2">Button</div>
    
    <svg>
        <defs>
            <filter id="fe1">
                <feTurbulence id="animation" type="fractalNoise" baseFrequency="0.00001 9.9999999" numOctaves="1" result="warp">
                    <animate attributeName="baseFrequency" from="0.00001 9.9999" to="0.00001 0.001" dur="2s" repeatCount="indefinite"/>
                </feTurbulence>
                <feOffset dx="-90" dy="-90" result="warpOffset"></feOffset>
                <feDisplacementMap xChannelSelector="R" yChannelSelector="G" scale="30" in="SourceGraphic" in2="warpOffset"></feDisplacementMap>
            </filter>
        </defs>
    </svg>
    

    .fe1 {
        width: 200px;
        height: 64px;
        outline: 200px solid transparent;
    }
    
    .fe1:hover {
        filter: url(#fe1);
    }
    

通过 hover 按钮的时候，给按钮添加滤镜效果，并且滤镜本身带有一个无限循环的动画：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/df7a60b10d134bf9ac224b160f5bad4b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=526&h=85&s=299663&e=gif&f=152&b=683bb6)

> 完整的代码你可以戳这里：[CodePen Demo - SVG Filter Button Effects](https://codepen.io/Chokcoco/pen/BapypJb "https://codepen.io/Chokcoco/pen/BapypJb")

feDisplacementMap 滤镜
--------------------

上面，我们有简单提到 `feDisplacementMap` 滤镜。

feDisplacementMap 为映射置换滤镜，想要用好这个滤镜不太容易，需要掌握非常多的关于 PhotoShop 纹理创建或者是图形色彩相关的知识。该滤镜用来自图像中从 in2 的输入值到空间的像素值置换图像从 in 输入值到空间的像素值。

说人话就是 `feDisplacementMap` 实际上是用于改变元素和图形的像素位置的。该滤镜通过遍历原图形的所有像素点，使用 `feDisplacementMap` 重新映射到一个新的位置，形成一个新的图形。

在上述的 `feTurbulence` 滤镜与文字的结合使用中，我们通过 `feTurbulence` 噪声得到了噪声图形，然后通过 `feDisplacementMap` 滤镜根据 `feTurbulence` 所产生的噪声图形进行形变，扭曲，液化，得到最终的效果。

而 `feDisplacementMap` 滤镜中的 `scale` 参数表示新得到的图像的扭曲程度，这个值越大，图像越加扭曲不可识别。

因此，有一个非常有意思的技巧，可以通过对 `scale` 设置一个非常大初始值，将输入的任何源图像粒子化。

看看这个 Demo：

    <div></div>
    <div class="fractal"></div>
    
    <svg viewBox="0 0 200 200" width="200px" height="200px">
      <defs>
        <filter id="fractal" filterUnits="userSpaceOnUse" x="0" y="0" width="200" height="200">
          <feTurbulence type="fractalNoise" baseFrequency="0.995" numOctaves="10" seed="1" stitchTiles="noStitch" result="img" />
          <feDisplacementMap in="SourceGraphic" in2="img" xChannelSelector="R" yChannelSelector="G" scale="600" />
        </filter>
      </defs>
    </svg>
    

    div {
        width: 200px;
        height: 200px;
        background: url(image.jpeg)
    }
    
    .fractal {
        filter: url(#fractal);
    }
    

左边为正常的图像，右边为作用了设置了 SVG 滤镜效果的图像，并且设置了 `scale="600"`，完全将图片粒子化了：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7c5ffc679cc2428f9d03afabf3da7328~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=560&h=217&s=164555&e=png&b=fbf9f7)

这个时候，让滤镜的 `scale="600"` 动态变化回 `scale="1"`（当此参数为 1 时，图像表示为正常状态），也就能实现一个图形从粒子化到正常化的转变：

    <svg viewBox="0 0 200 200" width="200px" height="200px">
        <filter id="fractal" filterUnits="userSpaceOnUse" x="0" y="0" width="200" height="200">
            <feTurbulence type="fractalNoise" baseFrequency="0.995" numOctaves="10" seed="1" result="img" />
            <feDisplacementMap in="SourceGraphic" in2="img" xChannelSelector="R" yChannelSelector="G" scale="600">
                <animate attributeName="scale" values="600;0;0" keyTimes="0;0.75;1" begin="0s" dur="2s" repeatCount="indefinite" />
            </feDisplacementMap>
        </filter>
    </svg>
    

> 上面运用了 SVG 的动画标签 `<animate>`，语法其实非常好理解，当然理解上存在困难的可能需要先自行学习一下。

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d7b3ee8416e74fe69951f289fa52b1cc~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=206&h=210&s=1615372&e=gif&f=49&b=eff9f5)

> [CodePen -- SVG Filter feTurbulence & feDisplacementMap 实现图片粒子化复原动画](https://codepen.io/Chokcoco/pen/OJWXjWz "https://codepen.io/Chokcoco/pen/OJWXjWz")

### 动态改变 `feDisplacementMap` 的 `scale` 的参数实现一些开奖动效

基于上述的效果，我们可以实现这样一类效果，譬如一些开奖结果，一开始它是模糊的，但是用户点击之后，模糊的结果逐渐从模糊到真实。

当然，这里可能需要借助一下 Javascript 代码，为了方便理解，使用 JQuery 简单做个示意。

假设，我们有一串开奖数组 `745846`，现在需要实现一个效果，能够做到实现点击之后元素从模糊动画过渡到实际清晰状态：

    <div id="fe1" class="fe1">745846</div>
    <svg>
        <filter id="feDisplacementMap" filterUnits="userSpaceOnUse" x="0" y="0" width="200" height="64">
            <feTurbulence type="fractalNoise" baseFrequency="0.0995" numOctaves="1" result="img" />
            <feDisplacementMap id="feDis" in="SourceGraphic" in2="img" scale="200" />
        </filter>
    </svg>
    

    $("#fe1").click((e) => {
      const filter = $("#feDis");
      const startTime = Date.now();
      const duration = 1000;
      const target = 200;
      
      requestAnimationFrame(function aniMove() {
          const t = Math.min(1, (Date.now() - startTime) / duration);
          const nextTarget = target - (t * target) + 1;
          
          filter.attr('scale', nextTarget);
    
          if (t < 1.0) {
              requestAnimationFrame(aniMove);
          }
      });
    });
    

点击之前的状态如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/95c36b945d0b44089895857e1504300e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=214&h=86&s=4132&e=png&b=ffffff)

点击之后：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/961b9804cc53471b98c56459adb38f9c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=217&h=85&s=142344&e=gif&f=79&b=ffffff)

是不是很有意思？运用 SVG 滤镜能够快速实现 CSS 无法实现的效果。并且，上述的代码片段，可以套用到任何地方。

> 完整的 Demo 地址，你可以戳这里：[CodePen Demo -- SVG Filter Button Effects](https://codepen.io/Chokcoco/pen/KKaMNZz "https://codepen.io/Chokcoco/pen/KKaMNZz")

总结一下
----

在这一章节中，我们揭开了 SVG 滤镜的神奇面纱。通过简单了解什么是 SVG 滤镜之后，我们开始了实际的对 SVG 滤镜效果的探索。

本章中的一些重点核心知识点，我们再回顾一下：

1.  SVG 滤镜与 CSS 之间的桥梁，**所有通过 SVG 实现的滤镜效果，都可以快速地通过 CSS 滤镜** **URL** **模式一键引入；**
2.  了解多个滤镜协同工作的模式；
3.  学习 **`feMorphology`** 滤镜，遇到文字加粗、图形加粗、多重边框的场景，可以考虑使用；
4.  学习 **`feTurbulence`** 滤镜，实际应用可能不算太多，适合制作一些特色动效及交互效果；
5.  学习 **`feDisplacementMap`** 滤镜，将元素粒子化的非 Canvas 手段，同样适合制作一些特色动效及交互效果。

当然，SVG 滤镜除此之外还有非常多有意思的功能，当我们遇到一些非 CSS 可以实现的效果，可以寻求 SVG 的解法。通过 SVG 与 CSS 之间的桥梁，在 CSS 中引入 SVG 滤镜、控制 SVG 属性都是可以做到的。

同时，同学们也不应该排斥抗拒去学习 SVG，SVG 上手并不困难。多掌握一门语言，在各种场景下都能都思考出一些解法。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
在上一章节中，我们深入到了动画 animation 属性的方方面面中，对 CSS animation 已经有了一个初步的认知。

本文，我们将继续拔高，学习 CSS 动画中更为核心的内容。

对于 animation 的具体应用，我们核心需要去掌握 3 个技巧：

1.  **分治**；
2.  **复用**；
3.  **合成**。

理解动画的分治与复用
----------

上一章讲完了每一个属性，我们再来看看一些动画使用过程中的细节。

看这样一个动画：

    <div></div>
    

    div {
        width: 100px;
        height: 100px;
        background: #000;
        animation: combine 2s;
    }
    @keyframes combine {
        100% {
            transform: translate(0, 150px);
            opacity: 0;
        }
    }
    

这里我们实现了一个 div 块下落动画，下落的同时产生透明度的变化：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0c7af2083ed74aa9a9fa51fd13f66f3d~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=150&h=289&s=38318&e=gif&f=72&b=fdfcfa)

对于这样一个多个属性变化的动画，它其实等价于：

    div {
        animation: falldown 2s, fadeIn 2s;
    }
    
    @keyframes falldown {
        100% {
            transform: translate(0, 150px);
        }
    }
    @keyframes fadeIn {
        100% {
            opacity: 0;
        }
    }
    

在 CSS 动画规则中，`animation` 是可以接收多个动画的规则定义的，像是这样：

    div {
        animation: 动画规则1, 动画规则2, 动画规则3, ...;
    }
    

这样做不仅仅只是为了**复用**，同时也是为了**分治**，我们对每一个属性层面的动画能够有着更为精确的控制。

利用 CSS 变量实现动画函数复用
-----------------

这里，还有一个非常重要的动画技巧，可以大幅度地提升单个动画的复用效率：**利用** **CSS** **变量实现动画函数复用**。

来看这么一个简单的例子，假设需要实现三个元素的位移动画，将元素从位置 A 移动到位置 B。三个元素的位置 A 相同，但是位置 B 不一样，如下所示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/978928da10e549efa90078151a84cb89~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=131&s=15974&e=gif&f=29&b=fdfcff)

正常而言，由于元素的动画，最终的终点不一样，我们可能需要实现 3 个不一样的 `@keyframes`，像是这样：

    <ul>
      <li></li>
      <li></li>
      <li></li>
    </ul>
    

    li:nth-child(1) {
        animation: move1 2s linear;
    }
    li:nth-child(2) {
        animation: move2 2s linear;
    }
    li:nth-child(3) {
        animation: move3 2s linear;
    }
    
    @keyframes move1 {
        60%,
        100% {
            transform: translate(150px);
        }
    }
    @keyframes move2 {
        60%,
        100% {
            transform: translate(120px);
        }
    }
    @keyframes move3 {
        60%,
        100% {
            transform: translate(200px);
        }
    }
    

但是，这里有一个非常致命的缺点。如果我们有 10 个类似的效果，就得创建 10 段 `@keyframes` 动画代码，如果是 100 段、1000 段呢？仅仅是因为一个参数不一样，需要重新定义整个动画 `@keyframes` 部分的代码。

因此在这里，我们可以利用 CSS 变量，让它变得更为简洁，我们改造一下 `@keyframes` 代码，将固定的位移值，变成一个变量：

    @keyframes move {
        60%,
        100% {
            transform: translate(var(--dis));
        }
    }
    

### 通过 CSS 代码进行 CSS 变量值的传递

由于 CSS 变量是存在作用域的，我们可以通过 CSS 变量的方式，给每一个 li 定义一个不同的 `--dis` 变量，像是这样：

    li:nth-child(1) {
        --dis: 150px;
    }
    li:nth-child(2) {
        --dis: 120px;
    }
    li:nth-child(3) {
        --dis: 200px;
    }
    

这样，虽然动画的结束点不一样，但是我们利用 CSS 变量，复用了同一个 `@keyframes` 函数：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4c6f6879fa2b4a79a9a10d6e6a8bb5f3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=131&s=15974&e=gif&f=29&b=fdfcff)

### 通过元素的 style 属性进行 CSS 变量值的传递

不仅如此，除了通过在 `<style>` 标签内，给不同的元素标签传入不同的自定义变量，另外一种方式是还可以通过元素的内联 style 属性传入自定义变量。

为此，再改造一下上述的 `@keyframes`相关的代码：

    @keyframes move {
        60%,
        100% {
            transform: translate(var(--end));
            background: var(--color);
        }
    }
    

如上所示，上面的 `@keyframes` 的代码中，我们定义了两处需要使用 CSS 变量的地方：

1.  `var(--end)` 控制位移距离；
2.  `var(--color)` 控制背景颜色变化。

这一次，可以直接通过 HTML 元素的内联 `style` 属性传递这两个 CSS 变量的值，像是这样：

    <ul>
        <li style="--end: 150px; --color: red;"></li>
        <li style="--end: 200px; --color: blue;"></li>
        <li style="--end: 120px; --color: green;"></li>
    </ul>
    

是的，每个 li 元素的 `@keyframes` 可以读取到每个 li 元素 HTML 代码中的 `style` 属性里定义的不一样的 CSS 变量。

这样，我们就可以得到如下效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2bbf361cc38d47b6bacdd41ff4bd2561~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=379&h=140&s=28435&e=gif&f=29&b=fdfcff)

> 完整的代码，可以戳这里：[CodePen Demo -- 巧用 CSS 变量，实现动画函数复用](https://codepen.io/Chokcoco/pen/poORNVx "https://codepen.io/Chokcoco/pen/poORNVx")

### 通过 JavaScript 改写 style 属性进行 CSS 变量值的传递

显而易见，通过内联 style 传递 CSS 变量的值的方式，是方便 JavaScript 与 CSS 进行更好的联动。

我们可以通过 JavaScript 计算、修改我们页面元素中的动画效果需要的值，实时进行修改传递。看一个最简单的 Demo：

    <div id="g-element"></div>
    

    #g-element {
        width: 100px;
        height: 100px;
        background: #000;
        border-radius: 50%;
        animation: move 1.2s linear infinite alternate;
    }
    
    @keyframes move {
        100% {
            transform: translate(var(--end));
            background: var(--color);
        }
    }
    

基于上面的代码，这一次，我们既不通过 CSS 传递，也不通过内联 style 传递变量，而是通过 JavaScript 传递 CSS 变量：

    const color = '#f00';
    const distance = "200px";
    
    document
        .querySelector('#g-element')
        .setAttribute('style', `--end: ${distance}; --color: ${color}`);
    

这样，`@keyframes move`动画一样可以读取到 `var(--end)` 和 `var(--color)` 的值。效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cbc1f137975a4bfd9477e48237608d87~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=110&s=70824&e=gif&f=47&b=fdfcfa)

总结一下，通过 CSS 自定义变量，我们能极大地提升对单个 `@keyframes` 动画的复用，而且可以选择通过内联标签的 style 属性以及 JavaScript 改写 style 属性等更高级的方式进行变量的传递！

基于 animation-composition，理解动画的合成
--------------------------------

其实，在上一章节中，我们少介绍了 CSS animation 家族中的这个属性 —— `animation-composition`。

这是一个非常新的属性，**动画合成属性**。从 Chrome 112 版本开始支持。

如果是顺序阅读小册的同学，试着回忆一下，我们在 mask 的章节中，其实有提到过一个 `mask-composite`，用于控制多个 mask 图层的合并规则。在这里，`animation-composition` 也类似，用于控制多个动画的合成规则。

它具体有什么取值及什么作用呢？我们一起来一探究竟。

### 作用于单一的动画规则的动画合成

当仅有单一动画的时候，有三种不同的取值：

    {
        /* Single animation */
        animation-composition: replace;
        animation-composition: add;
        animation-composition: accumulate;
    }
    

首先，假设我们的页面只有一个动画效果：

    <div class="normal"></div>
    <div class="composition"></div>
    

    .normal,
    .composition  {
        width: 100px;
        height: 100px;
        background: #000;
    }
    
    .normal {
        transform: translate(50px, 0);
        animation: move 2s infinite linear;
    }
    
    .composition {
        transform: translate(50px, 0);
        animation: move 2s infinite linear;
        animation-composition: replace;
    }
    
    @keyframes move {
        0% {
            transform: translate(100px, 0);
        }
        100% {
            transform: translate(200px, 0);
        }
    }
    

这里，我们的动画设置了元素的 `transform: translate(100px, 0)` 到 `transform: translate(200px, 0)` 的位移动画。

但是，需要注意，元素本身是设置了 `transform: translate(50px, 0)`。

我们给 `.composition` 设置 `animation-composition` 的值，两个动画如下：

1.  `animation-composition: replace` ，这里表示值替换，也是默认值，动画效果和不设置 `animation-composition` 是一样的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e7c1dae9cbed4a83bbe4ff94a8ede549~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=452&h=319&s=65605&e=gif&f=43&b=ffffff)

2.  `animation-composition: add`，这里表示值**追加**，因为元素本身有设置 `transform: translate(50px, 0)`，因此，关键帧中的 `0%` 和 `100%` 实际上都会先加上 `translate(50px, 0)`。
    
    *   `0%` 的关键帧值实际为：`transform: translate(50px, 0) translate(100px, 0)`。
    *   `100%` 的关键帧值实际为：`transform: translate(50px, 0) translate(200px, 0)`。

动画效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/81d12433bc1e4d2281b5a7e9949d3dd5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=452&h=319&s=85342&e=gif&f=44&b=ffffff)

3.  `animation-composition: accumulate`，这里表示值**累加，** 如果动画的 `@keyframes` 规则和元素本身设定值有重合部分，将会累加在一起，因此：
    
    *   `0%` 的关键帧值实际为：`transform: translate(150px, 0)`。
    *   `100%` 的关键帧值实际为：`transform: translate(250px, 0)`。

因此，动画效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/de2cd116d65448a48c8bf769c779cb03~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=452&h=319&s=85342&e=gif&f=44&b=ffffff)

在（3）这个例子中，`animation-composition: accumulate` 的表现和 `animation-composition: add` 是一致的。

但是，如果换成 `filter`，`filter: blur(5px) blur(10px)` 和 `filter: blur(15px)` 是不一致的。

注意区分 `animation-composition: accumulate` 和 `animation-composition: add` 的异同。

### 作用于多动画规则的动画合成

上面是单个动画动作下，`animation-composition` 的用法。

上面我们也提及了，同一个元素是完全可能设置了多个子动画的，此时，如果给单个元素的多个动画效果应用上动画合成，又会发生些什么呢？

我们来看一个最经典的例子，利用 CSS 实现一个抛物线效果，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c6204fe6b1214c449716e0b6f7086c81~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=310&s=10991&e=gif&f=52&b=fdfcff)

拆解一下这个动画，它是由：

1.  一个水平向右的位移动画，速度为匀速；
2.  一个垂直向下的位移动画，速度为逐渐加速。

用 CSS 大致模拟：

    <div class="container">
        <div class="x"></div>
    </div> 
    <div class="container">
        <div class="y"></div>
    </div> 
    

    .container .x {
        animation: translateX 3s infinite linear;
    }
    .container .y {
        animation: translateY 3s infinite cubic-bezier(.55, 0, .9, .4);
    }
    
    @keyframes translateX {
        0%,
        20% {
            transform: translateX(0);
        }
        80%,
        100% {
            transform: translateX(280px);
        }
    }
    
    @keyframes translateY {
        0%,
        20% {
            transform: translateY(0);
        }
        80%,
        100% {
            transform: translateY(280px);
        }
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/286afd0b84f5401e8420f45184e2ff86~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=750&h=337&s=43890&e=gif&f=79&b=fdfcf9)

好，接下来，尝试把两个动画合在一个元素上：

    <div></div>
    

    div {
        animation: 
            translateX 3s infinite linear,
            translateY 3s infinite cubic-bezier(.55, 0, .9, .4);
    }
    

预想中的抛物线动画，并没有出现，只有单个的向下动画：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c5abdd79c6134b6e9b2b2b8a2c374ece~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=341&s=27775&e=gif&f=84&b=fdfcff)

究其原因，在于后定义的 `translateY 3s infinite cubic-bezier(.55, 0, .9, .4)` 的垂直方向的动画效果 `transform: translateY(280px)` 的效果覆盖了在之前定义的 `transform: translateX(280px)` 动画效果。

传统的解决方案，我们会使用多层嵌套的结构把其中一个方向的动画移植到另外一个层叠的元素之上，譬如这样：

    <div class="g-father">
        <div class="g-child"></div>
    </div>
    

    .g-father {
        animation: translateX 3s infinite linear;
    }
    .g-child {
        animation: translateY 3s infinite cubic-bezier(.55, 0, .9, .4);
    }
    // ...
    

而 `animation-composition`，正是为了解决这种问题而诞生的。基于上面的代码，我们只需要再多设置一个 `animation-composition: accumulate` 即可：

    div {
        animation: 
            translateX 3s infinite linear,
            translateY 3s infinite cubic-bezier(.55, 0, .9, .4);
        animation-composition: accumulate;
    }
    

此时，我们就能通过一个元素，得到两个方向位移动画的合成效果，也就是我们想要的抛物线效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9ec9c059586e432fbc26ea1854810398~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=750&h=343&s=54133&e=gif&f=86&b=fdfdf7)

注意看右边的效果，就是应用了 `animation-composition: accumulate` 的效果。

> 完整的 Demo 代码，你可以戳这里：[CodePen Demo -- animation-composition Demo](https://codepen.io/Chokcoco/pen/RweYzeQ "https://codepen.io/Chokcoco/pen/RweYzeQ")

### 注意 animation-composition 的兼容问题

当然，在使用 `animation-composition` 的时候，一定要注意它的兼容问题。

截止至本文写作的今天（2023-05-18），CanIUse 的数据如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/67b5ec5274e64c78b3f4666bf0e019b3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=2722&h=1186&s=312851&e=png&b=e7dabf)

想要大范围大面积使用，还需要静待一段时间。

总结一下
----

本章的核心，在于动画的分治、复用与合成。

我们在实际使用 CSS Animation 的时候，一定要时刻牢记上述的 3 个技巧。它们能够很好地帮助我们拆分动画、尽可能地复用相同部分的代码，有效提升效率。

一些重点摘要：

1.  对复杂动画做拆分，通过多个子动画的方式实现动画效果的分治与复用。
    
2.  利用 CSS 自定义变量复用单个动画效果，并且需要知道 3 种 CSS 变量传值的方式。
    
    *   通过 CSS 代码进行 CSS 变量值的传递；
    *   通过元素的 style 属性进行 CSS 变量值的传递；
    *   通过 JavaScript 改写 style 属性进行 CSS 变量值的传递。
3.  部分利用了多个同类属性进行动画的场景，可以考虑使用 `animation-composition` 进行动画效果的合成。
    

当然，这两章关于动画的介绍，我们并没有很多复杂 CSS 动画的实际演示，这是因为动画贯穿了整本小册，贯穿了每个属性，这两章更多的是给大家打下坚实的理论基础，在其他章节，我们都会频繁地使用 CSS 动画。在读完这两章关于动画的解读后，可以回过头再去看看之前章节中的 CSS 动画效果，看看能否有更进一步的理解。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
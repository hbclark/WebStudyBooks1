对于 CSS 自定义属性（CSS 变量）相关的内容，我们的学习路径将会是：

1.  理解 CSS 变量最基础的内容，学会使用 CSS 变量，理解其设计理念，并且逐步掌握一些变量使用的高级技巧；
2.  基于 CSS 变量，学习 CSS @property，理解其对整体 CSS 功能（CSS 动画）带来的革命性提升，掌握多种实战技巧；
3.  最后，进阶学习 **CSS** **Houdini 之 CSS Paint** **API，** 掌握强大的 CSS 绘图技巧。

而本文，我们将衔接上章的内容，将重点放在第 3 点之上，重点讲解 **CSS Houdini 之 CSS Paint API**。

在[上一篇文章 《从 CSS 变量到 CSS @property，突破传统 CSS 限制》](https://juejin.cn/book/7052964245259943948/section/7053292706969157664 "https://juejin.cn/book/7052964245259943948/section/7053292706969157664")中的最后，我们借助 CSS **@property** 成功实现了这样一种图片渐变消失的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0b36c66805d64754b766cddcf9b6e51c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=378&h=308&s=1471937&e=gif&f=92&b=f0e9e8)

> 完整代码，戳这里：[CodePen Demo -- 基于 @property 和 mask 的文本渐隐消失术](https://codepen.io/Chokcoco/pen/qBKPgZY "https://codepen.io/Chokcoco/pen/qBKPgZY")

但是，这个效果的缺陷也非常明显，虽然借助 SCSS 简化了非常多的代码，但是，如果我们查看编译后的 CSS 文件，会发现，在 SCSS 代码只有 80 行代码的情况下，编译后的整个 CSS 文件行数高达 2400+ 行，实在是太夸张了。

看看整个 CSS 文件编译后的截图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6aa4a8ec0cab42b88fb57d2052e34084~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=255&h=330&s=19452&e=png&b=1c1e1e)

文件行数如此之多，这是因为我们利用原生的 CSS 去控制 400 个小块的透明度动画，控制了 400 个 CSS 变量！

是的，任何代码乘以 400，数量级都会变得非常大。而这，也引出了本章，我们将继续给大家介绍的超强功能 —— **CSS** **Paint** **API**。

CSS Houdini 中的 CSS Paint API
----------------------------

什么是 CSS Houdini？什么又是 CSS Paint API？

> Houdini 是一组底层 API，它们公开了 CSS 引擎的各个部分，从而使开发人员能够通过加入浏览器渲染引擎的样式和布局过程来扩展 CSS。Houdini 是一组 API，它们使开发人员可以直接访问 [CSS 对象模型](https://developer.mozilla.org/zh-CN/docs/Web/API/CSS_Object_Model "https://developer.mozilla.org/zh-CN/docs/Web/API/CSS_Object_Model")（CSSOM），使开发人员可以编写浏览器可以解析为 CSS 的代码，从而创建新的 CSS 功能，而无需等待它们在浏览器中本地实现。

而 CSS Paint API 是 W3C 规范之一，目前的版本是 [CSS Painting API Level 1](https://drafts.css-houdini.org/css-paint-api/#paintworkletglobalscope "https://drafts.css-houdini.org/css-paint-api/#paintworkletglobalscope")。它也被称为 CSS Custom Paint 或者 Houdini's Paint Worklet。

CSS Paint API 允许开发人员通过 JavaScript 来编写自定义的绘图代码，在运行时将这些代码应用到元素的背景、边框、阴影等视觉效果上，从而可以创建出更加自由、独特和复杂的 CSS 样式。使用 CSS Paint API 编写的样式可以与现有的 CSS 规则完美地结合使用，而无需任何额外的 DOM 操作或 JavaScript 代码。

CSS Paint API 的优缺点都非常明显。

优点：

1.  更广泛的样式定制：CSS Paint API 提供了一种灵活的方式，使得开发人员可以轻松地实现更加自由、个性化的样式效果，从而增强用户体验和页面吸引力。
2.  更高的可复用性：使用 CSS Paint API 编写的样式可以与现有的 CSS 规则完美地结合使用，而无需任何额外的 DOM 操作或 JavaScript 代码。这样可以大大提高样式的可复用性和维护性。
3.  更好的性能：CSS Paint API 是在渲染引擎内部进行的，因此性能比 JavaScript 等其他方法更高效。

缺点：

1.  浏览器兼容性：目前，CSS Paint API 还处于实验阶段，仅部分浏览器支持（如 Chrome、Firefox），在某些版本中可能存在性能问题或不兼容的情况。
2.  学习成本高：使用 CSS Paint API 需要一定的 JavaScript 编程能力和对渲染引擎的了解，因此对于一些入门开发人员来说，学习成本可能比较高。

上面说了一堆理论性的东西，可能会让很多同学看的一头雾水，别急，我们通过一个例子，快速入门 CSS Paint API。

一个最简单的 CSS Paint API 的例子
------------------------

[CSS Houdini](https://developer.mozilla.org/zh-CN/docs/Web/Guide/Houdini "https://developer.mozilla.org/zh-CN/docs/Web/Guide/Houdini") 的一个特性就是 [Worklet (en-US)](https://developer.mozilla.org/en-US/docs/Web/API/Worklet "https://developer.mozilla.org/en-US/docs/Web/API/Worklet")。在它的帮助下，我们可以通过引入一行 JavaScript 代码来引入配置化的组件，从而创建模块式的 CSS。不依赖任何前置处理器、后置处理器或者 JavaScript 框架。

下面是一个最简单的 **CSS** **Paint** **API** **的**例子。

HTML 部分：

    <div style="--color: red"></div>
    <div style="--color: blue"></div>
    <div style="--color: yellow"></div>
    
    <script>
      if (CSS.paintWorklet) {              
        CSS.paintWorklet.addModule('/CSSHoudini.js');
      }
    </script>
    

CSS 部分：

    div {
        margin: auto;
        width: 100px;
        height: 100px;
        background: paint(drawBg);
    }
    

没错，**CSS** **Paint** **API** **的核心其实是** **JavaScript** **代码，通过 JavaScript 代码，定义 CSS 的样式表现:**

    // 这个文件的名字为 CSSHoudini.js
    // 对应上面 HTML 代码中的 CSS.paintWorklet.addModule('/CSSHoudini.js')
    registerPaint('drawBg', class {
      
       static get inputProperties() {return ['--color']}
       
       paint(ctx, size, properties) {
           const c = properties.get('--color');
          
           ctx.fillStyle = c;
           ctx.fillRect(0, 0, size.width, size.height);
       }
    });
    

先看看最终的结果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bb6136bf43d4418f90d40c17b1cdcf77~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=512&h=120&s=1990&e=png&b=ffffff)

看似有点点复杂，其实非常好理解。仔细看我们的 CSS 代码，在 `background` 赋值的过程中，没有直接写具体颜色，而是借助了一个自定义了 CSS Houdini 函数，实现了一个名为 `drawBg` 的方法，从而实现的给 Div 上色。

registerPaint 是以 worker 的形式工作，具体有几个步骤：

1.  建立一个 CSSHoudini.js 的文件，如果我们想用 CSS Painting API，必须要在这个 JS 文件中进行模块注册 `registerPaint('drawBg', class{ /.../ })`，这个 class 是一个类，下面会具体讲到。
2.  我们需要在 HTML 中引入 CSS.paintWorklet.addModule('CSSHoudini.js')，这里的 `CSSHoudini.js` 就是我们刚刚定义的 JavaScript 文件的文件名，当然命名本身没有特定的要求，叫什么都可以。
3.  这样，我们就成功注册了一个名为 `drawBg` 的自定义 Houdini 方法，现在，可以用它来扩展 CSS 的功能。
4.  在 CSS 中使用，就像代码中示意的那样 `background: paint(drawBg)`。
5.  接下来，就是具体的 registerPaint 实现的 drawBg 内部的代码。

上面的步骤搞明白后，核心的逻辑，都在我们自定义的 drawBg 这个方法后面定义的 class 里面。CSS Painting API 非常类似于 Canvas，这里面的核心逻辑就是：

1.  可以通过 `static get inputProperties() {}` 拿到各种从 CSS 传递进来的 CSS 变量；
2.  通过一套类似 Canvas 的 API 完成整个图片的绘制工作。

而我们上面 Demo 做的事情也是如此，获取到 CSS 传递进来的 CSS 变量的值。然后，通过 `ctx.fillStyle` 和 `ctx.fillRect` 完成整个背景色的绘制。

注意，掌握 CSS Paint API 的核心就在于，我们需要在上面说的 `registerPaint` 中的 `class{/.../}` 内，通过 JavaScript 代码，类似于 Canvas 画布般，实现整个效果。

通过稍显复杂的 CSS Paint API 例子进一步理解它
------------------------------

OK，接下来，我们通过一个稍微更复杂点的例子，加深对 CSS Paint API 的理解。

我们会利用 CSS Paint API 实现一个 `circleBgSet` 自定义方法，能够绘制出如下的背景图案：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5d570b508d854d339cd0e92ca0f5221b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1272&h=398&s=164494&e=png&b=ee471d)

看着好像很复杂，实则并不难。我一步一步讲解。

1.  定义好写 CSS Paint API 代码的结构，需要在 HTML 中，利用 `CSS.paintWorklet.addModule('')` 注册引入响应的 JavaScript 文件。代码如下：

    <div style=""></div>
    
    <script>
      if (CSS.paintWorklet) {              
         CSS.paintWorklet.addModule('/CSSHoudini.js'');
      }
    </script>
    

2.  在 CSS 代码内部，只需要在实际调用 background 属性的时候，传入我们即将要实现的 `circleBgSet` 方法：

    div {
        --gap: 3;
        --color: #f1521f;
        --size: 64;
        width: 100vw;
        height: 1000vh;
        background: paint(circleBgSet);
    }
    

核心就在于 `background: paint(circleBgSet)`，我们将绘制背景的工作，交给接下来我们要实现的 circleBgSet 方法。

同时，这里定义了 3 个 CSS 变量，它们的作用分别是：

*   `--gap`：表示圆点背景的间隙；
*   `-color`：表示圆点的颜色；
*   `--size`：表示圆点的最大尺寸。

3.  接下来，只需要在对应的 JavaScript 文件中（注意，文件名必须是上面 HTML 文件中注册的），利用 CSS Painting API 实现 `circleBgSet` 方法即可。完整的 JavaScript 代码如下：

    // 这个文件的名字为 CSSHoudini.js
    registerPaint(
        "circleBgSet",
        class {
            static get inputProperties() {
                return [
                    "--gap", 
                    "--color",
                    "--size"
                ];
            }
    
            paint(ctx, size, properties) {
                const gap = properties.get("--gap");
                const color = properties.get("--color");
                const eachSize = properties.get("--size");
                const halfSize = eachSize / 2;
                
                const n = size.width / eachSize;
                const m = size.height / eachSize;
                
                ctx.fillStyle = color;
               
                for (var i = 0; i < n + 1; i++) {
                    for (var j = 0; j < m + 1; j++) {
                        
                        let x = i * eachSize + ( j % 2 === 0 ? halfSize : 0);
                        let y = j * eachSize / gap;
                        let radius = i * 0.85;
                        
                        ctx.beginPath();
                        ctx.arc(x, y, radius, 0, 2 * Math.PI);
                        ctx.fill();
                    }
                }
            }
        }
    );
    

代码其实也不多，并且核心的代码非常好理解。这里，我们再简单解释下：

1.  `static get inputProperties() {}`，我们在 CSS 代码中定义了一些 CSS 变量，而需要取到这些变量的话，需要利用到这个方法。它使我们能够访问所有 CSS 自定义属性和它们设置的值。
    
2.  `paint(ctx, size, properties) {}` 核心绘画的方法，其中 ctx 类似于 Canvas 2D 画布的 ctx 上下文对象，size 表示 PaintSize 对象，可以拿到对于元素的高宽值，而 properties 则是表示 StylePropertyMapReadOnly 对象，可以拿到 CSS 变量相关的信息。
    
3.  最终，仔细看看我们的 `paint()` 方法，核心做的就是拿到 CSS 变量后，基于双重循环，把我们要的图案绘制在画布上。这里核心就是调用了下述 4 个方法，对 Canvas 了解的同学不难发现，这里的 API 和 Canvas 是一模一样的。
    
    *   `ctx.fillStyle = color`
    *   `ctx.beginPath()`
    *   `ctx.arc(x, y, radius, 0, 2 * Math.PI)`
    *   `ctx.fill()`

这里，其实 CSS Houdini 的画布 API 与 Canvas API 的是一样的，具体存在这样一些映射，我们在官方规范 [CSS Painting API Level 1 - The 2D rendering context](https://drafts.css-houdini.org/css-paint-api/#paintworkletglobalscope "https://drafts.css-houdini.org/css-paint-api/#paintworkletglobalscope") 可以查到：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b3a439ecd3a9426ca41509da4f56c2fc~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=816&h=453&s=120185&e=png&b=d9f6fd)

还记得我们上面传入了 3 个 CSS 变量吗？这里我们只需要简单改变上面的 3 个变量，就可以得到不一样的图形。让我们试一试：

    div {
        width: 100vw;
        height: 1000vh;
        background: paint(circleBgSet);
        // --gap: 3;
        // --color: #f1521f;
        // --size: 64;
        --gap: 6;
        --color: #ffcc00;
        --size: 75;
    }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2af41b7c79a241d8a00c6245016545b8~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1454&h=374&s=141103&e=png&b=000000)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS Hudini Example - Background Circle](https://codepen.io/Chokcoco/pen/abKExxN "https://codepen.io/Chokcoco/pen/abKExxN")

Get 到 CSS Paint API 的神奇了吗？**它的本质就是将绘图的能力从 CSS 转移到了** **JavaScript** **，以一种类似于 Canvas 画布能力实现图形的绘制！**

接下来，一起看看 **CSS** **Paint** **API** 的一些实用场景。

利用 CSS Paint API 实现自定义 mask，完成酷炫的交互效果
-------------------------------------

还记得本文一开始的引子吗？在上一章节中的例子：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fc0007d852e24558baece38b391e809c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=378&h=308&s=148906&e=png&b=f0e9e8)

接下来，我们尝试利用 CSS Paint API 自定义方法还原实现这个效果，简化 CSS 的代码量。

自定义的 CSS Paint API 方法，不仅仅可以用于 background，你想得到的地方，其实都可以。因此在这个效果中，我们将利用 CSS Houdini 的 registerPaint 实现自定义的 mask 属性绘制。

首先，还是一样，HTML 中需要引入一下定义了 registerPaint 方法的 JavaScript 文件：

    <div></div>
    
    <script>
      if (CSS.paintWorklet) {              
        CSS.paintWorklet.addModule('/CSSHoudini.js');
      }
    </script>
    

首先，我们会实现一张简单的图片：

    div {
        width: 300px;
        height: 300px;
        background: url(image.jpg);
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9877ec0bdc1c4724baed6cef46d9ad1e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=309&h=306&s=186348&e=png&b=195578)

当然，我们的目标是利用 registerPaint 实现自定义 mask，那么需要添加一些 CSS 代码：

    div {
        width: 300px;
        height: 300px;
        background: url(image.jpg);
        mask: paint(maskSet);
        --size-m: 10;
        --size-n: 10;
    }
    

这里，`mask: paint(fragmentation)` 表示使用我们自定义的 `maskSet` 方法。

在这里，我们引入了两个 CSS 自定义变量 `--size-m` 和 `--size-n`，简单解释一下：

1.  `--size-m` 表示我们即将要用 mask 属性分隔图片的行数；
2.  `--size-n` 表示我们即将要用 mask 属性分隔图片的列数。

接下来，就是具体实现新的自定义 mask 方法。

当然，这里我们只是重新实现一个 mask，而 mask 属性本身的特性，透明的地方背后的内容将会透明这个特性是不会改变的。JavaScript 代码：

    // 这个文件的名字为 CSSHoudini.js
    registerPaint(
        "maskSet",
        class {
            static get inputProperties() {
                return ["--size-n", "--size-m"];
            }
    
            paint(ctx, size, properties) {
                const n = properties.get("--size-n");
                const m = properties.get("--size-m");
                const width = size.width / n;
                const height = size.height / m;
    
                for (var i = 0; i < n; i++) {
                    for (var j = 0; j < m; j++) {
                        ctx.fillStyle = "rgba(0,0,0," + Math.random() + ")";
                        ctx.fillRect(i * width, j * height, width, height);
                    }
                }
            }
        }
    );
    

这一段代码非常好理解，我们做的事情就是拿到两个 CSS 自定义变量 `--size-n` 和 `--size-m` 后，通过一个双循环，依次绘制正方形填满整个 div 区域。

通过 `ctx.fillStyle = "rgba(0,0,0," + Math.random() + ")"` 这段代码，每个小正方形的颜色为带随机透明度的黑色。

> mask 的核心在于，透过颜色的透明度来隐藏一个元素的部分或者全部可见区域。

因此，整个图片将变成这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9d6c29925460492f9e8ee1761d2c950a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=314&h=312&s=163873&e=png&b=c5d1d8)

当然，我们这个自定义 mask 方法也是可以用于 background 的，如果我们把这个方法作用于 background，你会更好理解一点。

    div {
        width: 300px;
        height: 300px;
        background: paint(maskSet);
        // mask: paint(maskSet);
        --size-m: 10;
        --size-n: 10;
    }
    

实际的图片效果是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/21611f3ac6664075abe1069d60616adc~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=322&h=315&s=4272&e=png&b=e0e0e0)

好，回归正题，我们继续。我们最终的效果还是要动画效果，Hover 的时候让图片方块化消失，肯定还是要和 CSS **@property** 自定义变量发生关联的。我们简单改造下代码，加入一个 CSS **@property** 自定义变量：

    @property --transition-time {
      syntax: '<number>';
      inherits: false;
      initial-value: 1;
    }
    
    div {
        width: 300px;
        height: 300px;
        background: url(https://tvax4.sinaimg.cn/large/6f8a2832gy1g8npte0txnj21jk13a4qr.jpg);
        mask: paint(fragmentation);
        --size-m: 10;
        --size-n: 10;
        --transition-time: 1;
        transition: --transition-time 1s linear;
    }
    
    div:hover {
      --transition-time: 0;
    }
    

这里，我们引入了 `--transition-time` 这个变量。接下来，让它在 `maskSet` 函数中，发挥作用：

    registerPaint(
        "maskSet",class {
            static get inputProperties() {
                return ["--size-n", "--size-m", "--transition-time"];
            }
    
            paint(ctx, size, properties) {
                const n = properties.get("--size-n");
                const m = properties.get("--size-m");
                const t = properties.get("--transition-time");
                const width = size.width / n;
                const height = size.height / m;
    
                for (var i = 0; i < n; i++) {
                    for (var j = 0; j < m; j++) {
                        ctx.fillStyle = "rgba(0,0,0," + (t * (Math.random() + 1)) + ")";
                        ctx.fillRect(i * width, j * height, width, height);
                    }
                }
            }
        }
    );
    

这里，与上面唯一的变化在于这一行代码：`ctx.fillStyle = "rgba(0,0,0," + (t * (Math.random() + 1)) + ")"`。

对于每一个小格子的 mask，我们让它的颜色值的透明度设置为 `(t * (Math.random() + 1))`：

1.  其中 t 就是 `--transition-time` 这个变量，记住，在 hover 的过程中，它的值会逐渐从 1 衰减至 0；
2.  `(Math.random() + 1)` 表示先生成一个 0 ~ 1 的随机数，再让这个随机数加 1，加 1 的目的是让整个值必然大于 1，处于 1 ~ 2 的范围；
3.  由于一开始 `--transition-time` 的值是 1，所以乘以 `(Math.random() + 1)` 的值也必然大于 1，而最终在过渡过程中 `--transition-time` 会逐渐变为 0， 整个表达式的值也最终会归于 0；
4.  由于上述 （3）的值控制的是每一个 mask 小格子的透明度，也就是说每个格子的透明度都会从一个介于 1 ~ 2 的值逐渐变成 0，借助这个过程，我们完成了整个渐隐的动画。

看看最终的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a053cec0c2c6431e8285b30d3494bccd~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=346&h=322&s=2662694&e=gif&f=177&b=e4ddd5)

> 完整代码，戳这里：[CodePen Demo -- CSS Hudini Example](https://codepen.io/Chokcoco/pen/KKeQWJb "https://codepen.io/Chokcoco/pen/KKeQWJb")

是的，细心的同学肯定会发现，文章一开头给的 Demo 是切分了 400 份 mask 的，而我们上面实现的效果，只用了 100 个 mask。

这个非常好解决，我们不是传入了 `--size-n` 和 `--size-m` 两个变量么？只需要修改这两个值，就可以实现任意格子的 Hover 渐隐效果啦。还是上面的代码，简单修改 CSS 变量的值：

    div:nth-child(1) {
        --size-m: 4;
        --size-n: 4; 
    }
    div:nth-child(2) {
        --size-m: 6;
        --size-n: 6; 
    }
    div:nth-child(3) {
        --size-m: 10;
        --size-n: 10; 
    }
    div:nth-child(4) {
        --size-m: 15;
        --size-n: 15; 
    }
    

结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8feb7fee7f3f48849313b4fd07458636~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1200&h=279&s=4295021&e=gif&f=258&b=eae5de)

> 完整代码，戳这里：[CodePen Demo -- CSS Hudini Example](https://codepen.io/Chokcoco/pen/oNyEpLN "https://codepen.io/Chokcoco/pen/oNyEpLN")

> 到这里，还有一个小问题，可以看到，在消失的过程中，整个效果非常的闪烁！每个格子其实闪烁了很多次。这个问题是可以解决的，但不是本文的核心内容。把解决的代码一并讲完可能内容会超长，感兴趣的可以在评论区继续讨论。

这样，我们就将原本 2400 行的 CSS 代码，通过 CSS Painting API 的 registerPaint，压缩到了 50 行以内的 JavaScript 代码。

利用 CSS Paint API 实现不规则边框效果
--------------------------

我们继续来看 CSS Paint API 另外一个非常有意思的实用场景：**不规则边框**的实现。

在之前，我们想实现不规则边框，如下图所示，还是有一点麻烦的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/53f56aa0b0dc49d0861ac2898adfb1b5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=450&h=178&s=1885&e=png&b=ffffff)

到了今天，利用 CSS Painting API ，我们有了一种更为直接的方式，可以更好地解决这个问题。

还是上面的图形，首先，我们通过 `clip-path` 来实现一个带有背景色的不规则图形：

    <div></div>
    

    div {
        position: relative;
        width: 200px;
        height: 64px;
        background: #f49714;
        clip-path: polygon(85% 0%, 100% 50%, 85% 100%, 0% 100%, 0% 0%;); 
    }
    

我们可以得到这样一个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3e2f300644704668948f69d87b7c9baf~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=438&h=164&s=6125&e=png&b=e8973b)

当然，本文的主角是 CSS Painting API，既然我们有 `clip-path` 的参数，其实完全也可以利用 CSS Painting API 的 borderDraw 来绘制这个图形。

我们尝试一下，改造我们的代码：

    <div></div>
    
    <script>
      if (CSS.paintWorklet) {              
        CSS.paintWorklet.addModule('/CSSHoudini.js');
      }
    </script>
    

    div {
        position: relative;
        width: 200px;
        height: 64px;
        background: paint(borderDraw);
        --clipPath: 85% 0%, 100% 50%, 85% 100%, 0% 100%, 0% 0%;); 
    }
    

这里，我们将原本的 `clip-path` 的具体路径参数，定义为了一个 CSS 变量 `--clipPath`，传入我们要实现的 `borderDraw` 方法中。整个图形效果，就是要利用 `background: paint(borderDraw)` 绘制出来。

接下来，我们需要实现 `borderDraw`。核心的点在于，我们通过拿到 `--clipPath` 参数，解析它，然后通过循环函数利用画布把这个图形绘制出来。

    // CSSHoudini.js 文件
    registerPaint(
        "borderDraw",
        class {
            static get inputProperties() {
                return ["--clipPath"];
            }
    
            paint(ctx, size, properties) {
                const { width, height } = size;
                const clipPath = properties.get("--clipPath");
                const paths = clipPath.toString().split(",");
                const parseClipPath = function (obj) {
                    const x = obj[0];
                    const y = obj[1];
                    let fx = 0,
                        fy = 0;
                    if (x.indexOf("%") > -1) {
                        fx = (parseFloat(x) / 100) * width;
                    } else if (x.indexOf("px") > -1) {
                        fx = parseFloat(x);
                    }
                    if (y.indexOf("%") > -1) {
                        fy = (parseFloat(y) / 100) * height;
                    } else if (y.indexOf("px") > -1) {
                        fy = parseFloat(y);
                    }
                    return [fx, fy];
                };
    
                var p = parseClipPath(paths[0].trim().split(" "));
                ctx.beginPath();
                ctx.moveTo(p[0], p[1]);
                for (var i = 1; i < paths.length; i++) {
                    p = parseClipPath(paths[i].trim().split(" "));
                    ctx.lineTo(p[0], p[1]);
                }
                ctx.closePath();            
                ctx.fill();
            }
        }
    );
    

简单解释一下上述的代码，注意其中最难理解的 `parseClipPath()` 方法的解释。

1.  首先我们，通过 `properties.get("--clipPath")`，我们能够拿到传入的 `--clipPath` 参数。
2.  通过 `spilt()` 方法，将 `--clipPath` 分成一段段，也就是我们的图形实际的绘制步骤。
3.  这里有一点非常重要，也就是 `parseClipPath()` 方法，由于我们的 `-clipPath` 的每一段可能是 `100% 50%` 这样的构造，但是实际在绘图的过程中，我们需要的实际坐标的绝对值，譬如在一个 100 x 100 的画布上，我们需要将 `50% 50%` 的百分比坐标，转化为实际的 `50 50` 这样的绝对值。
4.  在理解了 `parseClipPath()` 后，剩下的就都非常好理解了，我们通过 `ctx.beginPath()`、`ctx.move`、`ctx.lineTo` 以及 `ctx.closePath()` 将整个 `--clipPath` 的图形绘制出来。
5.  最后，利用 `ctx.fill()` 给图形上色。

这样，我们就得到了这样一个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/577821303f934c4fb2f27aad266aed23~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=424&h=164&s=5998&e=png&b=000000)

都拿到了完整的图形了，那么我们只给这个图形绘制边框，不上色，不就得到了它的边框效果了吗？

简单改造一些 JavaScript 代码的最后部分：

    // CSSHoudini.js 文件
    registerPaint(
        "borderDraw",
        class {
            static get inputProperties() {
                return ["--clipPath"];
            }
            paint(ctx, size, properties) {
                // ...
                ctx.closePath();            
                // ctx.fill();
                ctx.lineWidth = 1;
                ctx.strokeStyle = "#000";
                ctx.stroke();
            }
        }
    );
    

这样，我们就得到了图形的边框效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f3c2dbb941f340eb87829a7992216661~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=436&h=168&s=6436&e=png&b=ffffff)

但是，仅仅利用 `background: paint(borderDraw)` 来绘制边框效果，会有一些问题。

上述的图形，我们仅仅赋予了 1px 的边框，如果我们把边框改成 5px 呢？看看会发生什么？

    // CSSHoudini.js 文件
    registerPaint(
        "borderDraw",
        class {
            static get inputProperties() {
                return ["--clipPath"];
            }
            paint(ctx, size, properties) {
                // ...
                ctx.lineWidth = 5;
                ctx.strokeStyle = "#000";
                ctx.stroke();
            }
        }
    );
    

此时，整个图形会变成：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/14616888ee924ef8b9f541da6d367ed5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=474&h=164&s=6847&e=png&b=ffffff)

可以看到，没有展示完整的 5px 的边框，这是由于整个画布只有元素的高宽大小，而上述的代码中，元素的边框有一部分绘制到了画布之外，因此，整个图形并非我们期待的效果。

因此，我们需要换一种思路解决这个问题，继续改造一下我们的代码，仅仅需要改造 CSS 代码即可：

    div {
        position: relative;
        width: 200px;
        height: 64px;
        margin: auto;
        clip-path: polygon(var(--clipPath)); 
        --clipPath: 85% 0%, 100% 50%, 85% 100%, 0% 100%, 0% 0%;
        
        &::before {
          content:"";
          position:absolute;
          inset: 0;
          mask: paint(borderDraw);
          background: #000;
        }
    }
    

这里，我们的元素本身，还是利用了 `clip-path: polygon(var(--clipPath))` 剪切了自身，同时，我们借助了一个伪元素，利用这个伪元素去实现具体的边框效果。

这里其实用了一种`内外切割`的思想，去实现的边框效果：

1.  利用父元素的 `clip-path: polygon(var(--clipPath))` 剪切掉外围的图形；
2.  利用给伪元素的 mask 作用实际的 `paint(borderDraw)` 方法，把图形的内部镂空，只保留边框部分。

还是设置 `ctx.lineWidth = 5`，再看看效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8402738d84264f14905d0c253bd8c92a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=434&h=162&s=9584&e=png&b=eeeeee)

看上去不错，不过实际上，虽然设置了 `5px` 的边框宽度，但上图的边框宽度只有 `2.5px`，这是由于另外一半边框实际上被切割掉了。

因此，我们如果需要实现 `5px` 的效果，实际上需要 `ctx.lineWidth =10`。

当然，我们可以通过一个 CSS 变量来控制边框的大小：

    div {
        position: relative;
        width: 200px;
        height: 64px;
        margin: auto;
        clip-path: polygon(var(--clipPath)); 
        --clipPath: 85% 0%, 100% 50%, 85% 100%, 0% 100%, 0% 0%;
        --borderWidth: 5;
        
        &::before {
          content:"";
          position:absolute;
          inset: 0;
          mask: paint(borderDraw);
          background: #000;
        }
    }
    

在实际的 borderDraw 函数中，我们将传入的 `--borderWidth` 参数，乘以 2 使用就好：

    registerPaint(
        "borderDraw",
        class {
            static get inputProperties() {
                return ["--clipPath", "--borderWidth"];
            }
            paint(ctx, size, properties) {
                const borderWidth = properties.get("--borderWidth");
                // ...
                ctx.lineWidth = borderWidth * 2;
                ctx.strokeStyle = "#000";
                ctx.stroke();
            }
        }
    );
    

这样，我们每次都能得到我们想要的边框长度：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c22f808d8ce8490f8abab49a425df981~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=418&h=160&s=9418&e=png&b=eeeeee)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS Hudini & Unregular Custom Border](https://codepen.io/Chokcoco/pen/MWXXYgJ "https://codepen.io/Chokcoco/pen/MWXXYgJ")

到这里，整个实现就完成了，整个过程其实有多处非常关键的点，会有一点点难以理解，具体可能需要自己实际调试一遍找到实现的原理。掌握了上述技巧，我们就可以把它运用到更复杂的一些场景中。

譬如，我们只需要传入对应的 `clip-path` 参数以及我们想要的边框长度即可。

好，这样，我们就能实现各类不同的不规则图形的边框效果了。

像是这样：

    div {
        position: relative;
        width: 200px;
        height: 200px;
        clip-path: polygon(var(--clipPath)); 
        --clipPath: 0% 15%, 15% 15%, 15% 0%, 85% 0%, 85% 15%, 100% 15%, 100% 85%, 85% 85%, 85% 100%, 15% 100%, 15% 85%, 0% 85%;
        --borderWidrh: 1;
        --color: #000;
        
        &::before {
          content:"";
          position:absolute;
          inset: 0;
          mask: paint(borderDraw);
          background: var(--color);
        }
    }
    
    div:nth-child(2) {
        --clipPath: 50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%;
        --borderWidrh: 2;
        --color: #ffcc00;
    }
    div:nth-child(3) {
        --clipPath: 90% 58%90% 58%, 69% 51%, 69% 51%, 50% 21%, 50% 21%, 39% 39%, 39% 39%, 15% 26%, 15% 26%, 15% 55%, 15% 55%, 31% 87%, 31% 87%, 14% 84%, 14% 84%, 44% 96%, 44% 96%, 59% 96%, 59% 96%, 75% 90%, 75% 90%, 71% 83%, 71% 83%, 69% 73%, 69% 73%, 88% 73%, 88% 73%, 89% 87%, 89% 87%, 94% 73%, 94% 73%;
        --borderWidrh: 1;
        --color: deeppink;
    }
    div:nth-child(4) {
        --clipPath: 0% 0%, 100% 0%, 100% 75%, 75% 75%, 75% 100%, 50% 75%, 0% 75%;
        --borderWidrh: 1;
        --color: yellowgreen;
    }
    div:nth-child(5) {
        --clipPath: 20% 0%, 0% 20%, 30% 50%, 0% 80%, 20% 100%, 50% 70%, 80% 100%, 100% 80%, 70% 50%, 100% 20%, 80% 0%, 50% 30%;
        --borderWidrh: 3;
        --color: #c7b311;
    }
    

得到不同图形的边框效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0b65a077373a4052a563536f2e086344~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=3380&h=524&s=82404&e=png&b=ffffff)

> 完整代码，戳这里：[CodePen Demo -- CSS Hudini & Unregular Custom Border](https://codepen.io/Chokcoco/pen/KKeROeX "https://codepen.io/Chokcoco/pen/KKeROeX")

又或者是基于它们，去实现各类按钮效果，这种效果在以往使用 CSS 是非常非常难实现的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/76e33b59e0674d3e9f1620947f67393d~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=2262&h=172&s=33229&e=png&b=ffffff)

它们的核心原理都是一样的，甚至加上 Hover 效果，也是非常的轻松：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bacdcc4eb99a475b829662310bc4ed19~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1200&h=118&s=457073&e=gif&f=255&b=fefbff)

> 完整的代码，你可以戳这里：[CodePen Demo -- https://codepen.io/Chokcoco/pen/ExRLqdO](https://codepen.io/Chokcoco/pen/ExRLqdO "https://codepen.io/Chokcoco/pen/ExRLqdO")

又或者，我们经常在一些可视化页面看到的充满各种复杂线条的 UI，也是能够非常好地利用这个技巧来实现的，譬如这么一个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/60d60f817f724b56a3865d756297db0a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=237&h=145&s=3740&e=png&b=0d1c30)

其核心难点在于：

1.  不规则边框；
2.  不规则边框下的内阴影。

使用传统的 CSS 会感觉非常难以解决，但是使用 CSS Paint API 其实非常的简单，其核心的 CSS 和 JavaScript 代码如下：

    div {
        --borderWidth: 2;
        --clipPath: 30% 0%, 100% 0, 100% 70%, 70% 100%, 0% 100%, 0 30%;
        --color: #60b4be;
        width: 200px;
        height: 120px;
        clip-path: polygon(var(--clipPath)); 
        background: paint(borderDraw);
    }
    

    registerPaint(
        "borderDraw",
        class {
            static get inputProperties() {
                return ["--clipPath", "--borderWidth", "--color"];
            }
    
            paint(ctx, size, properties) {
                const { width, height } = size;
                const borderWidth = properties.get("--borderWidth");
                const clipPath = properties.get("--clipPath");
                const color = properties.get("--color");
                const paths = clipPath.toString().split(",");
                const parseClipPath = function (obj) {
                    const x = obj[0];
                    const y = obj[1];
                    let fx = 0,
                        fy = 0;
                    if (x.indexOf("%") > -1) {
                        fx = (parseFloat(x) / 100) * width;
                    } else if (x.indexOf("px") > -1) {
                        fx = parseFloat(x);
                    }
                    if (y.indexOf("%") > -1) {
                        fy = (parseFloat(y) / 100) * height;
                    } else if (y.indexOf("px") > -1) {
                        fy = parseFloat(y);
                    }
                    return [fx, fy];
                };
    
                var p = parseClipPath(paths[0].trim().split(" "));
                ctx.beginPath();
                ctx.moveTo(p[0], p[1]);
                for (var i = 1; i < paths.length; i++) {
                    p = parseClipPath(paths[i].trim().split(" "));
                    ctx.lineTo(p[0], p[1]);
                }
                ctx.closePath();
                ctx.strokeStyle = color;
                ctx.lineWidth = borderWidth * 2;
                ctx.shadowColor = "rgba(255, 255, 255, .8)";
                ctx.shadowBlur = 10;
                ctx.shadowOffsetX = 0; 
                ctx.shadowOffsetY = 0;
                ctx.stroke();
        }
    );
    

其实也只是在上述的不规则边框的基础上，再加上了阴影部分而已。并且，利用 `clip-path` 切割掉了外阴影。

> 完整的代码，你可以戳这里：[CodePen DEMO -- CSS Hudini & Unregular Custom Border And Shadow](https://codepen.io/Chokcoco/pen/OJBGEWv "https://codepen.io/Chokcoco/pen/OJBGEWv")

利用 CSS Paint API 实现波浪效果
-----------------------

CSS 实现波浪效果，一直是 CSS 的一个难点之一。在过往，虽然我们有很多方式利用一些 Hack 技巧，生成波浪效果。

但是大都是一些奇技淫巧，譬如，有这么个思路：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1aa553858e31448090311aac81f60019~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=434&h=423&s=1282023&e=gif&f=79&b=ffffff)

利用设定了不规则的 `border-radius` 圆形，旋转实现波浪效果。

如今，有了 CSS Painting API，我们已经可以绘制真实的波浪效果了。看看代码：

    <div></div>
    
    <script>
      if (CSS.paintWorklet) {              
        CSS.paintWorklet.addModule('/CSSHoudini.js');
      }
    </script>
    

    div {
        position: relative;
        width: 300px;
        height: 300px;
        background: paint(waveDraw);
        border-radius: 50%;
        border: 2px solid rgba(255, 0, 0, 0.5);
    }
    

我们定义了一个 `waveDraw` 方法，接下来，就通过利用 registerPaint 来实现这个方法即可。

    // 文件名为 CSSHoudini.js
    registerPaint(
        "waveDraw",
        class {
            static get inputProperties() {
                return [];
            }
            paint(ctx, size, properties) {
                const { width, height } = size;
                const initY = height * 0.5;
                ctx.beginPath();
                for (let i = 0; i <= width; i++) {
                    ctx.lineTo(i, initY + Math.sin((i) / 20) * 10);
                }
                ctx.lineTo(width, height);
                ctx.lineTo(0, height);
                ctx.lineTo(0, initY);
                ctx.closePath();
    
                ctx.fillStyle = 'rgba(255, 0, 0, 0.9)';
                ctx.fill();
            }
        }
    );
    

这样，我们就得到了这样一个波浪效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b75b54ac08b84e58803905ac6f3f746b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=654&h=632&s=36247&e=png&b=ffffff)

上面的代码其实很好理解，简单解释一下，我们核心就是利用路径绘制，基于 `Math.sin()` 三角函数，绘制了一段 sin(x) 三角函数的图形。

1.  整个图形从 `ctx.beginPath()` 开始，第一个点是 `ctx.lineTo(0, initY + Math.sin((i) / 20) * 10)`，不过 `Math.sin(0) = 0`，所以等于 `ctx.lineTo(0, initY)`。
2.  `initY` 在这的作用是控制从什么高度开始绘制波浪图形，我们这里的取值是 `initY = height * 0.5`，也就是定义成了图形的中间位置。
3.  利用 `for (let i = 0; i <= width; i++)` 循环，配合 `ctx.lineTo(i, initY + Math.sin((i) / 20) * 10)`，也就是在每一个 x 轴上的点，都绘制一个点。
4.  随后三个在循环体外的 `ctx.lineTo` 的作用是让整个图形形成一个闭环。
5.  最后 `ctx.closePath()` 完成整个路径，`ctx.fill()` 进行上色。

如果不 `ctx.fill()` 上色，利用 `ctx.stroke()` 绘制边框，也是可以的，其实我们得到是这样一个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fb251c6934154aa0b05b88e56ea63726~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=642&h=360&s=11743&e=png&b=ffffff)

上图是同时去掉了 CSS 代码里面的 `border-radius: 50%`，方便大家理解。

当然，上面的图形，有个很大的问题，没法动起来，所以，我们需要借助一个 CSS @property 自定义变量，让它拥有一些动画效果。

我们需要改造一下代码，首先，添加一个 CSS @property 自定义变量：

    @property --animation-tick {
      syntax: '<number>';
      inherits: false;
      initial-value: 1000;
    }
    div {
      // ... 代码与上述保持一致
      animation: move 20s infinite linear;
      --animation-tick: 1000;
    }
    @keyframes move {
        100% {
            --animation-tick: 0;
        }
    }
    

我们添加了一个 `--animation-tick` 变量，并且利用 CSS 动画，让它从 1000 减至 0。

下一步，利用这个不断在变化的 CSS 自定义变量，我们在 `waveDraw` 方法中，把它利用上：

    // 文件名为 CSSHoudini.js
    registerPaint(
        "waveDraw",
        class {
            static get inputProperties() {
                return ["--animation-tick"];
            }
            paint(ctx, size, properties) {
                let tick = Number(properties.get("--animation-tick"));
                const { width, height } = size;
                const initY = height * 0.5;
                ctx.beginPath();
                for (let i = 0; i <= width; i++) {
                    ctx.lineTo(i, initY + Math.sin((i + tick) / 20) * 10);
                }
                ctx.lineTo(width, height);
                ctx.lineTo(0, height);
                ctx.lineTo(0, initY);
                ctx.closePath();
    
                ctx.fillStyle = 'rgba(255, 0, 0, 0.9)';
                ctx.fill();
            }
        }
    );
    

仔细看，和上述的代码变化不大，核心在于，利用三角函数绘制图形的时候，我们把这个变量加入进去。

从原来的 `ctx.lineTo(i, initY + Math.sin((i) / 20) * 10)`，变成了 `ctx.lineTo(i, initY + Math.sin((i + tick) / 20) * 10)`。

这样，在这个不断变化的变量的作用下，我们的波浪图形就能运动起来了：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fb3dc10558794e80865ce0d9e5d911d6~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=310&s=161886&e=gif&f=152&b=fdfbf8)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS Houdini Wave](https://codepen.io/Chokcoco/pen/ZERxmGW "https://codepen.io/Chokcoco/pen/ZERxmGW")

虽然能动了，但总是感觉还少了些什么。如果我们把这个波浪效果应用于进度条之类的效果上，我们需要可以快速定义波浪的振幅、每个波峰之间的间距、效果的颜色、百分比等等。

因此，我们需要再通过一个 CSS 变量，让它成为一个实际可用的封装良好的波浪进度条。我们再简单改造一下：

    @property --animation-tick {
      syntax: '<number>';
      inherits: false;
      initial-value: 1000;
    }
    @property --height {
      syntax: '<number>';
      inherits: false;
      initial-value: .7;
    }
    div {
        position: relative;
        width: 300px;
        height: 300px;
        background: paint(waveDraw);
        animation: move 20s infinite linear;
        border-radius: 50%;
        border: 2px solid var(--color1);
        --amplitude: 15;
        --gap: 28;
        --animation-tick: 700;
        --height: 0.7;
        --color1: rgba(255, 0, 0, 0.5);
        --color2: rgba(255, 0, 0, 0.4);
        --color3: rgba(255, 0, 0, 0.3);
        
        transition: --height 8s;
    }
    

可以看到，我们定义了非常多个 CSS 变量，每次，它们都是有意义的：

*   `--animation-tick` 表示波浪运动的速率；
*   `--amplitude` 波浪的振幅；
*   `--gap` 波峰间距；
*   `--initHeight` 初始高度；
*   `--color1`、`--color2`、`--color3` 我们会叠加 3 层波浪效果，显得更真实一点，这里 3 个颜色表示 3 层波浪的颜色。

定义好这些 CSS 变量后，我们就可以把它们运用在实际的`waveDraw` 方法中。看看代码：

    registerPaint(
        "waveDraw",
        class {
            static get inputProperties() {
                return [
                    "--animation-tick", 
                    "--height", 
                    "--gap",
                    "--amplitude",
                    "--color1",
                    "--color2",
                    "--color3"
                ];
            }
            
            paint(ctx, size, properties) {
                let tick = Number(properties.get("--animation-tick"));
                let initHeight = Number(properties.get("--height"));
                let gap = Number(properties.get("--gap"));
                let amplitude = Number(properties.get("--amplitude"));
                let color1 = properties.get("--color1");
                let color2 = properties.get("--color2");
                let color3 = properties.get("--color3");
                
                this.drawWave(ctx, size, tick, amplitude, gap, initHeight, color1);
                this.drawWave(ctx, size, tick * 1.21, amplitude / 0.82, gap + 2, initHeight + 0.02, color2);
                this.drawWave(ctx, size, tick * 0.79, amplitude / 1.19, gap - 2, initHeight - 0.02, color3);
            }
            
            /**
             * ctx
             * size
             * tick 速率
             * amplitude 振幅
             * gap 波峰间距
             * initHeight 初始高度
             * color 颜色
             */
            drawWave(ctx, size, tick, amplitude, gap, initHeight, color) {
                const { width, height } = size;
                const initY = height * initHeight;
                tick = tick * 2;
                
                ctx.beginPath();
                for (let i = 0; i <= width; i++) {
                    ctx.lineTo(i, initY + Math.sin((i + tick) / gap) * amplitude);
                }
                ctx.lineTo(width, height);
                ctx.lineTo(0, height);
                ctx.lineTo(0, initY);
                ctx.closePath();
                ctx.fillStyle = color;
                ctx.fill();
            }
        }
    );
    

可以看到，我们在 `paint()` 方法中，调用了 `this.drawWave()`。每次调用 `this.drawWave()` 都会生成一个波浪图形，通过 3 层的叠加效果，生成 3 层波浪。并且，把我们在 CSS 中定义的变量全部的应用了起来，分别控制波浪效果的不同参数。

这样，我们就得到了这样一个波浪效果：

![](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6930c990d63d4bc087aaa6e9611f541b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=310&s=329834&e=gif&f=203&b=fdfbf7)

通过控制 CSS 中的 `--height` 变量，还可以实现高度的变化，从而完成真实的百分比，实现一种进度条效果。

    div:hover {
        --height: 0;
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/51fd65149a454a9aaaa15f4a301dd4b3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=310&s=599184&e=gif&f=355&b=fdfaf7)

很好，非常不错的效果。有了上述一些 CSS 自定义变量的帮助，我们就可以通过封装好的 `waveDraw` 方法，实现不同颜色、不同大小、不同速率的波浪进度条效果了。

我们只需要简单改变一下传入的 CSS 变量参数即可：

    <div></div>
    <div></div>
    <div></div>
    

    div {
        position: relative;
        width: 300px;
        height: 300px;
        background: paint(waveDraw);
        animation: move 20s infinite linear;
        border-radius: 50%;
        border: 2px solid var(--color1);
        --amplitude: 15;
        --gap: 28;
        --animation-tick: 700;
        --height: 0.7;
        --color1: rgba(255, 0, 0, 0.5);
        --color2: rgba(255, 0, 0, 0.4);
        --color3: rgba(255, 0, 0, 0.3);
        
        transition: --height 8s;
    }
    div:nth-child(2) {
        --amplitude: 6;
        --gap: 25;
        --animation-tick: 300;
        --height: 0.5;
        --color1: rgba(28, 90, 199, 0.5);
        --color2: rgba(28, 90, 199, 0.4);
        --color3: rgba(28, 90, 199, 0.3);
    }
    div:nth-child(3) {
        --amplitude: 3;
        --gap: 30;
        --animation-tick: 1200;
        --height: 0.3;
        --color1: rgba(178, 120, 33, 0.5);
        --color2: rgba(178, 120, 33, 0.4);
        --color3: rgba(178, 120, 33, 0.3);
    }
    

看看效果如何：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2768508d8cc6490a96d94d0e5e6d97d4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1000&h=298&s=1280506&e=gif&f=339&b=fcf9f6)

> 完整代码，戳这里：[CodePen Demo -- CSS Hudini Custom Wave Effects !](https://codepen.io/Chokcoco/pen/XWYEGyz "https://codepen.io/Chokcoco/pen/XWYEGyz")

这样，借助 CSS Painting API，我们完美地实现了波浪图形，并且借助它，实现了波浪进度条效果。通过传入不同的 CSS 变量，我们有了快速批量生成不同效果的能力，弥补了过往 CSS 在波浪效果上的缺陷！

当然，就基于上述的代码，还是有一些可以优化的空间的：

1.  在上述的 CSS 代码中，可以看到，我们是传入了 3 个关于颜色的 CSS 变量，`--color1`、`--color2`、`--color3`，正常而言，这里传入 1 个颜色即可，通过转换成 HSL 颜色表示法，替换 L 色值，得到近似的另外两个色值即可。当然，这样做的话会增添非常多的 JavaScript 代码，所以，本文为了方便大家理解，偷懒直接传入了 3 个 CSS 颜色变量值。
    
2.  整个波浪效果单轮的动画持续时间我设置为了 20s，但是在本文中，没有去适配动画的首尾衔接，也就是可能会出现每 20s，波浪效果有一个明显的跳动的感觉。解决这个问题，有两个思路：
    
    *   通过精确的计算，让动画的最后一帧和动画的第一帧衔接上；
    *   把 `--animation-tick` 的值设置得非常大，然后把相应的单轮动画时间设置得非常长，这样，基本也感受不到动画的跳帧。
3.  第三个问题可能就在于**兼容性**了。
    

CSS Paint API 兼容性
-----------------

那么，CSS Painting API 的兼容性到底如何呢？

[CanIUse - registerPaint](https://caniuse.com/?search=registerPaint "https://caniuse.com/?search=registerPaint") 数据如下（截止至小册写作的今天 2023-05-28）：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9e0e9f822ecf4afd87e4b9fcacb75219~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1371&h=520&s=81436&e=png&b=ede0c6)

Chrome 和 Edge 基于 [Chromium](https://www.google.com.hk/search?newwindow=1&rlz=1C5GCEM_enCN988CN988&q=Chromium&spell=1&sa=X&ved=2ahUKEwi3he2ensL7AhVaSmwGHdnzBxgQkeECKAB6BAgoEAE "https://www.google.com.hk/search?newwindow=1&rlz=1C5GCEM_enCN988CN988&q=Chromium&spell=1&sa=X&ved=2ahUKEwi3he2ensL7AhVaSmwGHdnzBxgQkeECKAB6BAgoEAE") 内核的浏览器很早就已经支持，而主流浏览器中，Firefox 和 Safari 目前还不支持。

CSS Paint API 虽然强大，目前看来要想大规模上生产环境，仍需一段时间的等待。让我们给它一点时间！

总结一下
----

本章，我们在上一章 CSS 变量和 CSS @property 的基础上，介绍了 CSS 中一个非常强大的特性 CSS Paint API。

它的优点非常明显：

1.  更广泛的样式定制：CSS Paint API 提供了一种灵活的方式，使得开发人员可以轻松地实现更加自由、个性化的样式效果，从而增强用户体验和页面吸引力。
2.  更高的可复用性：使用 CSS Paint API 编写的样式可以与现有的 CSS 规则完美地结合使用，而无需任何额外的 DOM 操作或 JavaScript 代码，这样可以大大提高样式的可复用性和维护性。
3.  更好的性能：CSS Paint API 是在渲染引擎内部进行的，因此性能比 JavaScript 等其他方法更高效。

**CSS Paint API 的本质就是将绘图的能力从 CSS 转移到了** **JavaScript** **，以一种类似于 Canvas 画布能力实现图形的绘制！**

合理利用它们，我们可以实现许多之前 CSS 无法实现的效果，譬如不规则边框效果、波浪效果等等。

当然，我们需要看到其学习成本较高、学习路线较为陡峭的问题。现阶段 CSS Paint API 的兼容性和流行程度也是非常大一个问题。当然，保持学习新内容，掌握更多的新解法，拓宽解题的思路，CSS Paint API 还是可以给我们非常多启发的。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
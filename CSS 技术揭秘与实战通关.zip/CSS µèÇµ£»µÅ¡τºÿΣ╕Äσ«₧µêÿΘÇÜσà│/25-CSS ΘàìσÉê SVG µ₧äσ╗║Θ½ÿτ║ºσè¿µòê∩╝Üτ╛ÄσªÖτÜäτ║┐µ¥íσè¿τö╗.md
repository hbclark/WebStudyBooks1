在本小册中，我们一直在探索 CSS 能力的边界。

介绍的每一个属性，都尽可能地去挖掘其使用场景，尽可能地用它们去解决一些实际问题。

但是，不管怎么样，CSS 的能力总是会有一个边界的，能够解决的问题也是有限的。

譬如，在 3D 的章节中，我们对比了 CSS 3D 与 WebGL 的能力差距，明确了哪些场景是 CSS 3D 力所能及的。

而一个有意思的现象是，**有的时候，用某种语言无法解决的问题，可能在其他语言环境下，是非常简单的问题。**

这也就引出了接下来两章的内容：**在** **CSS** **中，借助 SVG 的外力，巧妙地解决很多纯 CSS 无法解决的问题**。

当然，我们并不会从 0 开始学习 SVG，更不是去完全介绍 SVG 语言，剖析其能力。虽然有 SVG 部分的内容，但是它们通过了某些属性，能够与 CSS 打通，通过 CSS 去引入或者控制 SVG 的样式。

本章，我们会着重围绕**线条动画**展开。

好，接下来进入今天的正文部分，思考一下，如果仅仅使用 CSS，下面的这个按钮效果如何实现呢？

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b2912c196a1b45508bf0a0373d64adb5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=81&s=92450&e=gif&f=87&b=faf7fd)

想要实现这个效果，其核心在于一个**线条的变换动画**，拆解出来，也就是整个动画的核心是如下所示的线条动画效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9e5cc5a4fd874909bf8fbb6518a8d067~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=81&s=67805&e=gif&f=122&b=fefbff)

这个效果，使用 CSS 实现其实是非常非常困难的。但是，对于 SVG 而言，它又是小菜一碟！

SVG 快速入门
--------

如果从头开始讲 SVG，直到讲到 SVG 路径动画，可能需要的篇幅非常之多。

当然，我们还是会快速介绍一下 SVG 基础。当然更希望读者同学，已经有了一定的 SVG 基础知识。

根据 [MDN](https://developer.mozilla.org/zh-CN/docs/Web/SVG/Tutorial "https://developer.mozilla.org/zh-CN/docs/Web/SVG/Tutorial") 的描述，全称可缩放矢量图形（Scalable Vector Graphics），是一种基于 XML 标记语言的图像格式。相对于其他图像格式（如 JPEG、GIF 等），SVG 具有以下优势：

1.  **可无限缩放**：SVG 是矢量图形，相比于位图能够保证图像质量，在不同尺寸下不会出现失真。
2.  **体积小**：与 JPG 和 PNG 等图像格式不同，SVG 文件仅是由一个特定的 XML 源代码组成，因此它们在文件大小和下载速度方面具有优势。
3.  **易于编辑**：由于 SVG 是基于文本的 XML 格式，因此可以通过编辑 SVG 代码轻松地修改图像。
4.  **支持动画和交互**：SVG 可以使用 JavaScript 来创建动态图像，并且可以为 SVG 图像添加事件处理程序和链接，使其具有更多的交互性。

通常我们使用 SVG 的场景，就是为了与 CSS 进行互补，它的某些能力，能够很好地填补 CSS 的空白。

学习 SVG，最为基础的就是它的各种形状。使用 SVG，我们快速绘制各种不同的图形，像是下面这些：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5e823019567b4f518505b715d2aaddcc~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=110&h=260&s=11500&e=png&b=e6e5e5)

有一些非常常规的形状，它们包含：

1.  矩形
2.  圆形
3.  椭圆
4.  线条
5.  折线
6.  多边形

也可以利用 SVG 的 PATH 属性绘制一些复杂图形：

1.  二次贝塞尔曲线
2.  三次贝塞尔曲线

基于上面的这些几何形状，我们就能绘制出所有类型的图形。这个就是 SVG 最基础的内容。

我们来看一个最简单的例子，利用 SVG 的 `rect` 元素，绘制一个矩形元素：

      <svg height="100%" width="100%" xmlns="http://www.w3.org/2000/svg">
        <rect width="250" height="50" stroke="#673ab7" stroke-width="2" fill="transparent" />
      </svg>
    

其核心就是 `<rect width="250" height="50" stroke="#673ab7" stroke-width="2" fill="transparent" />` 这一句，这样我们就成功地得到了一个矩形元素：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/05dcc66f151443f6a515c20d11755778~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=280&h=73&s=1139&e=png&b=ffffff)

简单解释一下：

1.  `<rect>` 元素在 SVG 中表示矩形图案，其他的还有圆形 `<circle>`、椭圆 `<ellipse>` 等等，具体的 SVG 图形，你可以戳这里了解 -- [SVG 基本形状](https://developer.mozilla.org/zh-CN/docs/Web/SVG/Tutorial/Basic_Shapes "https://developer.mozilla.org/zh-CN/docs/Web/SVG/Tutorial/Basic_Shapes")；
2.  在元素内部，`width`、`height` 属性非常好理解，表示矩形元素的高宽；
3.  `stroke` 和 `stroke-width` 可以类比 CSS 中的 `border-color` 和 `border-width`，表示边框的颜色和宽度；
4.  `fill` 可以类比 CSS 中的 `background`，表示元素的颜色。

看，是不是非常好理解？这样 SVG 就算入门了，当我们想去画一个 SVG 图形的时候，再去翻阅 API 文档，其实很容易就能上手。

譬如，我们尝试画一个半径为 `50px` 的圆形，设置 `1px` 的黑色边框，并且填充粉色 `deeppink`：

    <svg height="100%" width="100%" viewBox="-5 -5 200 200" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="50" stroke="#000" stroke-width="1" fill="deeppink"/>
    </svg>
    

当然，`<circle>` 的语法有点点不一样，其中 `cx`、`cy` 表示圆心位置，`r` 表示半径，这样我们就得到了一个圆形，结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/21f2bed64ce740c299f2a2550724e3d9~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=128&h=122&s=4023&e=png&b=ff1489)

SVG 图形与 CSS 之间的桥梁
-----------------

好，到这里，我们会稍微提速一下，SVG 基础部分读者同学可能需要自行再去学习学习。

那么，上文提及的所谓的 “**SVG 图形与** **CSS** **之间的桥梁**” 是什么呢？

上面，我们把一个 SVG 图形的属性定义在了元素内部：

    <svg height="100%" width="100%" xmlns="http://www.w3.org/2000/svg">
      <rect width="250" height="50" stroke="#673ab7" stroke-width="2" fill="transparent" />
    </svg>
    

就是内部的 `height`、`width`、`stroke`、`stroke-width`、`fill` 等等。但是，有趣的是，我们可以通过给 SVG 元素选择器，在 CSS 中利用选择器选中对应的 SVG 元素，再利用 CSS 样式对 SVG 元素进行控制！

也就是说，下面的代码与上述的代码是等价的：

    <svg height="100%" width="100%" xmlns="http://www.w3.org/2000/svg">
      <rect class="rect"/>
    </svg>
    

    .rect {
      width: 250px;
      height: 50px;
      stroke: #673ab7;
      stroke-width: 2;
      fill: transparent;
    }
    

可以得到一模一样的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5a8fc104bbfe4630b67394ce0c1bab6f~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=280&h=73&s=3897&e=png&b=ffffff)

没错，这里通过 CSS 样式去控制 SVG 元素的表现，**就是 SVG 图形与 CSS 之间的桥梁**。

相当一部分 SVG 属性在 CSS 中也被支持，并且，非常重要的一点是，它们也支持过渡以及动画效果！

上面的代码，我们再稍加改造：

    .rect {
      width: 250px;
      height: 50px;
      stroke: #673ab7;
      stroke-width: 2;
      fill: transparent;
      transition: all 1s;
    }
    .rect:hover {
      stroke-width: 1;
      fill: deeppink;
      stroke: transparent;
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2c039392002f4ceda558f78d37dc7e54~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=260&h=79&s=104970&e=gif&f=96&b=fffcff)

有意思：

1.  通过 CSS 样式去控制 SVG 元素的表现；
2.  部分属性是支持 CSS 过渡与动画效果的。

这两点就给了基于 CSS 去控制 SVG 元素非常大的想象空间，能够完成的动效也非常的多。

SVG 线条动画
--------

当然，仅仅只有上面这些还不够。

到目前为止，介绍的内容，使用 CSS 也都可以实现，那 SVG 到底有什么特殊之处呢？

这里就要介绍 SVG 中，非常有趣的两个属性，`stroke-dasharray` 和 `stroke-dashoffset`。

*   `stroke-dasharray`：值是一组数组，没数量上限，每个数字交替表示边框与间隔的宽度；
*   `stroke-dashoffset`：表示的是边框线的偏移量。

这两属性有什么特殊呢？我们来一起看看。

正常而言，元素的边框都是完整的，其样式，在 CSS 中有 `solid`、`dashed` 等等。

但是 SVG 允许对元素边框进行更为复杂的定制。

譬如，我们想实现一个虚线边框，在 CSS 中可以利用 `dashed` 关键字。但是，每段虚线的长度、每段虚线线段的长度是无法控制的，在 SVG 中利用 `stroke-dasharray` 就可以进行控制。

还是上面的 DEMO，我们利用 `stroke-dasharray` 来实现多种不同的虚线样式：

    <svg xmlns="http://www.w3.org/2000/svg">
      <rect class="rect rect1"/>
    </svg>
    <svg xmlns="http://www.w3.org/2000/svg">
      <rect class="rect rect2"/>
    </svg>
    <svg xmlns="http://www.w3.org/2000/svg">
      <rect class="rect rect3"/>
    </svg>
    

    svg {
      width: 250px;
      height: 50px;
      margin-bottom: 20px;
    }
    .rect {
      width: 100%;
      height: 100%;
      stroke: #673ab7;
      stroke-width: 2;
      fill: transparent;
    }
    .rect1 {
      stroke-dasharray: 10 10;
    }
    .rect2 {
      stroke-dasharray: 30 30;
    }
    .rect3 {
      stroke-dasharray: 50 20;
    }
    

这样，我们就能得到不同的虚线边框样式：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1483398cab084d4399d1e4c69c92cf87~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=272&h=200&s=2577&e=png&b=ffffff)

取其中一个，一看就懂：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2e7f984f780a4a1a97406f5e40c31035~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=706&h=384&s=36688&e=png&b=ffffff)

OK，那 `stroke-dashoffset` 的作用又是什么呢？也很好理解，可以设置边框的偏移量。

默认情况下，虚线的起点位于路径的起点处，但是通过改变 `stroke-dashoffset` 值，可以让虚线从路径的其他位置开始绘制。

一个简单的例子：

    .rect1 {
      stroke-dasharray: 10 20 30 40 50 60;
      stroke-dashoffset: 0;
    }
    .rect2 {
      stroke-dasharray: 10 20 30 40 50 60;
      stroke-dashoffset: 20px;
    }
    .rect3 {
      stroke-dasharray: 10 20 30 40 50 60;
      stroke-dashoffset: 40px;
    }
    

在上面，我们的 `stroke-dasharray` 是一致的，`10 20 30 40 50 60` 表示边框和间隔按照 `10px 20px 30px 40px 50px 60px` 的规律进行，不断循环，只有 `stroke-dashoffset` 不一致，分别是 0、`20px` 和 `40px`。效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0e95ead050434b40a4c45f2ed35f85a1~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=313&h=246&s=1423&e=png&b=ffffff)

仔细看 3 个图形，边框形状是一致的，就是边框的起点不一样，而这，就是 `stroke-dashoffset` 的作用：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2dc079634b3547be8707e13079da7d1b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=870&h=453&s=29503&e=png&b=ffffff)

> 完整的代码，你可以戳这里：[CodePen Demo -- SVG DashArray and DashOffset](https://codepen.io/Chokcoco/pen/OJaMJOP "https://codepen.io/Chokcoco/pen/OJaMJOP")

规则图形的 SVG 路径线条动画
----------------

好，到这里，该有的铺垫都铺垫完了，可以进入实战环节了。在掌握了上述内容后，我们就可以利用它们开始去实现各种边框动画效果。首先，我看一些规则图形的 SVG 路径线条动画。

回到文章一开始的效果，我们需要实现这么一个线条动画：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/247f17a9b23b40fc8488db9cc177e0b6~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=81&s=67805&e=gif&f=122&b=fefbff)

这个效果，使用 CSS 实现其实是非常非常困难的。但是，有了上面的内容铺垫后，使用 SVG 实现是非常简单的。

首先，利用 `rect` 元素，通过调试 `stroke-dasharray`，我们就可以得到边框的初始状态，仅仅在下方展示一条线段：

     <div class="container">
        <svg height="100%" width="100%" xmlns="http://www.w3.org/2000/svg">
            <rect class="rect" />
        </svg>
     </div>
    

      .rect {
        width: 250px;
        height: 50px;
        stroke: #673ab7;
        stroke-width: 1px;
        fill: transparent;
        stroke-dasharray: 100 500;
        stroke-dashoffset: 225;
      }
    

我们通过 `stroke-dasharray: 100 500` 设置虚线边框的规则，线段部分为 `100px`，间隔部分为 `500px`，由于元素的高宽为 `250px` 和 `50px`，因此周长就是 `600px`，所以，在 `stroke-dasharray: 100 500` 的规则下，只能看到一条线段。

再通过 `stroke-dashoffset: 225` 把唯一的边框线段调整到我们想要的位置。

这样，就可以得到如下效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a5f5d85a90454c12a4fa76610d221ccf~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=187&h=79&s=354&e=png&b=ffffff)

在这个基础上，设置一个 `:hover` 规则：

    .container:hover .rect {
      stroke: deeppink;
      stroke-dasharray: 600 0;
      stroke-dashoffset: 475;
      stroke-width: 3px;
    }
    

代码也非常好理解，通过改变 `stroke-dasharray` 和 `stroke-dashoffset`，就能实现边框的动态变化效果，而 `stroke-dasharray: 600 0` 的意思是，线段部分为 `600px`，间隔部分为 `0px`，因为周长只有 `600px`，相当于最终状态，只有一条线段。

而 `stroke-dashoffset: 475` 的变化，可以调整边框线段在运动过程中的方向。

最终，动画效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f70cd28dd06348ab809ecd01b3041a06~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=81&s=67805&e=gif&f=122&b=fefbff)

再配合文字的简单动画，文章开头的整个动画的完整代码如下：

    <div class="container">
      <svg height="100%" width="100%" xmlns="http://www.w3.org/2000/svg">
        <rect class="rect" />
        <div class="text">Line Animations</div>
      </svg>
    </div>
    

    .container {
      position: relative;
      width: 250px;
      height: 50px;
    
      .rect {
        width: 250px;
        height: 50px;
        stroke: #673ab7;
        stroke-width: 1px;
        fill: transparent;
        transition: .5s ease-in-out;
        stroke-dasharray: 100 500;
        stroke-dashoffset: 225;
      }
      .text {
        position: absolute;
        inset: 0;
        transition: .3s;
        transition-delay: .6s;
      }
    }
    
    .container:hover {
      .rect {
        stroke: deeppink;
        stroke-dasharray: 600 0;
        stroke-dashoffset: 475;
        stroke-width: 3px;
      }
    
      .text {
        background: deeppink;
        color: #fff;
      }
    }
    

这样，我们就完美地还原了这个效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/56cf4b8f612a47a2a5cb7e06452e0776~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=81&s=92450&e=gif&f=87&b=faf7fd)

> 完整的代码，你可以戳这里：[CodePen Demo -- SVG Hover Animations](https://codepen.io/Chokcoco/pen/qBQOLXB "https://codepen.io/Chokcoco/pen/qBQOLXB")

当然，掌握了这个技巧之后，我们可以发挥想象力，去创造各种有意思的边框线条 Hover 动画。再举个例子，譬如下面这样的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/88dc23fcc81844479d38c79b3429ce68~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=357&h=93&s=105827&e=gif&f=50&b=ffffff)

> 在 CodePen 上，还是有非常多类似的案例的，譬如更多有意思的 Hover 效果，你可以点击这里：[CodePen Demo -- SVG Line Animation](https://codepen.io/kjbrum/pen/PoXQWN "https://codepen.io/kjbrum/pen/PoXQWN")

当然，类似的线条不仅仅是只能运用在按钮上，在某年的 APP 扫福活动上，就有这么一个有意思的扫码动画：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c2c542e2d68a406e9302a7f67d7b2980~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=348&h=361&s=63747&e=gif&f=51&b=000000)

实现这个效果，使用 CSS 的话，是非常困难的。同理，借助 SVG，它将迎刃而解。

代码如下：

    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="300px" height="300px">
        <polygon class="g-polygon-wrap" points="150 0, 300 75, 300 225, 150 300, 0 225,  0 75, 150 0" />
        <polygon class="g-polygon-move" points="150 0, 300 75, 300 225, 150 300, 0 225,  0 75, 150 0" />
    </svg>
    

这里，我们运用了两个 SVG 对象，都是 `<polygon>`，它表示多边形。如果对 `clip-path` 章节还有印象，我们也提到过 `clip-path` 中的 `polygon()` 方法，此元素可以基于我们给定的坐标点，生成一个多边形。

此处一个 `<polygon>` 用于实现整个正六边形，另外一个 `<polygon>` 用于实现线条动画：

    .g-polygon-wrap,
    .g-polygon-move {
        fill: none; 
        stroke: #bf303c; 
        stroke-width: 2;
        stroke-linejoin: round;
        stroke-linecap: round;
    }
    
    .g-polygon-move {
        transform-origin: center center;
        transform: scale(1.05);
        stroke: linear-gradinet(180deg, red, transprent);
        stroke-width:1.5;
        stroke-dasharray: 280, 700;
        stroke-dashoffset: 8;
        animation: move 2.4s infinite linear;
    }
    
    @keyframes move {
        0% {
            stroke-dashoffset: 8;
        }
        100% {
            stroke-dashoffset: -972;
        }
    }
    

代码还是非常好理解的，其核心，还是基于 `stroke-dasharray` 和 `stroke-dashoffset` 的动态变换。

1.  `stroke-dasharray: 280, 700` 虚线边框的初始状态，只能看到一条线段；
2.  由于在此动画中，边框长度及间隔不需要变换，只需要一条线段不断围绕六边形运动，因此，在动画中，只需要改变 `stroke-dashoffset` 即可。

> 完整的代码，你可以戳这里：[CodePen Demo -- Alipay RedPacket Scan Animation](https://codepen.io/Chokcoco/pen/YzPjaXp "https://codepen.io/Chokcoco/pen/YzPjaXp")

最后，我们再来看一个 Loading 动画：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bdeadb97e2d047b786b1e72fff265cab~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=150&h=151&s=236325&e=gif&f=213&b=fffcff)

基于上面的内容，现在让你来实现这个效果，有思路了吗？

是的，这里只需要一个简单的 SVG 标签 `<circle>`，再配合 `stroke-dasharray` 和 `stroke-dashoffset` 即可轻松完成上述效果：

    <svg class="circular" viewbox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" />
    </svg>
    

    .circular {
      width: 100px;
      height: 100px;
      animation: rotate 2s linear infinite;
    }
    .path {
      stroke-dasharray: 1, 200;
      stroke-dashoffset: 0;
      stroke: #000;
      animation: dash 1.5s ease-in-out infinite
    }
    @keyframes rotate {
      100% {
        transform: rotate(360deg);
      }
    }
    @keyframes dash {
      0% {
        stroke-dasharray: 1, 200;
        stroke-dashoffset: 0;
      }
      50% {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: -35px;
      }
      100% {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: -124px;
      }
    }
    

简单解释一下，利用 `stroke-dasharray` 将原本的整个圆形边框，切割成多段，假设是 `stroke-dasharray: 10, 10` 表示这样一个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9adc23ea7ce9475990eeea350fc6e80f~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=206&h=218&s=6610&e=png&b=ffffff)

而实际代码中的 `stroke-dasharray: 1, 200`，表示在两条 `1px` 的线段中间，间隔 `200px`，由于直径 `40px` 的圆的周长为 `40 * π ≈ 125.6px`，小于 `200`，所以实际如图下，只有一个点：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4c33ab92a08e4179a1649210edcf38ee~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=216&h=212&s=4766&e=png&b=ffffff)

同理，`stroke-dasharray: 89, 200` 表示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/96b7f8e6b6d44f45b802bc0844b319ff~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=202&h=186&s=6764&e=png&b=ffffff)

通过 animation，让线段在这两种状态之间不断循环变换。而 `stroke-dashoffset` 的作用则是将线段向前推移，配合父容器的 `transform: rotate()` 旋转动画，使得视觉效果上线段是一直在向一个方向旋转。结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a73a3aa2cc1e484ebf8421c86d2a3eef~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=150&h=151&s=236325&e=gif&f=213&b=fffcff)

> 完整的代码你可以戳这里：[CodePen Demo -- Linear loading](https://codepen.io/Chokcoco/pen/jOGQGJP?editors=1100 "https://codepen.io/Chokcoco/pen/jOGQGJP?editors=1100")

不规则图形的 SVG 路径线条动画
-----------------

上面的几个例子，都是规则图形的线条动画。也就是说，其中的形状（路径），我们是可以手写得到的。

那如果我们想实现一个非规则图形的线条动画，又该怎么办呢？譬如这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/355178519d684afdaeff9abe8508d84e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=325&h=311&s=560759&e=gif&f=90&b=18111a)

在 SVG 中，我们可以通过 `<rect>`、`<circle>` 等元素手绘图案。当然图案比较复杂时，也可以通过 `<path>` 元素，填充路径，绘制图案。

SVG 的 Path 属性是指可以用来绘制图形的命令集合。Path 属性采用了类似于笔画线条的方式，通过一系列的起始点、方向、终止点、角度等信息来完整描述图形的轮廓。

Path 命令包括以下几种类型：

1.  Moveto（M）：将画笔移动到指定坐标点，作为路径的起点。
2.  Lineto（L）：绘制一条直线，参数为终点坐标。
3.  Horizontal Lineto（H）：绘制一条水平线，参数为终点的 x 坐标。
4.  Vertical Lineto（V）：绘制一条垂直线，参数为终点的 y 坐标。
5.  Curve（C）：绘制一条三次贝塞尔曲线，需要给出起始点、控制点和终点三个坐标。
6.  Smooth Curve（S）：绘制一条光滑的三次贝塞尔曲线。
7.  Quadratic Bézier Curve（Q）：绘制一条二次贝塞尔曲线。
8.  Smooth Quadratic Bézier Curve（T）：绘制一条光滑的二次贝塞尔曲线。
9.  Elliptical Arc（A）：绘制一个椭圆弧形。

使用这些命令，可以绘制出复杂的图形。一般还算不太复杂的图形，手写 Path 路径有可以的，但是对于复杂度到达了一定程度的图形，手写的工作量就太大了，此时，我们必须借助工具。

这里，我介绍 2 个比较实用的工具：

1.  简单路径绘制工具 —— [SVGPathEditor](https://yqnn.github.io/svg-path-editor/ "https://yqnn.github.io/svg-path-editor/")；
2.  Adobe Photoshop 和 AI，导出复杂路径。

首先看第一种 [SVGPathEditor](https://yqnn.github.io/svg-path-editor/ "https://yqnn.github.io/svg-path-editor/")，它是一个简易版本的在线路径绘制工具。

界面如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/279b0fb2bdb041c78ba87b766142b29e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=3134&h=1612&s=255821&e=png&b=2a2a2a)

通过这个在线 Web 页面，可以可视化操作 Path 的各种指令，绘制我们想要的图形，得到相应的 SVG 路径。

在这里，我们应用这个软件，绘制出了想要的心形图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/79ddfe2e429045d4a6c7499afae59394~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=791&h=535&s=60357&e=png&b=2a2a2a)

通过可视化界面，最终的目的就是拿到这一段 SVG 的 Path 路径：

    M 400 160 A 2 2 90 0 0 260 160 A 2 2 90 0 0 120 160 C 120 230 260 270 260 350 C 260 270 400 230 400 160
    

有了它，利用本文核心的 `stroke-dasharray` 和 `stroke-offset` 属性，我们就可以得到一个心形追逐线条动画：

    <div class="container">
        <svg>
            <path class="line" d="M 400 160 A 2 2 90 0 0 260 160 A 2 2 90 0 0 120 160 C 120 230 260 270 260 350 C 260 270 400 230 400 160" />
        </svg>
        <svg>
            <path class="line line2" d="M 400 160 A 2 2 90 0 0 260 160 A 2 2 90 0 0 120 160 C 120 230 260 270 260 350 C 260 270 400 230 400 160" />
        </svg>
    </div>
    

    body {
        background: #000;
    }
    svg {
        position: absolute;
    }
    .container {
        position: relative;
    }
    .line {
        fill: none;
        stroke-width: 10;
        stroke-linejoin: round;
        stroke-linecap: round;
        stroke: #fff;
        stroke-dasharray: 328 600;
        animation: rotate 2s infinite linear;  
    }
    .line2 {
        animation: rotate 2s infinite -1s linear;   
    }
    @keyframes rotate {
      0% {
        stroke-dashoffset: 0;
      }
      100% {
        stroke-dashoffset: 928;
      }
    }
    

整体的动画效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/43243c7df537427aa17a20acbbca6c1b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=325&h=311&s=560759&e=gif&f=90&b=18111a)

简单解释下上述代码：

1.  两个相同的 SVG 图形，通过 `stroke-dashoffset` 将完整的线条图形截成部分；
2.  通过 `stroke-dashoffset` 的从 0 到 928 的变化，实现一次完整的线条动画循环（这里的 928 是完整的 path 的长度，可以通过 JavaScript 脚本求出）；
3.  整个动画过程 2s，设置其中一个的 `animation-delay: -1s`，也就是提前 1s 触发动画，这样就实现了两个心形线条的追逐动画。

还有一种情况，就是面对更为复杂的线条，手绘已经是不可能完成的任务了。此时，我们就需要借助专业的工具，通过原图，得到路径。也就是上面说的借助 **Adobe** **Photoshop** **和** **AI** **，导出复杂路径**。

以这个图形为例子：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5b16c1c1d70f42a989fa4700ee832a5b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=256&h=217&s=157774&e=gif&f=40&b=ffffff)

当然，本文的重点不在于如何导出复杂路径。如何借助 **Adobe** **Photoshop** **和** **AI** **，导出复杂路径，可以参考下我过往写的这篇详细教程：[【Web动画】SVG 实现复杂线条动画](https://www.cnblogs.com/coco1s/p/6230165.html "https://www.cnblogs.com/coco1s/p/6230165.html")**

最终，我们的结果，是要拿到这么个路径：

    <div class="container">
      <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="210" height="200" x="0px" y="0px" viewbox="0 0 100 100">
         <path class="yy" d="M43.4,0.2c1.4,1.5,0.9,4,0.2,5.8c2-0.5,3.3-0.7,4.1-2.4c0.1,0.2,0.2,0.3,0.2,0.5c0.8,1.3-0.3,3.5,0.7,3.8c1.6,0.6,3.2,1.1,4.8,1.7c3.8-3.3,15.2-6,20.6-2.4c1.3,4.4,2.1,11.5,0.7,16.8c-0.6,1.6-1.3,3.2-1.9,4.8c-0.5,3,3.1,8.9,2.2,13.9c-1.4,7.4-6.1,11.1-8.9,15.8c5.3,1,9.1-3.1,16.3-1.7c10.3,2,18.4,13.5,10.6,24c-2.2,2.9-8.2,6.5-13.9,5.5c-3.1-0.5-7.2-1.5-10.6-0.7c-6.5,1.6-10.9,7.3-16.8,9.8c-1.9,0.8-7,1.4-9.1,0.2c-0.8-0.4-0.4-1.4-1.7-1.4c-1-0.1-6.3-0.3-7.2,0c-1.9,0.6-3.2,2.7-7.4,1.9c-7.7-1.5-12.8-11.4-12.7-20.9c-1,0.7-2.5,2-4.3,1.2c-0.4-0.2-0.8-0.5-1.2-0.7c-0.8-2.6,1.9-11,1.9-11c1.3-2.8,4.5-4.2,6.5-6.5c-0.2-0.2-0.5-0.3-0.7-0.5c-8.1-4-17.5-6.2-15.1-20.4c0.6-3,1.3-5.9,1.9-8.9C1.9,24.5-3.1,10.1,2.4,6.7c4.8-4.3,16.8,0.9,19.9,2.9c2.1-0.6,4.2-1.3,6.2-1.9c1.5-0.8,2.7-2.6,4.6-3.4C37.7,2.5,41.6,4.7,43.4,0.2z"/>
      </svg>
    </div>
    

有了这个路径，再次重复上面的过程，就能轻松得到我们想要的路径动画了！

> 完整的代码，你可以看这里：[CodePen Demo -- SVG Line Animation](https://codepen.io/Chokcoco/pen/GNbwYV "https://codepen.io/Chokcoco/pen/GNbwYV")

边框线条动画配合 `drop-shadow`
----------------------

还有一个有意思的点，线条动画是可以配合 `drop-shadow` 实现更有意思的光影效果的。

`drop-shadow()` 滤镜用于创建一个符合元素（图像）本身形状 (alpha 通道) 的阴影。

回到上面这个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/423fc3cb8b4741b78899661650a77b53~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=325&h=311&s=560759&e=gif&f=90&b=18111a)

基于这个代码，只需要给两段 SVG 线条，利用 `drop-shadow()` 添加不同颜色的多重阴影即可：

    .line {
        ...
        --colorA: #f24983;
        filter:drop-shadow(0 0 2px var(--colorA))
            drop-shadow(0 0 5px var(--colorA))
            drop-shadow(0 0 10px var(--colorA))
            drop-shadow(0 0 15px var(--colorA))
            drop-shadow(0 0 25px var(--colorA));
    }
    
    .line2 {
        ...
        --colorB: #37c1ff;
        filter:drop-shadow(0 0 2px var(--colorB))
            drop-shadow(0 0 5px var(--colorB))
            drop-shadow(0 0 10px var(--colorB))
            drop-shadow(0 0 15px var(--colorB))
            drop-shadow(0 0 25px var(--colorB));
    }
    

这样，我们就神奇地给两端线段，加上了动感的光影效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/180cec788120465e942128cb9daa3a98~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=380&h=355&s=4675185&e=gif&f=120&b=1b131e)

> 完整的代码，你可以猛击： [CSS 灵感 - SVG 配合 drop-shadow 实现线条光影效果](https://csscoco.com/inspiration/#/./svg/svg-dropshadow-line-neon-effect.md "https://csscoco.com/inspiration/#/./svg/svg-dropshadow-line-neon-effect.md")

同理，我们再把这个效果也拿出来：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/92e29e8938a14775ac23b99d26c56b3c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=256&h=217&s=157774&e=gif&f=40&b=ffffff)

把这个效果也改造改造，配合 `drop-shadow()`，同时利用滤镜章节中的 `filter: hue-rotate()`，实现这么一个有趣的线条动画，非常适合作为 Loading。

完整的代码，也不多：

    <div class="container">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewbox="-25 -25 150 150">
            <path class="element" d="M43.4,0.2c1.4,1.5,0.9,4,0.2,5.8c2-0.5,3.3-0.7,4.1-2.4
                c0.1,0.2,0.2,0.3,0.2,0.5c0.8,1.3-0.3,3.5,0.7,3.8c1.6,0.6,3.2,1.1,4.8,1.7c3.8-3.3,15.2-6,20.6-2.4c1.3,4.4,2.1,11.5,0.7,16.8
                c-0.6,1.6-1.3,3.2-1.9,4.8c-0.5,3,3.1,8.9,2.2,13.9c-1.4,7.4-6.1,11.1-8.9,15.8c5.3,1,9.1-3.1,16.3-1.7c10.3,2,18.4,13.5,10.6,24
                c-2.2,2.9-8.2,6.5-13.9,5.5c-3.1-0.5-7.2-1.5-10.6-0.7c-6.5,1.6-10.9,7.3-16.8,9.8c-1.9,0.8-7,1.4-9.1,0.2c-0.8-0.4-0.4-1.4-1.7-1.4
                c-1-0.1-6.3-0.3-7.2,0c-1.9,0.6-3.2,2.7-7.4,1.9c-7.7-1.5-12.8-11.4-12.7-20.9c-1,0.7-2.5,2-4.3,1.2c-0.4-0.2-0.8-0.5-1.2-0.7
                c-0.8-2.6,1.9-11,1.9-11c1.3-2.8,4.5-4.2,6.5-6.5c-0.2-0.2-0.5-0.3-0.7-0.5c-8.1-4-17.5-6.2-15.1-20.4c0.6-3,1.3-5.9,1.9-8.9
                C1.9,24.5-3.1,10.1,2.4,6.7c4.8-4.3,16.8,0.9,19.9,2.9c2.1-0.6,4.2-1.3,6.2-1.9c1.5-0.8,2.7-2.6,4.6-3.4C37.7,2.5,41.6,4.7,43.4,0.2
                z" />
        </svg>
    </div>
    

    body {
        background: #000;
    }
    .container {
        animation: colorChange 5s infinite linear;
    }
    .element {
        --colorB: #37c1ff;
        stroke-width: 1;
        stroke: #fff;
        fill: transparent;
        stroke-dasharray: 100, 278;
        animation: lineMove 3s linear infinite;
        filter:drop-shadow(0 0 2px var(--colorB))
            drop-shadow(0 0 4px var(--colorB))
            drop-shadow(0 0 6px var(--colorB))
            drop-shadow(0 0 8px var(--colorB));
    }
    
    @keyframes lineMove {
        0% {
            stroke-dashoffset: 0;
        }
        100% {
            stroke-dashoffset: 378;
        }
    }
    @keyframes colorChange {
        0% {
            filter: hue-rotate(0);
        }
        100% {
            filter: hue-rotate(360deg);
        }
    }
    

最终，可以得到这么一种酷炫的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/26bab314c7c4449fadc725a8896e41ae~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=289&s=434110&e=gif&f=120&b=000000)

怎么样，是不是非常 Amazing？

> 完整的代码，你可以戳这里：[CodePen Demo -- SVG Line Animation](https://codepen.io/Chokcoco/pen/yLQezLZ "https://codepen.io/Chokcoco/pen/yLQezLZ")

不规则路径长度计算
---------

当然，上面的动画效果，都依赖一个非常关键的值，也就是路径的整个周长。因为这个值需要频繁地用于 `stroke-dasharray` 和 `stroke-dashoffset` 的值的计算。

对于规则图形，还能口算一下，但是对于复杂路径，肯定是没办法口算出来的。

那么复杂路径的长度怎么计算？好办，这里借助一段简单的 JavaScript 代码即可以完成：

    <svg>
        <path id="svgpath" d="...">
    </svg>
    

    var obj = document.querySelector("#svgpath");
    var length = obj.getTotalLength();
     
    console.log(length); // 377.0433
    

核心就是 `obj.getTotalLength()` 方法，通过它，我们可以拿到整个路径的周长，再利用这个值去完成各种事情。

总结一下
----

**在** **CSS** **中，借助 SVG 的外力，可以很巧妙地解决很多纯 CSS 无法解决的问题**。

而本文，介绍了一种非常有意思的动画效果 —— SVG 线条动画，并且了解了 SVG 图形与 CSS 之间的桥梁 —— 通过 CSS 样式去控制 SVG 元素的表现这种特殊的方式。

随后，通过 SVG 基础知识入门，逐渐过渡到规则图形的 SVG 路径线条动画、不规则图形的 SVG 路径线条动画的不同实现方式。

最后，配合 `drop-shadow()`，最终让线条动画大放异彩。

总体来说，线条动画是 Web 页面中非常常见的一种动画效果，当然有很多线条动画是 CSS 就能搞定的；而一些复杂的线条动画，借助 SVG 的外力，我们也能比较好地掌控它们。

SVG 其实并不复杂，掌握一些核心常用的用法及基础，能非常好地拓宽我们的解题思路，在遇到各类复杂动画场景的时候，能够拿出不一样的解决方案，还是值得花时间了解学习的！

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
聊完了过渡 transition，我们趁热打铁，继续讲 animation —— **动画**！

CSS 动画介绍及语法
-----------

CSS 动画的完成规范由 [CSS Animations Level 1](https://www.w3.org/TR/2018/WD-css-animations-1-20181011/ "https://www.w3.org/TR/2018/WD-css-animations-1-20181011/") 定义。

什么是 CSS 动画呢？CSS 动画可以实现元素从一个 CSS 样式的配置转换到另一个 CSS 样式配置，也就是实现样式 A 到样式 B 的切换。

在 CSS 中，动画效果的实现通常需要以下两个核心概念。

1.  **`animation` 属性**：用于将动画序列应用到指定的元素上，可以控制动画的各种属性，例如持续时间、循环次数、动画方向等等。
2.  **`@keyframes` 规则**：用于定义动画序列中不同时间点的样式，可以将动画拆分为多个关键帧（keyframe），每个关键帧指定一个时间点和对应的样式。

一个最简单的例子示意：

    div {
        animation: colorChange 2s;
    }
    
    @keyframes colorChange {
        0% {
            color: #f00;
        }
        100% {
            color: #000;
        }
    }
    

1.  `animation: move 2s` 部分就是动画的第一部分，用于描述动画的各个规则；
2.  `@keyframes move {}` 部分就是动画的第二部分，用于指定动画开始、结束以及中间点样式的关键帧。

一个 CSS 动画一定要由上述两部分组成。

上述动画的结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/17d3478527e44e9494270bae807ad2bd~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=220&h=54&s=24817&e=gif&f=103&b=fdfaf7)

接下来，我们会由浅及深逐一介绍 CSS 的几个属性值。

创建动画序列，需要使用 animation 属性或其子属性，该属性允许配置动画时间、时长以及其他动画细节，但该属性不能配置动画的实际表现，动画的实际表现是由 **[@keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 规则实现。

animation 是一个整体的合并写法，当 animation 拆开写的时候，可以分为如下子属性：

*   animation-name：指定由 **[@Keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 描述的关键帧名称。
*   animation-duration：设置动画一个周期的时长。
*   animation-delay：设置延时，即从元素加载完成之后到动画序列开始执行的这段时间。
*   animation-direction：设置动画在每次运行完后是反向运行还是重新回到开始位置重复运行。
*   animation-iteration-count：设置动画重复次数，可以指定 infinite 无限次重复动画。
*   animation-play-state：允许暂停和恢复动画。
*   animation-timing-function：设置动画速度，即通过建立加速度曲线，设置动画在关键帧之间是如何变化。
*   animation-fill-mode：指定动画执行前后如何为目标元素应用样式。
*   animation-composition：指定多个动画的合成方式。

一个动画想要运行，还应该包括 **[@keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 规则，用于指定动画开始、结束以及中间点样式的关键帧。

其中，就上述属性而言，对于一个可运行动画，并非所有属性都要定义，大部分的动画子属性是存在默认值的。

*   **必须项**：`animation-name`、`animation-duration` 和 `@keyframes`规则。
*   **非必须项**：`animation-delay`、`animation-direction`、`animation-iteration-count`、`animation-play-state`、`animation-timing-function`、`animation-fill-mode`、`animation-composition`，当然不是说它们不重要，只是不设置时，它们都有默认值。

这就是一个最基本的 CSS 动画，本文将从 animation 的各个子属性入手，探究 CSS 动画的方方面面。

动画 animation 与过渡 transition 的异同
-------------------------------

动画 animation 和过渡 transition 是 CSS 中两种最常见实现视觉动画效果的实现方式，它们都可以用来改变元素的样式和行为，但是在使用和实现方面存在一些异同。

**相同点：**

1.  CSS 的 animation 和 transition 均能够对元素的样式和行为进行修改，使其产生动态效果。
2.  两者都需要设置初始状态和结束状态，并且在之间进行过渡或动画过程。
3.  用于改善用户体验，增加页面的交互性和吸引力。

**不同点：**

1.  实现方式不同：animation 是通过连续播放多帧图像来实现动态效果，而 transition 则是通过平滑过渡来实现元素样式的变化。
2.  动画方式不同：animation 可以根据关键帧设置进行循环播放、反向播放、暂停等复杂操作，而 transition 只能实现简单的从一种状态到另一种状态的平滑过渡。
3.  触发方式不同：transition 更多的需要通过手动触发，而 animation 不但可以手动触发，也可以默认进行播放。
4.  适用场景不同：animation 更适合用于实现复杂动态效果，如 loading 动画、动态图表等；而 transition 更适用于简单的元素样式变化，如 hover 状态下颜色和大小的变化等。

总的来说，animation 和 transition 都是 CSS 中常用的动态效果实现方式，但是它们在实现方式、动画方式、触发方式和适用场景等方面存在一些不同。在实际应用中，需要根据具体的需求和效果来选择合适的实现方式。

animation-name / animation-duration 详解
--------------------------------------

首先，我们来看看 `animation-name` 和 `animation-duration`。

单个的 `animation-name` 和 `animation-duration` 本身没有太多的技巧性可言，只是我们需要记住，如上面提及到的，一个可运行动画，是一定需要定义 `animation-name` 和 `animation-duration` 的，这两个属性没有默认值。

首先介绍一下 `animation-name`，通过 `animation-name`，CSS 引擎将会找到对应的 **[@keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 规则。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/57f31639f370495c91a4b23bcdf7eade~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=305&h=352&s=32203&e=png&b=1f1f1f)

和 CSS class/id 选择器的规则命名一样，`animation-name` 的命名也存在一些骚操作。

譬如，它是支持 emoji 表情的，所以代码中的 `animation-name` 命名也可以这样写：

    div {
        animation: 😄 2s;
    }
    
    @keyframes 😄 {
        0% {
            color: #f00;
        }
        100% {
            color: #000;
        }
    }
    

`animation-duration` 非常好理解，设置动画的一个周期的运行时长，上述 Demo 中，就是设定动画整体持续 `2s`。

animation-delay 详解
------------------

从 `animation-delay` 开始，动画的子属性就开始存在各式不同的技巧了。

`animation-delay`用于设置动画的延时，即从元素加载完成之后到动画序列开始执行的这段时间。

来看最简单的一个 Demo：

    <div></div>
    <div></div>
    

    div {
        width: 100px;
        height: 100px;
        background: #000;
        animation-name: move;
        animation-duration: 2s;
    }
    
    div:nth-child(2) {
        animation-delay: 1s;
    }
    @keyframes move {
        0% {
            transform: translate(0);
        }
        100% {
            transform: translate(200px);
        }
    }
    

比较下列两个动画，一个添加了 `animation-delay`，一个没有，非常直观：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/68412919ebe640899b41598aa2689f19~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=375&h=268&s=68810&e=gif&f=45&b=ffffff)

可以明显看到，设置了 `animation-duration: 2s` 下面的元素，它的动画运行会延迟 2s 进行。

上述第二个 div，关于 `animation` 属性，也可以简写为 `animation: move 2s 1s`，第一个时间值表示持续时间，第二个时间值表示延迟时间。

### animation-delay 的值可以为负值

这里，我们给出一个关于动画非常重要的技巧：**`animation-delay`** **的值可以为负值。**

也就是说，虽然属性名翻译过来是**动画延迟时间**，但是当值赋予了一负数之后，动画可以**提前进行**。

看个具体的 Demo，假设我们要实现这样一个 loading 动画效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6d486512ee12405e9aaafc9081186db9~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=164&h=135&s=212336&e=gif&f=85&b=fefefe)

如果不使用 GIF 图，而是利用 CSS 实现，有两种不同的可行思路：

1.  初始 3 个球的位置就是间隔 120°，同时开始旋转，但是这样代码量会稍微多一点；
2.  另外一种思路，同一个动画，3 个元素的其中两个延迟整个动画的 1/3，2/3 时间出发。

方案 2 的核心伪代码如下：

    .item:nth-child(1) {
        animation: rotate 3s infinite linear;
    }
    .item:nth-child(2) {
        animation: rotate 3s infinite 1s linear;
    }
    .item:nth-child(3) {
        animation: rotate 3s infinite 2s linear;
    }
    

但是，在动画的前 2s，另外两个元素是不会动的，只有 2s 过后，整个动画才是我们想要的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c38e7eeaeed24029b6cddf8d8868e57c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=164&h=135&s=213272&e=gif&f=101&b=ffffff)

此时，我们可以让第 2、3 个元素的延迟时间，改为负值，这样可以让动画延迟进行 `-1s`、`-2s`，也就是提前进行 `1s`、`2s`：

    .item:nth-child(1) {
        animation: rotate 3s infinite linear;
    }
    .item:nth-child(2) {
        animation: rotate 3s infinite -1s linear;
    }
    .item:nth-child(3) {
        animation: rotate 3s infinite -2s linear;
    }
    

这样，每个元素都无需等待，直接就是运动状态中的，并且元素间隔位置是我们想要的结果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f0233babed9c48379e2584fe95588f5b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=164&h=135&s=212336&e=gif&f=85&b=fefefe)

### 利用 animation-duration 和 animation-delay 构建随机效果

还有一个有意思的小技巧。

同一个动画，我们利用一定范围内随机的 `animation-duration` 和一定范围内随机的 `animation-delay`，可以有效地构建更为随机的动画效果，让动画更加的自然。

我在下述两个纯 CSS 动画中，都使用了这样的技巧：

1.  [纯 CSS 实现华为充电动画](https://codepen.io/Chokcoco/pen/vYExwvm "https://codepen.io/Chokcoco/pen/vYExwvm")：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/367ea57054cc4d6badd359936acf6cea~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=242&h=373&s=587550&e=gif&f=126&b=000000)

2.  [纯 CSS 实现火焰动画](https://codepen.io/Chokcoco/pen/jJJbmz "https://codepen.io/Chokcoco/pen/jJJbmz")：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/71e4b49314b14b7eaea38f479dd66437~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=164&h=284&s=61399&e=gif&f=17&b=000000)

这里以**纯** **CSS** **实现华为充电动画**为例子，简单讲解一下。

仔细观察这一部分，上升的一个一个圆球，抛去这里的一些融合效果，只关注不断上升的圆球，看着像是没有什么规律可言。

我们来模拟一下，如果是使用 10 个 `animation-duration` 和 `animation-delay` 都一致的圆的话，核心伪代码：

    <ul>
      <li></li>
      <!--共 10 个...--> 
      <li></li>
    </ul>
    

    ul {
        display: flex;
        flex-wrap: nowrap;
        gap: 5px;
    }
    li {
        background: #000;
        animation: move 3s infinite 1s linear;
    }
    @keyframes move {
        0% {
            transform: translate(0, 0);
        }
        100% {
            transform: translate(0, -100px);
        }
    }
    

这样，小球的运动会是这样的整齐划一：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e5c8d9a7faa84661a5afb5391d5db3d5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=240&h=144&s=52310&e=gif&f=55&b=fdfcff)

要让小球的运动显得非常的随机，只需要让 `animation-duration` 和 `animation-delay` 都在一定范围内浮动即可，改造下 CSS：

    @for $i from 1 to 11 {
        li:nth-child(#{$i}) {
            animation-duration: #{random(2000)/1000 + 2}s;
            animation-delay: #{random(1000)/1000 + 1}s;
        }
    }
    

我们利用 SASS 的循环和 `random()` 函数，让 `animation-duration` 在 2～4 秒范围内随机，让 `animation-delay` 在 1～2 秒范围内随机，这样，我们就可以得到非常自然且不同的上升动画效果，基本不会出现重复的画面，很好地模拟了随机效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5114966ab86847929e0f3c7997110b09~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=240&h=144&s=297866&e=gif&f=256&b=fdfcff)

> [CodePen Demo -- 利用范围随机 animation-duration 和 animation-delay 实现随机动画效果](https://codepen.io/Chokcoco/pen/JjyRYyR "https://codepen.io/Chokcoco/pen/JjyRYyR")

animation-timing-function 缓动函数
------------------------------

缓动函数在动画中非常重要，它定义了动画在每一动画周期中执行的节奏。

缓动主要分为两类：

1.  cubic-bezier-timing-function，三次贝塞尔曲线缓动函数；
2.  step-timing-function，步骤缓动函数（这个翻译是我自己翻的，可能有点奇怪）。

### 三次贝塞尔曲线缓动函数

首先看看**三次贝塞尔曲线缓动函数**。在 CSS 中，支持一些缓动函数关键字：

    /* Keyword values */
    animation-timing-function: ease; // 动画以低速开始，然后加快，在结束前变慢 
    animation-timing-function: ease-in; // 动画以低速开始 
    animation-timing-function: ease-out; // 动画以低速结束 
    animation-timing-function: ease-in-out; // 动画以低速开始和结束 
    animation-timing-function: linear; // 匀速，动画从头到尾的速度是相同的
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4c84a315a2d4426d8618036e485fcca6~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=579&h=136&s=13901&e=png&b=ececec)

关于它们之间的效果对比：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/41821fe94a7543ab81bb5039ee637bcf~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=360&h=365&s=124807&e=gif&f=96&b=fcfbf8)

除了 CSS 支持的这 5 个关键字，我们还可以使用 `cubic-bezier()` 方法自定义三次贝塞尔曲线：

    {
        animation-timing-function: cubic-bezier(0.1, 0.7, 1.0, 0.1);
    }
    

这里有个非常好用的网站 —— [cubic-bezier](https://cubic-bezier.com/#.25,.1,.25,1 "https://cubic-bezier.com/#.25,.1,.25,1") 用于创建和调试生成不同的贝塞尔曲线参数。

### 三次贝塞尔曲线缓动对动画的影响

关于缓动函数对动画的影响，这里有一个非常好的示例。

这里我们使用纯 CSS 实现了一个钟的效果，对于其中动画的运动，如果是 `animation-timing-function: linear`，效果如下：

![bg1.gif](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/abaf2667b5c64bc185d363ce8b6ebf5e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=164&s=1406044&e=gif&f=127&b=1e1b1e)

而如果我们把缓动函数替换一下，变成 `animation-timing-function: cubic-bezier(1,-0.21,.85,1.29)`，它的曲线对应如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/100ce448fcad488196eb9ce9de9b146c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=555&h=416&s=36894&e=png&b=fafafa)

整个钟的动画律动效果将变成这样，完全不一样的感觉：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b3b1d057c4904d3baccbe3fadf6cd691~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=164&s=1441668&e=gif&f=147&b=1e1b1e)

> 完整代码，戳这里： [CodePen Demo - 缓动不同效果不同](https://codepen.io/Chokcoco/pen/JjyxLMY "https://codepen.io/Chokcoco/pen/JjyxLMY")

对于许多精益求精的动画，在设计中其实都考虑到了缓动函数。我很久之前看到过一篇《基于物理学的动画用户体验设计》（可惜如今已经无法找到原文），其中传达出的一些概念是，动画的设计依据实际在生活中的表现去考量。

譬如 linear 这个缓动，实际应用于某些动画中会显得很不自然，因为由于空气阻力的存在，程序模拟的匀速直线运动在现实生活中是很难实现的。因此，对于这样一个用户平时很少感知到的运动是很难建立信任感的。这样的匀速直线运动也是我们在进行动效设计时需要极力避免的。

### 步骤缓动函数

接下来再讲讲步骤缓动函数。在 CSS 的 `animation-timing-function` 中，它有如下几种表现形态：

    {
        /* Keyword values /animation-timing-function: step-start; animation-timing-function: step-end;  / Function values */
        animation-timing-function: steps(6, start)
        animation-timing-function: steps(4, end);
    }
    

在 CSS 中，使用步骤缓动函数最多的，就是利用其来实现逐帧动画。假设我们有这样一张图（图片大小为 `1536 x 256`，图片来源于网络）：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7f270a29f42a4786b9d9027a918b9054~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1536&h=256&s=137461&e=png&a=1&b=090909)

可以发现它其实是一个人物行进过程中的 6 种状态，或者可以为 6 帧，我们利用 `animation-timing-function: steps(6)` 可以将其用一个 CSS 动画串联起来，代码非常的简单：

    <div class="box"></div>
    

    .box {
      width: 256px;
      height: 256px;
      background: url('https://github.com/iamalperen/playground/blob/main/SpriteSheetAnimation/sprite.png?raw=true');
      animation: sprite .6s steps(6, end) infinite;
    }
    @keyframes sprite {
      0% { 
        background-position: 0 0;
      }
      100% { 
        background-position: -1536px 0;
      }
    }
    

简单解释一下上述代码，首先要知道，刚好 `256 x 6 = 1536`，所以上述图片其实可以刚好均分为 6 段：

1.  我们设定了一个大小都为 `256px` 的 div，给这个 div 赋予了一个 `animation: sprite .6s steps(6) infinite` 动画；
2.  其中 `steps(6)` 的意思就是将设定的 **[@Keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 动画分为 6 次（6 帧）执行，而整体的动画时间是 `0.6s`，所以每一帧的停顿时长为 `0.1s`；
3.  动画效果是由 `background-position: 0 0` 到 `background-position: -1536px 0`，由于上述的 CSS 代码没有设置 `background-repeat`，所以其实 `background-position: 0 0` 是等价于 `background-position: -1536px 0`，就是图片在整个动画过程中推进了一轮，只不过每一帧停在了特定的地方，一共 6 帧。

将上述 1、2、3 这 3 个步骤画在图上简单示意：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3e999061bd974a59971ecb7d36faa59c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1812&h=454&s=259408&e=png&b=fdfbfb)

从上图可知，在动画过程中，`background-position` 的取值其实只有 `background-position: 0 0`、`background-position: -256px 0`、`background-position: -512px 0` ……依次类推一直到 `background-position: -1536px 0`，由于背景的 repeat 的特性，其实刚好回到原点，由此又重新开始新一轮同样的动画。

所以，整个动画就会是这样，每一帧停留 0.1s 后切换到下一帧（注意这里是个无限循环动画）：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/93765cfa0f5b4511b3bfc7f1e1223b78~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=273&h=247&s=368352&e=gif&f=33&b=fcf7f7)

> 完整的代码，你可以戳这里： [CodePen Demo -- Sprite Animation with steps()](https://codepen.io/Chokcoco/pen/JjrBqJZ "https://codepen.io/Chokcoco/pen/JjrBqJZ")

### animation-duration 动画长短对动画的影响

在这里再插入一个小章节，`animation-duration` 动画长短对动画的影响也是非常明显的。

在上述代码的基础上，我们再修改 `animation-duration`，缩短每一帧的时间就可以让步行的效果变成跑步的效果；同理，也可以增加每一帧的停留时间，让每一步变得缓慢，就像是在步行一样。

> 需要提出的是，上文说的每一帧，和浏览器渲染过程中的 FPS 的每一帧不是同一个概念。

看看效果，设置不同的 `animation-duration` 的效果（这里是 0.6s -> 0.2s），GIF 录屏丢失了一些关键帧，实际效果会更好点：

![bg2.gif](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/09ed2b25e1b741d6970b995d73900c65~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=256&h=225&s=1432481&e=gif&f=128&b=fcf7f7)

### 复杂的 `steps` 语法

在逐帧动画的关键字 `steps()` 中，还有一些有意思的细节。

譬如，如下几种不同的 `steps()` 语法：

1.  `steps(6)`；
2.  `steps(6, start)`；
3.  `steps(6, end)`；
4.  `steps(6, jump-start)`；
5.  `steps(6, jump-end)`；
6.  `steps(6, jump-none)`；
7.  `steps(6, jump-both)`。

其核心就在于控制动画的关键帧如何进行跳跃，尤其是对动画首尾的一些处理上，经常容易出现问题。其中：

*   **`jump-start`** **与** **`start`** **的作用类似：** 表示第一次跳跃发生在动画开始时。
*   **`jump-end`** **与** **`end`** **作用类似：** 表示最后一次跳转发生在动画结束时。
*   **`jump-none`** **：** 它将对象保持在 0% 标记和 100% 标记处，每个持续时间的 1/n。
*   **`jump-both`** **：** 包括在 0% 和 100% 标记处的暂停，有效地在动画迭代期间添加一个步骤。

当我们实际需要使用 `steps()` 语法去控制动画的时候，当遇到首尾动画衔接、首尾动画停留问题，通常都可以借助以上的一些关键字解决。

### 同个动画效果的补间动画和逐帧动画演绎对比

上述的三次贝塞尔曲线缓动和步骤缓动，其实就是对应的补间动画和逐帧动画。

对于同个动画而言，有的时候两种缓动都是适用的。我们在具体使用的时候需要具体分析选取。

假设我们用 CSS 实现了这样一个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f1b38bfc8d1b48c2b9e64bb3170f9d42~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=281&h=286&s=5887&e=png&b=000000)

现在想利用这个图形制作一个 Loading 效果，如果利用补间动画，也就是三次贝塞尔曲线缓动的话，让它旋转起来，得到的效果非常的一般：

    .g-container{
        animation: rotate 2s linear infinite;
    }
    @keyframes rotate {
        0% {
            transform: rotate(0);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    

动画效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8195da99275d4336aae309765027b1f7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=281&h=267&s=281536&e=gif&f=79&b=000000)

但是如果这里，我们将补间动画换成逐帧动画，因为有 20 个点，所以设置成 steps(20)，再看看效果，会得到完全不一样的感觉：

    .g-container{
        animation: rotate 2s steps(20) infinite;
    }
    @keyframes rotate {
        0% {
            transform: rotate(0);
        }
        100% {
            transform: rotate(360deg);
        }
    }
    

动画效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ec1f86f790134032ac5bad02bcb6d2c0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=281&h=267&s=67528&e=gif&f=21&b=000000)

整个 loading 的圈圈看上去好像也在旋转，实际上只是 20 帧关键帧在切换，整体的效果感觉更适合 Loading 的效果。

因此，两种动画效果都是很有必要掌握的，在实际使用的时候灵活尝试，选择更适合的。

> 上述 Demo 效果完整的代码：[CodePen Demo -- Scale Loading steps vs linear](https://codepen.io/Chokcoco/pen/oNGMROO "https://codepen.io/Chokcoco/pen/oNGMROO")

animation-play-state
--------------------

接下来，我们讲讲 `animation-play-state`，顾名思义，它可以控制动画的状态 —— 运行或者暂停，类似于视频播放器的开始和暂停。这是 CSS 动画中有限的控制动画状态的手段之一。

它的取值只有两个（默认为 running）：

    {
        animation-play-state: paused | running;
    }
    

使用起来也非常简单，看下面这个例子，我们在 hover 按钮的时候，实现动画的暂停：

    <div class="btn stop">stop</div>
    <div class="animation"></div>
    

    .animation {
        width: 100px;
        height: 100px;
        background: deeppink;
        animation: move 2s linear infinite alternate;
    }
    
    @keyframes move {
        100% {
            transform: translate(100px, 0);
        }
    }
    
    .stop:hover ~ .animation {
        animation-play-state: paused;
    }
    

一个简单的 CSS 动画，但是当我们 hover 按钮的时候，给动画元素添加上 `animation-play-state: paused`：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c0915acbe87241fd8d3da64974697f3f~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=331&h=202&s=196127&e=gif&f=157&b=ffffff)

理解了上述效果后，我们尝试反其道而行之，利用它来创造一些有意思的 CSS 动画效果。

举个例子，正常情况下，动画应该是运行状态，那如果我们将一些动画的默认状态设置为暂停，只有当鼠标点击或者 hover 的时候，才设置其 `animation-play-state: running`，这样就可以得到很多有趣的 CSS 效果。

看个倒酒的例子，这是一个纯 CSS 动画，但是默认状态下，动画处于 `animation-play-state: paused`，也就是暂停状态，只有当鼠标点击杯子的时候，才设置 `animation-play-state: running`，让酒倒下，利用 `animation-play-state` 实现了一个非常有意思的交互效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ae026d1a1eb84e5a8369899531bc2d3e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=343&h=444&s=2093428&e=gif&f=178&b=040404)

> 完整的 Demo，你可以戳这里：[CodePen Demo -- CSS Beer!](https://codepen.io/mikegolus/pen/jJzRwJ "https://codepen.io/mikegolus/pen/jJzRwJ")

在非常多 Web 创意交互动画中我们都可以看到这个技巧的身影。

1.  页面 render 后，无任何操作，动画不会开始。只有当鼠标对元素进行 `click` ，通过触发元素的 `:active` 伪类效果的时候，赋予动画 `animation-play-state: running`，动画才开始进行。
2.  动画进行到任意时刻，鼠标停止点击，伪类消失，则动画停止。

animation-fill-mode 控制元素在各个阶段的状态
--------------------------------

`animation-fill-mode` 属性，意为设置 CSS 动画在执行之前和之后如何将样式应用于其目标。

常见的一个认知误区在于认为这个属性仅仅是用于控制元素在动画结束后是否复位。

但是这个认识其实是不准确、不够全面的。首先，看看这个属性的取值：

1.  `animation-fill-mode: none`：默认值，当动画未执行时，动画将不会将任何样式应用于目标，而是使用赋予给该元素的 CSS 规则来显示该元素的状态。
2.  `animation-fill-mode: backwards`：动画将在应用于目标时立即应用第一个关键帧中定义的值，并在 animation-delay 期间保留此值。
3.  `animation-fill-mode: forwards`：目标将保留由执行期间遇到的最后一个关键帧计算值。 最后一个关键帧取决于 animation-direction 和 animation-iteration-count。
4.  `animation-fill-mode`：动画将遵循 forwards 和 backwards 的规则，从而在两个方向上扩展动画属性。

    {
        animation-fill-mode: none;
        animation-fill-mode: backwards; 
        animation-fill-mode: forwards;    
        animation-fill-mode: both; 
    }
    

对于 `animation-fill-mode` 的解读，我在 Segment Fault 上的一个问答中（[SF - 如何理解 animation-fill-mode](https://segmentfault.com/q/1010000003867335 "https://segmentfault.com/q/1010000003867335")）看到了 4 副很好的解读图，这里借用一下：

假设 HTML 如下：

    <div class="box"></div>
    

CSS 如下：

    .box{
        transform: translateY(0);
    }
    .box.on{
        animation: move 1s;
    }
    
    @keyframes move{
        from{transform: translateY(-50px)}
        to  {transform: translateY( 50px)}
    }
    

使用图片来表示 `translateY` 的值与**时间**的关系：

*   横轴表示**时间**，为 0 时表示动画开始的时间，也就是向 box 加上 on 类名的时间，横轴一格表示 0.5s；
*   纵轴表示 `translateY` 的值，为 0 时表示 `translateY` 的值为 0，纵轴一格表示 `50px`。

1.  `animation-fill-mode: none` 表现如图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0e4dfd5b71c646cf9620bae9ea5acd16~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=350&s=11740&e=png&b=ffffff)

一句话总结，元素在动画时间之外，样式只受到它的 CSS 规则限制，与 **[@Keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 内的关键帧定义无关。

2.  `animation-fill-mode: backwards` 表现如图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6cab5c7f5d704152a8b392c5a431b89c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=350&s=11230&e=png&b=ffffff)

一句话总结，元素在动画开始之前（包含未触发动画阶段及 `animation-delay` 期间）的样式为动画运行时的第一帧，而动画结束后的样式则恢复为 CSS 规则设定的样式。

3.  `animation-fill-mode: forwards` 表现如图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/df8bd6d55b6a4bcbbb415cc73a68c7a9~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=350&s=11274&e=png&b=ffffff)

一句话总结，元素在动画开始之前的样式为 CSS 规则设定的样式，而动画结束后的样式则表现为由执行期间遇到的最后一个关键帧计算值（也就是停在最后一帧）。

4.  `animation-fill-mode: both` 表现如图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/122bbff1e482438a8648648041b6b4c3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=350&s=10570&e=png&b=ffffff)

一句话总结，综合了 `animation-fill-mode: backwards` 和 `animation-fill-mode: forwards` 的设定。动画开始前的样式为动画运行时的第一帧，动画结束后停在最后一帧。

这里，我还制作了一个动画效果，以帮助大家进一步理解 `animation-fill-mode` 的各个状态。

在此效果中，一共有 3 种状态：

1.  动画的 `@keyframes` 关键帧之外，有给元素设置默认的 `left: -40px`；
2.  动画的 `@keyframes` 关键帧的 `0%`，给元素设置默认的 `left: 0`；
3.  动画的 `@keyframes` 关键帧的 `100%`，给元素设置默认的 `left: 100%`。

了解了这个之后，再看看下述的关于 `animation-fill-mode` 的演示效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d697b41a14ca41f9be81d3e7ec7fc036~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=650&h=474&s=187494&e=gif&f=146&b=f5f4f2)

> 完整的演示 Demo，你可以戳这里：[CodePen Demo - animation fill mode Demo](https://codepen.io/Chokcoco/pen/vYVzKOm "https://codepen.io/Chokcoco/pen/vYVzKOm")

这里的核心，在于理解动画的初始状态和结束状态，是如何被 `animation-fill-mode` 给影响的。

核心观察动画初始及结束状态下，元素的位置：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c69f7018c0a7429085fed38134ebb4d1~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1130&h=582&s=71670&e=png&b=fbfbfb)

配合上面的四张图，记住核心的两点结论：

1.  **backwards、both** 会影响动画的初始状态；
2.  **forwards、both** 会影响动画的结束状态。

animation-iteration-count/animation-direction 动画循环次数和方向
-------------------------------------------------------

讲到了 `animation-fill-mode`，我们就可以顺带讲讲这两个比较好理解的属性：`animation-iteration-count` 和 `animation-direction`。

*   `animation-iteration-count` 控制动画运行的次数，可以是数字或者 `infinite`，注意，数字可以是小数。
*   `animation-direction` 控制动画的方向，正向、反向、正向交替与反向交替。

在上面讲述 `animation-fill-mode` 时，我使用了**动画运行时的第一帧**替代了 **[@Keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 中定义的第一帧这种说法，因为动画运行的第一帧和最后一帧的实际状态还会受到动画运行方向 `animation-direction` 和 `animation-iteration-count` 的影响。

在 CSS 动画中，由 `animation-iteration-count` 和 `animation-direction` 共同决定动画运行时的第一帧和最后一帧的状态。

1.  动画运行的第一帧由 `animation-direction` 决定。
2.  动画运行的最后一帧由 `animation-iteration-count` 和 `animation-direction` 决定。

动画的最后一帧，也就是动画运行的最终状态，并且我们可以利用 `animation-fill-mode: forwards` 让动画在结束后停留在这一帧，这个还是比较好理解的，但是 `animation-fill-mode: backwards` 和 `animation-direction` 的关系很容易弄不清楚，这里简单讲解下。

设置一个 `100px x 100px` 的滑块，在一个 `400px x 100px` 的容器中，其代码如下：

    <div class="g-father">
        <div class="g-box"></div>
    </div>
    

    .g-father {
        width: 400px;
        height: 100px;
        border: 1px solid #000;
    }
    .g-box {
        width: 100px;
        height: 100px;
        background: #333;
    }
    

表现如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cbb2e6492b9c4591b5f24ac00e426023~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=468&h=143&s=711&e=png&b=ffffff)

那么，加入 `animation` 之后，在不同的 `animation-iteration-count` 和 `animation-direction` 作用下，动画的初始和结束状态都不一样。

如果设置了 `animation-fill-mode: backwards`，则元素在动画未开始前的状态由 `animation-direction` 决定：

    .g-box {
        ...
        animation: move 4s linear;
        animation-play-state: paused;
        transform: translate(0, 0);
    }
    @keyframes move {
        0% {
            transform: translate(100px, 0);
        }
        100% {
            transform: translate(300px, 0);
        }
    }
    

注意这里 CSS 规则中，元素没有设置位移 `transform: translate(0, 0)`，而在动画中，第一个关键帧和最后一个关键的 translateX 分别是 `100px`、`300px`，配合不同的 `animation-direction` 初始状态如下。

下图假设我们设置了动画默认是暂停的 —— `animation-play-state: paused`，那么动画在开始前的状态为：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/374f039e669e45fc96e4246b213e31a7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1620&h=328&s=38459&e=png&b=ffffff)

keyframes 规则的设定
---------------

我们经常能够在各种不同的 CSS 代码中见到如下两种 CSS `@keyframes` 的设定。

1.  使用百分比：

    @keyframes fadeIn {
        0% {
            opacity: 1;
        }
        100% {
            opacity: 0;
        }
    }
    

2.  使用 `from` 及 `to`：

    @keyframes fadeIn {
        from {
            opacity: 1;
        }
        to {
            opacity: 0;
        }
    }
    

在 CSS 动画 `@keyframes` 的定义中，`from` 等同于 `0%`，而 `to` 等同于 `100%`。

当然，当我们的关键帧不止 2 帧的时候，更推荐使用百分比定义的方式。

除此之外，当动画的起始帧等同于 CSS 规则中赋予的值并且没有设定 `animation-fill-mode`，`0%` 和 `from` 这一帧是可以删除的。

本章总结
----

在本章中，我们详细介绍了 CSS animation 的各个属性，它们分别是：

*   animation-name：指定由 **[@Keyframes](https://github.com/Keyframes "https://github.com/Keyframes")** 描述的关键帧名称。
*   animation-duration：设置动画一个周期的时长。
*   animation-delay：设置延时，即从元素加载完成之后到动画序列开始执行的这段时间。
*   animation-direction：设置动画在每次运行完后是反向运行还是重新回到开始位置重复运行。
*   animation-iteration-count：设置动画重复次数， 可以指定 infinite 无限次重复动画。
*   animation-play-state：允许暂停和恢复动画。
*   animation-timing-function：设置动画速度， 即通过建立加速度曲线，设置动画在关键帧之间是如何变化。
*   animation-fill-mode：指定动画执行前后如何为目标元素应用样式。

并且，还介绍了这些属性在 CSS animation 的实际运用中的一些技巧。当然，本文仅仅只是刚刚揭开了 CSS 动画神秘的一角。在下一章中，我们仍将继续我们的动画旅程，深入到对动画的更高层次的理解之上！

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
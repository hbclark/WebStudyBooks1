本章，我们进入过渡与动画的章节。在 CSS 中，过渡与动画扮演了非常重要的角色，同时也存在着非常多有意思的技巧。而本章，我们的主角是 —— **transition 过渡**。

CSS 中，transition 属性用于指定为一个或多个 CSS 属性添加过渡效果。以控制元素的某个属性值从状态 A 经由动画效果，变化到状态 B。

通过一个最常见的例子快速入门：

    <div></div>
    

    div {
        width: 140px;
        height: 64px;
        transition: transform 1s linear 0s;
    }
    div:hover {
        transform: translate(120px, 0);
    }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8a693fbc75fa4545ab8e5ad63c5deadb~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=493&h=79&s=63723&e=gif&f=53&b=ffffff)

如果不设置 `transition: 1s transform linear 0s`，那么将会是这么一个效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/95ecd158e89a41e088874fe143a8f995~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=80&s=12785&e=gif&f=104&b=fdfcff)

对比一下，可以快速理解 `transition` 的作用。

transition 基础讲解
---------------

我们首先快速过一下 transition 相关的基础内容。

基于上面的 Demo，有这么一句核心的语句 `transition: transform 1s linear 0s`，这一句其实是 transition 整个语法的缩写形式，代表了：

*   `transition-property`：过渡属性，指定应用过渡属性的名称；
*   `transition-duration`：过渡持续时间，指定过渡动画持续的时间；
*   `transition-timing-function`：过渡缓动，指定过渡动画过程中的缓动函数；
*   `transition-delay`：过渡延迟，指定过渡动画延迟多久才被触发。

对应关系如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/071d3d936e6b4c1ebbe6ed30a012195c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=2342&h=406&s=121830&e=png&b=fefefe)

对于这 4 个属性，有一些需要注意的细节点。

### 可以通过关键字 `all` 给所有属性设置过渡

在 transition 中，我们可以使用如下所示代码，统一给元素下面的所有支持过渡的属性添加过渡效果：

    div {
        transition: all 1s linear;
    }
    

这里有一个很重要的关键字：`all`。`all` 是 `transition-property` 的一个特殊的值。指定 `all` 时，元素下任何支持过渡的属性都将被赋予过渡效果。

这个值很方便，如果需要设置的过渡效果的属性非常多，那么它的确是一个非常好的简化写法。

当然，也有一类声音反对使用 `all`，原因是后期对代码的维护过程中，如果出现一个属性不需要过渡效果，那么需要重写整段 `transition` 代码，并且很有可能造成遗漏。

### transition 支持多个属性的精细化控制

因此，如果我们不想使用 `all`，亦或者不同属性的过渡时间或缓动函数不一致，`transition` 也是支持多个属性的精细化控制的。

我们可以分别精细化控制每一个属性：

    {
        // 可以这样
        transition: all 1s linear;
    
        // 也可以这样
        transition: 
            height 1s linear, 
            transform 0.5s,
            color 2s ease-in-out 0.5s;
    }
    

如上述代码所示，我们可以在 `transition` 的描述中，一次精细化地定义多个不同的过渡效果。分别设置不同的过渡时长、缓动效果以及延迟时间。

> 如果没有延迟时间，最后一个 0s 可以省去。同理，过渡的缓动函数默认是 ease，如果希望缓动是 ease，则 ease 关键字也可以省略（ease：规定过渡先缓慢地开始，然后加速，然后缓慢地结束）。

### 过渡效果支持延迟加载

与 CSS 的 Animation 一样，过渡也是支持延迟触发的，通过 `transition-delay` 的设置。

看个最简单的例子：

    div {
        // 延迟 1s 触发过渡，过渡动画的时间为 0.8 秒
        transition: .8s transform 1s linear;
    }
    div:hover {
        transform: translate(120px, 0);
    }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/14b41caaf7cf4257ab1c76d0ad80c6b8~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=493&h=79&s=46762&e=gif&f=40&b=ffffff)

可以看到，不管是过渡触发，还是过渡复位，都会等待 1 秒再触发。

灵活使用 `transition-delay` 能够创造出许多非常有意思的效果。这个我们在下文会详细讲解。

### 并非所有元素都是支持过渡动画的

接下来这一点非常重要。并非所有属性都支持过渡变化，通常情况下，能够进行过渡动画的属性包括颜色、背景色、字体大小、位置、尺寸等等。以下是一个不支持过渡动画的元素的例子：

    <div>Lorem</div>
    

    div {
        font-family: Arial;
        transition: font-family 1s linear;
    }
    div:hover {
        font-family: Microsoft Yahei;
    }
    

如果我们的设备同时支持 `Arial` 和 `Microsoft Yahei` 两种字体，即便设置了 `transition: font-family 1s linear`，在 hover 元素的过程中，也不会出现字体的过渡动画变化，而是一瞬间的跳变。这是由于 `font-family` 是不支持过渡变化的属性之一！

这里有一个列表，列出了所有支持 transition 的属性 —— [CSS animated properties](https://developer.mozilla.org/zh-CN/docs/Web/CSS/CSS_animated_properties "https://developer.mozilla.org/zh-CN/docs/Web/CSS/CSS_animated_properties")。

在快速过了一遍基础后，我们将开始挖掘过渡的一些进阶使用技巧。

合理使用过渡，提升用户体验
-------------

首先，过渡效果最为常见的场景，在于一些交互效果当中。

丝滑的过渡效果比起突兀的切换效果而言，通常能给用户以更好的体验。

看下面两个例子：

    .g-button:hover {
        background: #ff0089;
    }
    .g-button:active {
        background: #71003c;
    }
    .g-circle:hover {
        transform: translate(0, -20px);
    }
    .s-transition {
        transition: background .5s,
                    transform .3s;
    }
    

我们给左边的元素添加上过渡效果，而右边的元素没有过渡效果，演示结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5353922f7b8049db96605336a7944e8a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=314&s=183541&e=gif&f=160&b=fdfbf9)

上面就是最常见的过渡使用场景，在恰当的交互场景下，合理使用过渡，能够有效提升用户体验。

不要将 auto 值应用于过渡动画
-----------------

MDN 上关于过渡效果，有一个非常好的知识点，那就是关于 `auto` 值，`auto` 值常常较复杂，规范指出不要在它上进行动画与过渡。一些用户代理，比如基于 Gecko 内核相关浏览器，是遵循这点的；而另外一些浏览器，比如基于 WebKit 的，则没有这么严格限制。在 `auto` 上进行的动画结果可能不会符合预期，这取决于浏览器及其版本，因此我们应当避免使用。

在文章上面，我们其实有提到，**并非所有元素都是支持过渡动画的。**

有的时候，还有更例外的。某些支持 transition 的属性在某些特定状态下，也是不支持 transition 的。非常典型的就是 `height: auto` 和 `width: auto`。

我们来看这样一个场景，我们希望实现一个元素高度的过渡动画，伪代码大概是这样：

    {
        height: unset;
        transition: height 0.3s linear;
    
        &.up {
            height: 0;
        }
        &.down {
            height: unset;
        }
    }
    

这里，我们虽然给 `height` 属性设置了 `transition`，但是过渡动画没有触发，展开的动画是直接一步到位展开的，效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6545a324a2904a139fe57e406f108858~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=234&h=254&s=34104&e=gif&f=21&b=ffffff)

原因在于， **CSS** **transtion 不支持元素的高度或者宽度为 auto 的变化**。

当然，对于这种场景，也并非没有解。我们可以使用 `max-height` 的偏方进行另外一种方式的过渡。

这个技巧非常有意思，既然过渡不支持 `height: auto`，那我们就另辟蹊径，利用 `max-height` 的特性来实现动态高度的伸缩，譬如：

    {
        max-height: 0;
        transition: max-height 0.3s linear;
    
        &.up {
            max-height: 0;
        }
        &.down {
            max-height: 1000px;
        }
    }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9c885906c30c448cabdc6126938311e9~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=573&h=181&s=55583&e=gif&f=40&b=ffffff)

当然，这里虽然解决了动画效果，但是会造成无法完美控制过渡的动画时长，不过这就不属于本章节的内容了，如果你对动态高度动画感兴趣，可以继续阅读：[CSS 奇技淫巧：动态高度过渡动画](https://github.com/chokcoco/iCSS/issues/91 "https://github.com/chokcoco/iCSS/issues/91") 以及 [CSS 如何让 auto height 完美支持过渡动画？](https://juejin.cn/post/7196843994030342200 "https://juejin.cn/post/7196843994030342200")。

巧用多层元素，解决交互闪烁问题
---------------

当然，在使用过渡的过程中，我们可能会遇到一些小问题。

看下面这个场景：

    <div class="g-circle">Hello CSS</div>
    

    .g-circle {
        transition: transform .3s;
    }
    .g-circle:hover {
        transform: translate(0, -20px);
    }
    

还是上面的例子，我们设置了一个元素，给它赋予了 `transform` 相关的过渡效果设置，当元素被 `hover` 的时候，元素向上位移 `20px`，如果代码仅仅是这样，当我们从元素的下方 `hover` 元素的时候，可能会出现这样的情况：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/769c33def64840e2ace63889c1c448b5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=200&h=169&s=318800&e=gif&f=155&b=faf8fd)

为什么会存在这种抖动的情况？

这是由于元素的初始态和 `hover` 状态下的终态，元素的位置发生了变化，中间存在 `20px` 高度差，当鼠标从下方 `hover` 上去的时候，触发了元素向上位移的过渡动画，元素在向上位移的过程中，鼠标很有可能会失去元素的焦点，导致元素失去 `hover` 状态，此时元素就会回归本位，在回归的过程中鼠标又能重新获得元素的焦点……如此反复，就导致了整个元素的抖动！

那么如何有效解决这个问题呢？**那就是** **`hover`** **目标元素与最终运动元素分离**。

通过多叠加一层元素，我们将 `hover` 的目标从运动元素上转移到父元素上，父元素不会参与 `transform` 变换，因此不会出现元素的焦点选区发出变化的情形，自然也就不会出现抖动的现象。

改造一下，代码如下：

    <div class="g-container">
        <div class="g-circle">Hello CSS</div>
    </div>
    

    .g-circle {
        transition: transform .3s;
    }
    .g-container:hover .g-circle {
        transform: translate(0, -20px);
    }
    

对比一下效果，差异非常明显：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dfb0ff0ecfe14833a79b239d5b87cfd7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=450&h=214&s=322253&e=gif&f=226&b=fbfafe)

核心的点在于，我们是通过触发父元素的 `hover` 控制子元素的样式变化，父元素本身的位置是不会发生变化的。

也就是需要理解从 `.g-circle:hover {}` 到 `.g-container:hover .g-circle {}` 的变化。

> 完整的代码，你可以戳这里：[CodePen Demo -- transition hover Demo](https://codepen.io/Chokcoco/pen/xxypBEm?editors=1100 "https://codepen.io/Chokcoco/pen/xxypBEm?editors=1100")

巧用延迟过渡，让内容保持状态
--------------

接下来，我们看看过渡延迟 `transition-delay`。

和动画 Animation 类似，每一个过渡都是支持延迟触发的：

    div {
        // 延迟 1s 触发过渡，过渡动画的时间为 0.8 秒
        transition: .8s transform 1s linear;
    }
    div:hover {
        transform: translate(120px, 0);
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/25b1f4e4484941239148ed6d28ba6e5e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=493&h=79&s=46762&e=gif&f=40&b=ffffff)

可以看到，不管是过渡的触发，还是过渡的复位，都会等待 1 秒再进行。

那什么时候会运用到过渡延迟呢？有哪些具体的应用场景？

我们来看这么一个具体场景，在按钮的旁边，有一个菜单，每次 hover 按钮的时候，菜单就会出现：

    <div class="g-container">
        <div class="g-button">
            Button
            <ul>
                <li>>> Lorem, ipsum dolor sit amet?</li>
                <li>>> Lorem, ipsum dolor sit amet?</li>
                <li>>> Lorem, ipsum dolor sit amet?</li>
                <li>>> Lorem, ipsum dolor sit amet?</li>
            </ul>
        </div>
    </div>
    

    .g-container {
        position: relative;
    }
    .g-button {
        width: 120px;
        height: 40px;
    }
    ul {
        position: absolute;
        left: 124px;
        opacity: 0;
    }
    .g-button:hover ul {
        opacity: 1;
    }
    

实际的交互效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fb28ba52f2314ca392d60933f5bb9529~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=450&h=218&s=108959&e=gif&f=145&b=fdfcff)

每次当我们的鼠标想去到菜单界面的时候，由于我们的鼠标离开了按钮区域，导致出现了的菜单又消失不见。

因此，在类似于这种情形下，使用 `transition-delay` 延迟菜单的消失，就是一种非常好的做法。

要知道，`transition-delay` 可以作用于过渡动画的触发和复位。当然，这里还有一点，当鼠标 `hover` 到 Button 的时候，我们是希望菜单马上出现的，只有当鼠标离开按钮，菜单才会延缓消失。因此，这里我们还需要对 `hover` 和 `非 hover` 状态的 `transition-delay` 进行区别处理。

代码如下：

    ul {
        opacity: 0;
        transition: all .3s;
        transition-delay: 1s;
    }
    .g-button:hover ul {
        opacity: 1;
        transition-delay: 0s;
    }
    

这里，分为两个状态去理解：

1.  当鼠标 hover 到按钮，触发 `hover` 伪类，元素的 `transition-delay` 设置为了 `0s`，`opacity` 过渡动画会立即触发，因此菜单会立即显现；
2.  而当鼠标离开 Button 按钮，`hover` 伪类失效，此时元素的 `transition-delay` 设置为了 `1s`，所以菜单会等待 1 秒之后才进行复位过渡动画，因此菜单不会立即消失。

整体效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/26fff04d778445f2a4543a19995764ce~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=450&h=218&s=232282&e=gif&f=157&b=fdfcff)

巧用延迟过渡，实现多段过渡动画的组合
------------------

当然，延迟过渡不仅仅只能用于上述的交互场景。

巧妙使用延迟过渡，我们还可以实现一系列有意思的动画效果。

首先，我们实现这样一个宽高变化的过渡动画：

    <div></div>
    

    div {
        position: relative;
        width: 200px;
        height: 64px;
        box-shadow: inset 0 0 0 3px #ddd;
    }
    div::before {
        content: "";
        position: absolute;
        width: 0;
        height: 0;
        top: 0; left: 0; width: 0; height: 0;
        box-sizing: border-box;
        transition: height .25s, width .25s, border-bottom-color .25s;
        transition-delay: 0s, .25s, .25s;
    }
    div:hover::before {
        width: 200px;
        height: 64px;
        border-left: 3px solid #00e2ff;
        border-bottom: 3px solid #00e2ff;
    }
    

在上述的代码中，我们利用 `transition` 分别控制了元素伪元素的高度、宽度及下边框的变化，并且给宽度过渡动画和下边框的颜色动画设置了 0.25 秒的延迟，这样元素的高度会先进行过渡，由于整体的过渡动画时间也是 0.25s，所以高度过渡动画结束后，才会开始宽度过渡动画，下边框也才会出现颜色变化。

这样就能把它们的过渡动画衔接在一起，体现到元素的 border 之上，看看效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e7ef91d0093d4852b9fc34f5f072f150~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=319&h=76&s=27257&e=gif&f=27&b=fdfdfd)

这里肯定很多同学一时间难以理解，如果我们把其他元素拿走，只剩下一个伪元素 `div::before`，并且，给这个伪元素添加上一个背景色，再理解一次这个过渡效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5c89949417474531af28b5783b5a7356~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=450&h=105&s=45149&e=gif&f=118&b=fdfcf9)

**这里的核心在于通过元素先高度后宽度的变化，让两条 border 的出现是有先后顺序感的**。

利用同样的原理，我们再利用元素的另外一个伪元素 `::after`，实现另外一半边框的变化。

只是它们的过渡延迟时间，整体需要再全部加上 0.5 秒，也就是需要等到上述的 `::before` 元素的过渡动画执行完毕后才执行：

    div::after {
        right: 0;
        bottom: 0;
    }
    div:hover::after{
        transition: height .25s, width .25s, border-top-color .25s;
        transition-delay: 0.5s, 0.75s, 0.75s;
        width: 200px;
        height: 64px;
        border-top: 3px solid #00e2ff;
        border-right: 3px solid #00e2ff;
    }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d14274bb7330442fb49af33cd8b3e1b4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=319&h=76&s=31753&e=gif&f=33&b=fdfdfd)

这样，我们可以把两个伪元素的过渡动画进行合并，得到一个完整的 border 动画如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c4ff063e081a4acaa063e0c5ad737ee7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=319&h=76&s=35307&e=gif&f=37&b=fdfdfd)

> 完整的 Demo，你可以戳这里：[CodePen Demo -- 借助 transition-delay 实现按钮 border 动画效果](https://codepen.io/Chokcoco/pen/GwKOem "https://codepen.io/Chokcoco/pen/GwKOem")

**看，通过** **`transition-delay`** **，我们精细化地控制了不同属性，通过时间先后的展示，最终组合得到各种有趣的效果**。

创意构想，transition-duration 0 与非 0 切换的效果
-------------------------------------

上面的 Demo 中，也出现了 `transition-delay` 在 hover 状态和非 hover 状态的两种值的设定。

无独有偶，我们也可以利用这个技巧，将其应用在 `transition-duration`，也就是过渡持续时间之上。

基于此，我们可以实现许多有创意的交互效果，其核心就在于：

1.  当元素被 hover/active 处于 hover/active 状态下，设置一个非常短，甚至 0s 的过渡持续时间 `transition-duration`；
2.  当元素离开 hover/active 等状态，再设置一个非常非常长的过渡持续时间 `transition-duration`，这样就能近似地让元素的状态停留在 hover/active 设置的状态之下。

利用上述的思路，我们来实现一个**刮刮乐**。

首先，我们在一个 `600px x 200px` 的 div 上，通过 300 个 `20 x 20` 的格子，将其铺满。

代码大致如下：

    <div class="g-container">
      <div class="g-box">
        <div class="g-row">
          <div class="g-item"></div>
          // 每个 .g-row 下面一共有 30 个 .g-item
          <div class="g-item"></div>
        </div>
        // 一共有 10 行
        <div class="g-row">...</div>
      </div>
    </div>
    

    .g-box {
        position: relative;
        height: 200px;
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
    }
    .g-row {
        width: 600px;
        flex-grow: 1;
        display: flex;
        flex-direction: row;
        flex-wrap: nowrap;
    }
    .g-item {
        width: 20px;
        height: 20px;
        background: rgba(100, 100, 100, 1);
        border-radius: 50%;
    }
    

实现这么一个图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6e8ee04cec864113820671412c60b573~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=615&h=214&s=13698&e=png&b=585858)

我们给每个 `.g-item` 设置一个缩放，让 300 个 `.g-item` 铺满容器。再设置父容器的 `overflow: hidden`，这样，我们就实现好了我们的初始结构：

    .g-box {
        overflow: hidden;
    }
    .g-item {
        transform: scale(1.6);
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8057b0fc18d949e2a690abcc7751a8f5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=614&h=218&s=3609&e=png&b=585858)

接下来，我们设置每个 `.g-item` 的默认过渡时间是 `5s`，当被 hover 的时候，过渡时间为 `0s`，因此，颜色会瞬间从灰色变成透明色：

    .g-item {
        transform: scale(1.6);
        transition: background 5s;
    }
    .g-item:hover {
        background: rgba(100, 100, 100, 0);
        transition-duration: 0s;
    }
    

这样，我们尝试 hover 一下整个元素：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4c8c89deab4f4d7ca600fec0dee66225~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=209&s=586768&e=gif&f=237&b=4a4947)

由于颜色的过渡动画持续时间在 hover 和非 hover 状态下，一个是 `0s`、一个是 `5s`，就造成了元素的过渡动画是瞬间完成，但是会缓慢消失。

如果我们把上面的 `5s` 变成 `9999999s` 一个非常大的数字，又会发生什么呢？

    .g-item {
        transform: scale(1.6);
        transition: background 9999999s;
    }
    .g-item:hover {
        background: rgba(100, 100, 100, 0);
        transition-duration: 0s;
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/338d5fb07d974ff2a623e8befcdb2f70~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=207&s=79171&e=gif&f=233&b=494847)

由于设置了 `transition: background 9999999s`，这就相当于 `.g-item` 从透明色变回灰色需要几千个小时！变相地相当于将元素的状态保持在了 `hover` 时候的状态。

基于上述的效果，我们在元素的下方，再通过一个元素，写上一些内容，就近似实现了一个有意思的刮刮乐效果！

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/08bf49296d89493aac233deb7d491777~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=207&s=78231&e=gif&f=199&b=494847)

> 当然，其实这个效果使用 `transition-delay` 也是可以完成的。

> 完整的代码，你可以戳这里：[CodePen Demo -- Pure CSS Scratch Panel](https://codepen.io/Chokcoco/pen/QWZaRMb "https://codepen.io/Chokcoco/pen/QWZaRMb")

举一反三，基于这个技巧，我们可以再实现一个画板，或者说是签名版。

首先，在一个高宽都为 500px 的容器中，实现一个 100x100 的 HTML 网格布局，为了方便大家理解，我把每个格子加了个 `border`。

在最终效果中，背景和格子都是透明的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2211ef91d65e4c8b8a84159935896f47~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=513&h=513&s=10961&e=png&b=f4f4f4)

接着，我们给每个格子 `g-item` 加上 hover 事件，与上面的刮刮乐效果一致：

1.  hover 时改变当前格子背景色，并且 hover 的同时， `transition-duration` 设置为 `0s`；
2.  而正常状态下，设置一个非常大的 `transition-duration`。

    .g-item {
        transition: 9999999s;
    }
    .g-item:hover {
        background: #000;
        transition-duration: 0s;
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bdbdb671248040d3a2440a9d3db8f9ad~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=372&s=109599&e=gif&f=101&b=fefefe)

这样就实现了，鼠标 hover 上去的时候，因为 `transition: 0s` 的缘故，背景色被快速地改变，而当 hover 效果离开， `transition: 9999999s` 重新生效，黑色则会以一个非常非常慢的速度失效。**是的，慢到根本感受不到它在发生变化。**

当然，上述效果是有问题的，要实现画板的话，很重要的一点在于，当鼠标 hover 到画板上不会立即开始触发元素的变化，只有鼠标按下时，也就是当触发了 `:active` 状态，并且保持 `:active`，才开始遵循鼠标轨迹改变颜色。

最后，当鼠标停止点击，则停止画画。

有个巧妙的方法可以实现上述的诉求：我们在画布上，再叠加上一层 div，层级 `z-index` 比画布更高，当鼠标 hover 到画布上，其实是 hover 到这个遮罩层上，当鼠标按下，触发 `:active` 事件时，给元素添加一个 `:active` 事件，将遮罩层移除即可。

这样，一个完整的签名板，或者说是画板就实现了：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/17badfd90b774b849c675fd3b9df3d6e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=372&s=82815&e=gif&f=79&b=fefefe)

> 因为与上面的代码高度类似，就不在文章中过多展示代码，完整的代码实现，你可以戳这里：[CodePen Demo -- Pure CSS signature](https://codepen.io/Chokcoco/pen/gOLbrYJ "https://codepen.io/Chokcoco/pen/gOLbrYJ")

总结一下
----

在本章中，我们从 CSS transition 的基础开始，由浅及深，较为系统性地梳理了一遍过渡相关特点及使用技巧。

当然，与过渡效果非常相关的一个缓动函数，我们没有在本章展开讲解，将会在 Animation 动画的章节详述。

最后，我们一起来回顾一下本章的要点内容。

对于 CSS transition，我们需要了解其一些基础特性：

1.  可以通过关键字 `all` 给所有属性设置过渡；
2.  transition 支持多个属性的精细化控制；
3.  过渡效果支持延迟加载；
4.  并非所有元素都是支持过渡动画的。

而在 CSS 过渡的具体使用中，我们还介绍了一些常见的应用技巧：

1.  合理使用过渡，提升用户体验；
2.  不要将 auto 值应用于过渡动画；
3.  巧用多层元素，解决交互闪烁问题；
4.  巧用延迟过渡，让内容保持状态；
5.  巧用延迟过渡，实现多段过渡动画的组合；
6.  创意构想，transition-duration 0 与非 0 切换的效果。

在恰当的地方，添加合理的过渡效果，能够让我们页面更加鲜活。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
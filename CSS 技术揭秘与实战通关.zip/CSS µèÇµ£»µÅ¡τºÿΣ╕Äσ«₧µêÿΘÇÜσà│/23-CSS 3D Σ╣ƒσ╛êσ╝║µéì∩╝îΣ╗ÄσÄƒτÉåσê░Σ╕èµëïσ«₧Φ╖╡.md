好，我们进入下一个主题的学习。本章和下章，我们将深入到 CSS 3D 中，一步一步感受 CSS 3D 的魅力。

一提到 3D，很多同学本能地望而生畏，潜意识地认为它很难。

实则不然，可能很多人潜意识中的 3D 是这个样子的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8608dfcf385649218e0e28b73994e9c3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=538&s=6894131&e=gif&f=292&b=ffffff)

又或者是这样的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fedb6a9c6ac348c498bbb7bcf20d2027~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=500&h=315&s=8638181&e=gif&f=61&b=02100a)

> 图片来源于 ThreeJS 官网收录案例：[Three.js - 2050 Earth](https://2050.earth/ "https://2050.earth/")

这类拥有完整的 3D 场景、光线、阴影、模型的 3D 效果确实很复杂，在 Web 上想要实现它们，通常需要借助 Canvas 3D 画布，也就是 WebGL 的能力。

WebGL 和 CSS 3D 转换是在浏览器（Web）中创建 3D 的两种主要技术，而在本小册中，我们主要讨论是 CSS 3D。

庆幸的是，对于 CSS 3D 而言，它其实并没有那么高的复杂度！并且非常容易上手。

借助 CSS 3D 效果，虽然没法做到 3D 建模，但是依靠简单的 transform 3D 变换，我们依然可以实现令人惊叹的效果。掌握并且灵活使用它们，可以极大地提升 Web 页面的交互体验。

CSS 3D 快速入门
-----------

所以，本小册默认你已经掌握了一定的 CSS 3D 知识，已经能够绘制最简单的 CSS 3D 动画效果。

当然这里我们再快速过一下 CSS 3D 相关的基础知识。

### 使用 transform-style 启用 3D 模式

要利用 CSS 实现 3D 的效果，最主要的就是借助 `transform-style` 属性。`transform-style` 只有两个值可以选择：

    {
      transform-style: flat; // 默认，子元素将不保留其 3D 位置
      transform-style: preserve-3d; // 子元素将保留其 3D 位置。
    }
    

当我们指定一个容器的 `transform-style` 的属性值为 `preserve-3d` 时，容器的后代元素便会具有 3D 效果，这样说有点抽象，也就是当前父容器设置了 `preserve-3d` 值后，它的子元素就可以相对于父元素所在的平面，进行 **3D 变形操作**。

### 利用 perspective & perspective-origin 设置 3D 视距，实现透视/景深效果

`perspective` 为一个元素设置三维透视的距离，仅作用于元素的后代，而不是其元素本身。

简单来说，当元素没有设置 `perspective` 时，也就是当 `perspective: none` 或者 `perspective: 0` 时，所有后代元素被压缩在同一个二维平面上，不存在**景深（透视）** 的效果。

而如果设置 `perspective` 后，将会看到三维的效果。

    {
      // 语法
      perspective: number|none;
    
      // x-axis : 定义该视图在 x 轴上的位置。默认值：50%
      // y-axis : 定义该视图在 y 轴上的位置。默认值：50%
      perspective-origin: x-axis y-axis;
    }
    

而 `perspective-origin` 表示 3D 元素透视视角的基点位置，默认的透视视角中心在容器是 `perspective` 所在的元素，而不是它的后代元素的中点，也就是 `perspective-origin: 50% 50%`。

### 使用 transform 3d 属性进行 3D 变换

在设置了 **`transform-style: perserve-3d`** 以及 **`perspective`** 后，最终想要实现 3D 效果，还是要依靠元素的 3D 变换。而这就需要如下几个属性：

    {
        transform: translate3d();
        transform: rotate3d();
        transform: scale3d();
    }
    

这里也需要简单解释一下：

1.  使用 `translateX()` 、`translateY()` 、 `translateZ()` 来进行 3D 位移操作，也可以合并为 `translate3d(x, y, z)` 这种写法；
2.  使用 `scaleX()` 、`scaleY()` 、`scaleZ()` 来进行3D 缩放操作，也可以合并为 `scale3d(x, y, z)` 这种写法；
3.  使用 `rotateX()` 、`rotateY()` 、`rotateZ()` 来进行 3D 旋转操作，也可以合并为 `rotate3d(x, y, z)` 这种写法。

首先，我们来看最简单的一个 3D 案例，借此体会 CSS 3D 的效果。

我们首先，设置 3 个一样的结构：

    <div></div>
    <div></div>
    <div></div>
    

    div {
        position: relative;
        width: 200px;
        height: 200px;
        border: 2px dashed #333;
        background: rgba(0, 0, 0, .3);
    }
    
    div::before {
        content: "";
        position: absolute;
        inset: 10px;
        border: 1px solid #000;
        background: #3f51b5;
    }
    

这里为了节省元素，我们用了元素和元素的伪元素做示意（注意，元素和元素的伪元素构造了父子结构关系），你可以理解为就是 div 包裹 div 的结构。

可以得到这样三个元素：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/317fc48edf644ca59e1a22831cbb4cbb~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1006&h=229&s=3779&e=png&b=f0f0f0)

接下来，我们通过最简单的代码，来理解：

1.  `transform-style: preserve-3d;` 的作用是什么？
2.  `perspective` 的作用是什么？

我们给这 3 个元素，添加上不同的代码：

    div:nth-child(1)::before {
        transform: rotateY(30deg);
    }
    
    div:nth-child(2){
        perspective: 150px;
    }
    div:nth-child(2)::before {
        transform: rotateY(30deg);
    }
    
    div:nth-child(3){
        transform-style: preserve-3d;
        perspective: 150px;
    }
    div:nth-child(3)::before {
        transform: rotateY(30deg);
    }
    

我们会得到如下三种不一样的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d26c1b0ca2c94b7baa86841772a09715~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1060&h=438&s=26856&e=png&b=f7f7f7)

仔细看上面的图，你能通过这张图 Get 到 `transform-style: preserve-3d` 和 `perspective` 的作用吗？

我们来解读一下：

1.  第一张图：没有设置 `transform-style: preserve-3d` 和 `perspective`，因此，虽然使用了 3d 旋转 `rotateY(30deg)`，围绕 Y 轴旋转 30°，**但是图形看上去仍然是平面的，并且没有透视景深的效果**。
    
2.  第二张图：父容器设置了 `perspective` 但是没有设置 `transform-style: preserve-3d`，可以看到，子元素运用了 `rotateY(30deg)` 后，有了 3D 的感觉，也就是透视景深的效果，近大远小。但是，此时，其实还不算严格意义上的 3D，因为其实整个图形还是在一个 2D 平面上，只有视觉上的元素 3D 形变，没有 Z 轴的概念。也就是说，此时，在 Z 轴方向上，其实还是一个平面。
    
3.  第三张图：要解决在 Z 轴方向上，形成真正的 3D 空间，就必须再给 3D 形变的元素的父元素，设置 `transform-style: preserve-3d`，也就是第三张图的效果。此时，元素不仅仅在视觉上形成了 3D 景深效果，同时，在 Z 轴方向上，不再是一个平面，而是存在了一个 Z 轴的空间，所以我们能看到，元素的一半因为旋转，被父元素的背景 `background: rgba(0, 0, 0, .3)` 遮挡住了。
    

上面的内容，对于理解 CSS 3D 的核心概念而言非常重要，需要仔细理解。至此，我们用更通俗的语言，再快速总结一下 CSS 3D 几个核心属性：

1.  **`transform-style: perserve-3d`** 让元素的后代在 Z 轴方向上，形成一个空间而非一个平面，因此让元素及其后代的表现能够有空间感，形成所谓的 3D 效果；
2.  **`perspective`** 让元素的后代形成三维透视（景深）效果；
3.  **`rotate3d()/translate3d()/scale3d()`** 对元素进行 3D 变换。

至此，CSS 3D 的基本概念就算厘清了。接下来，我们稍微加一点点难度，尝试利用 CSS 3D，构建一个 3D 图形。

利用 CSS 3D 构建 3D 图形
------------------

最常见的 3D 图形，莫过于一个 3D 立方体。

如果没有上下两个面，只是一个 4 个面的图形，大概是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/580c175783744fcc92c6de8fbd48cdec~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=321&s=2165231&e=gif&f=138&b=bfc89b)

这样一个图形，利用 CSS 3D，如何快速实现呢？

首先，构造这么一个结构：

    <div class="perspective">
            <div class="container">
                    <div class="img">3</div>
                    <div class="img">D</div>
                    <div class="img">视</div>
                    <div class="img">图</div>
            </div>
    </div>
    

4 个面，就是最内层的 4 个 `.img`，首先，需要给两个父容器，设置 3D 的属性：

    .perspective {
      perspective: 3000px;
    }
    .container {
      width: 400px;
      height: 400px;
      transform-style: preserve-3d;
    }
    

简单解释一下：

1.  `perspective` 可以作用于元素的后代，设置在最上层即可；
2.  `transform-style: preserve-3d` 设置给最终需要 3D 空间的元素的父容器之上，由于最终是 4 个 `.img` 需要 3D 空间，因此设置给 `.container` 即可。

接下来，就是最为核心的，如何设置 4 个 `.img` 元素的 3D 变换，使之形成 3D 立方体。

技巧就是：**先旋转，再位移**。

这里给出一个俯视效果图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b54dd273120749f38f47ac63c0ac2599~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=710&h=305&s=40053&e=png&b=fefefe)

以上述 Demo 中的正方体为例子，class 为 `.img` 的 div 块的高宽为 `400px*400px`。那么要利用 4 个 这样的 div 拼接成一个正方体，需要分别将 4 个 div 绕 Y 轴旋转 \[90°, 180°, 270°, 360°\]，再 `translateY(200px)` 。

值得注意的是，**一定是先旋转角度，再偏移距离，这个顺序很重要**。

代码如下：

    .img {
            position: absolute;
            top: 0;
            left: 0;
            width: 400px;
            height: 400px;
    }
    @for $i from 1 through $imgCount {
            .img:nth-child(#{$i}) {
                    transform: rotateY(($i * 90deg)) translateZ(200px);
            }
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9c4a528a7a834f2c98c3ec5e076adca0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=661&h=637&s=2801521&e=gif&f=158&b=e9e0d2)

此时，可能会觉得图片太太太大了，此时，我们可以通过给中间层 `.container` 设置一个恰当的 `translateZ` 进行视觉大小上的调节。

    .container {
        transform: translateZ(-3000px);
    }
    

这样，就能得到恰当大小的立方体元素效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cff2d894c5e848d099d347e2b8c703ca~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=321&s=2165231&e=gif&f=138&b=bfc89b)

> 完整的代码，你可以戳这里：[CodePen Demo -- 3D Cube](https://codepen.io/Chokcoco/pen/OJaLLpX "https://codepen.io/Chokcoco/pen/OJaLLpX")

掌握了 4 个面的立方体，完全可以继续拓展出其他多面体，譬如我们再尝试制作一个 8 面体，其核心也是，先旋转再位移，俯视图如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ee2198cad4d14bfd983d7f30554783c4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=648&h=445&s=74388&e=png&b=fdfdfd)

效果图如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c172a79a85bf442fa6dfdcc7dd90f26e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=500&h=250&s=1998095&e=gif&f=113&b=fffbff)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS 3D Eight-sided Cube](https://codepen.io/Chokcoco/pen/qBQWWxz "https://codepen.io/Chokcoco/pen/qBQWWxz")

我们再来看看 Webpack 的 Logo，它正是由 2 个立方体组成：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/314f41ea66234c09beefed421e74f948~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=956&h=399&s=115784&e=gif&f=23&b=2d3b44)

相对于上面的 4 面立方体，它多出了两个面：

1.  一个正方体由 6 个面组成，所以首先设定一个父元素 div，然后这个 div 再包含 6 个子 div，同时，父元素设置 `transform-style: preserve-3d`；
2.  6 个子元素，依次首先旋转不同角度，再通过 `translateZ` 位移正方体长度的一半距离即可；
3.  父元素可以通过 `transform` 和 `perspective` 调整视觉角度。

代码与上面的 4 面立方体、8 面立方体一致，就不贴了。

叠加两个立方体，调整颜色和透明度，我们可以非常轻松地实现 Webpack 的 LOGO：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d87cd37246164fe78b6165eff885d692~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=240&h=206&s=233508&e=gif&f=52&b=2c3a43)

当然，这里的 LOGO 为了保证每条线条视觉上的一致性，其实是没有设置景深效果 `perspective` 的，我们可以尝试给顶层父容器添加一下如下代码，通过 `transform` 和 `perspective` 调整视觉角度，设置景深效果：

    .father {
        transform-style: preserve-3d;
        perspective: 200px;
        transform: rotateX(10deg);
    }
    

就可以得到真正的 3D 效果，感受很不一样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1a9ce1bbff354a1d93bf62a4d49eb077~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=240&h=206&s=267493&e=gif&f=65&b=2c3a43)

对比两种风格的立方体 Webpack LOGO，相信你能对 CSS 3D 有更深刻的认识。

> 完整的代码，你可以戳这里：[CodePen Demo -- Webpack LOGO](https://codepen.io/Chokcoco/pen/gOWyeXX?editors=1100 "https://codepen.io/Chokcoco/pen/gOWyeXX?editors=1100")

通过立方体实现 3D 进度条
--------------

还是 3D 立方体，我们再进一步，尝试利用 3D 立方体来实现一个立体的进度条效果。

当然，首先还是得实现一个立方体，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f1137bb8a5d7485cb32ff4388528d223~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=378&h=154&s=5310&e=png&b=b57ac7)

我们可以把这个立方体想象成一个立体的进度条容器，通过控制每个面的颜色，可以巧妙地得到一种 3D 进度条的效果。

当然，其实不需要 6 个面，只保留 4 个面即可，去掉左右两边。然后利用渐变修改一下立方体各个面的颜色，去掉 border，核心的代码如下：

    <div class="demo-cube perspective percentage">
      <ul class="cube">
        <li class="top"></li>
        <li class="bottom"></li>
        <li class="front"></li>
        <li class="back"></li>
      </ul>
    </div>
    

    .demo-cube {
      position: relative;
    
      .cube {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 300px;
        height: 100px;
        transform-style: preserve-3d;
        transform: translate(-50%, -50%) rotateX(-33.5deg);
    
        li {
          position: absolute;
          width: 300px;
          height: 100px;
          background: linear-gradient(90deg, rgba(156, 39, 176, .3), rgba(255, 34, 109, .8) 70%, rgba(255, 255, 255, .6) 70%, rgba(255, 255, 255, .6));
        }
        .top {
          transform: rotateX(90deg) translateZ(50px);
        }
        .bottom {
          transform: rotateX(-90deg) translateZ(50px);
        }
        .front {
          transform: translateZ(50px);
        }
        .back {
          transform: rotateX(-180deg) translateZ(50px);
        }
      }
    }
    

这样，我们就可以得到一个非常酷炫的 3D 进度条效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/16cb2a758c594bc4b86c510a7c6057fd~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=406&h=155&s=32434&e=png&b=f5e7ea)

### 利用 CSS Property 给 3D 进度条加上动画

当然，进度条嘛，它需要一个进度条改变的动画效果。由于我们使用的是渐变实现的进度条的进度，需要去控制其中的颜色百分比变化。

而正常而言，CSS 是不支持渐变的动画的，不过这也难不倒我们，利用前面渐变及 @property 的内容，控制渐变的动画可以使用 CSS @Property。简单改造一下代码：

    @property --per {
      syntax: '<percentage>';
      inherits: false;
      initial-value: 0%;
    }
    
    .demo-cube .cube {
      .top,
      .front,
      .bottom,
      .back {
        background: linear-gradient(90deg, rgba(255, 217, 34, .6), rgba(255, 34, 109, .8) var(--per), rgba(255, 34, 109, .1) var(--per), rgba(255, 34, 109, .1));
        animation: perChange 6s infinite;
      }
    }
    
    @keyframes perChange {
      0% {
        --per: 0%;
      }
      90%,to {
        --per: 80%;
      }
    }
    

这样，我们就实现了一个会动的 3D 进度条，只需要控制 `--per` CSS 自定义属性即可，效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a34e1eb919df4370a22bf2ccaf79bea0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=147&s=1408868&e=gif&f=169&b=efbccd)

> 上述的完整代码，你可以猛击这里：[CSS 灵感 -- 3D 立方体进度条](https://csscoco.com/inspiration/#/./3d/3d-cuber-progress-bar "https://csscoco.com/inspiration/#/./3d/3d-cuber-progress-bar")

实现 3D 照片墙
---------

再来一个有意思的实战例子。

想象上面的 8 面立方体，如果我们继续把每一个面的图形向外扩散（也就是增大 `translateZ()` 的值），再给每一个面，实际贴上图片。

配合其他一些有意思的属性，譬如 CSS 中的倒影效果，我们就能实现非常赞的 3D 照片墙效果，代码大同小异。

简单介绍一下，这里的倒影效果，应用的是 CSS 中的`-webkit-box-reflect` ，能够在上下左右四个方向上，拷贝一份元素实际的渲染效果，形成镜像效果，配合各种 CSS 动画，非常地赞。

代码如下：

    <div class="container">
    	<!-- 舞台层 -->
    	<div class="stage">
    		<!-- 控制层 -->
    		<div class="control">
    			<!-- 图片层 -->
    			<div class="imgWrap">
    				<div class="img img1"><img src="https://picsum.photos/2000/1000?random=99"></div>
    				<div class="img img2"><img src="https://picsum.photos/2000/1000?random=100"></div>
    				<div class="img img3"><img src="https://picsum.photos/2000/1000?random=101"></div>
    				<div class="img img4"><img src="https://picsum.photos/2000/1000?random=102"></div>
    				<div class="img img5"><img src="https://picsum.photos/2000/1000?random=103"></div>
    				<div class="img img6"><img src="https://picsum.photos/2000/1000?random=104"></div>
    				<div class="img img7"><img src="https://picsum.photos/2000/1000?random=105"></div>
    				<div class="img img8"><img src="https://picsum.photos/2000/1000?random=106"></div>
    			</div>
    		</div>
    	</div>
    </div>
    

CSS 代码如下（使用了 SASS 预处理器，其中还有一个循环函数）：

    $imgCount : 8;
    .container{
    	position:relative;
    }
    .stage{
    	position:relative;
    	width: 800px;
    	height: 240px;
    	perspective:2000px;
    	transform-style: preserve-3d;
    	-webkit-box-reflect: below 10px linear-gradient(transparent, rgba(0, 0, 0, .5));
     
    	.control{
    		position:relative;
    		width:100%;
    		height:100%;
    		transform-style: preserve-3d;
    		transform: translateZ(-2000px) rotateY(50deg) rotateZ(0deg);
    		animation:rotate 30s linear infinite;
    		
    		.imgWrap{
    			position:absolute;
    			width:400px;
    			height:400px;
    			top:50%;
    			left:50%;
    			transform:translate(-50%, -50%);
    			transform-style: preserve-3d;
    			
    			.img{
    				position:absolute;
    				width:500px;
    				height:400px;
    				top:0;
    				left:0;
    				transform-style: preserve-3d;
    				transform-origin: 50% 50% 0px;
    			}
    			
    			img {
    				width: 100%;
    				height: 100%;
    				object-fit: cover;
    			}
    
    			@for $i from 1 through $imgCount{
    				.img#{$i}{
    					transform: rotateY(35 + ($i * 45deg)) translateZ(650px) ;
    				}
    			}
    		}
    	}
    }
    
    @keyframes rotate{
    	0%{
    		transform: translateZ(-2000px) rotateY(0deg);
    	}
    	50%{
    		transform: translateZ(-2000px) rotateY(-360deg);
    	}
    	100%{
    		transform: translateZ(-2000px) rotateY(-720deg);
    	}
    }
    

看看效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/300b52de80b64860b37b9b27619021da~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=550&h=344&s=10421530&e=gif&f=101&b=181715)

> 完整的代码，你可以戳这里：[CodePen demo - 3DView & -webkit-box-reflect](https://codepen.io/Chokcoco/pen/ZEBpjVO "https://codepen.io/Chokcoco/pen/ZEBpjVO")

总结一下
----

至此，CSS 3D 入门课就结束了。

本章，我们的核心还是围绕在如何构建一个 CSS 3D 场景进行。重点在于厘清 CSS 3D 几个核心属性：

1.  `transform-style: perserve-3d` 让元素的后代在 Z 轴方向上，形成一个空间而非一个平面，因此让元素及其后代的表现能够有空间感，形成所谓的 3D 效果；
2.  `perspective` 让元素的后代形成三维透视（景深）效果；
3.  `rotate3d()/translate3d()/scale3d()` 对元素进行 3D 变换。

同时，我们借助最为经典的立方体为引子，逐步从 Webpack LOGO 到 3D 进度条，最终实现了一个 3D 照片墙效果。

当然，CSS 3D 绝不仅于此，本章只是一个开胃菜，在下一章节中，我们将继续奇妙的 3D 之旅，共同探索利用 CSS 3D 构建的更为有意思的效果！

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
本章我们将继续 CSS 3D 的内容。

在上一章节中，我们围绕着 CSS 3D 的基础以及如何构建 3D 多面体进行了系统化的描述，基于它们很好地对 CSS 3D 有了一个大概的认知。

然而，CSS 3D 仅仅只能实现立方体、多面体吗？CSS 3D 在实战中还有其他有意思的用法吗？

当然，本章我们就将一起探索 CSS 3D 的更多技巧与用法，同时，更进一步地理解什么是 CSS 3D 能做的、什么是 CSS 3D 不能做的。

理解 CSS 3D 中的模型
--------------

在上一章节中，我们利用 CSS 3D 实现了立方体，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/957e8bb0a6e342b59be8438e6e59e4b0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=321&s=39902&e=png&b=bcbb90)

实现了正多面体，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/be802bbf5fd04a28848bb0a958a0915e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=500&h=250&s=41178&e=png&b=fefcfe)

那么，一定会有同学好奇，CSS 可以实现一个完美的 3D 球形模型吗？像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/16363c861bc94910ab103b526525aedd~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=380&h=305&s=13292892&e=gif&f=212&b=3c393c)

上图是使用 Three.JS 中的 `SphereGeometry` 实现的一个球形模型。很遗憾，正常而言，CSS 无法生成如此一个 3D 球模型，原因在于 CSS 3D 被设计出来之初就不是为了去对标 WebGL，它只支持相对而言更简单的 3D 效果，不支持 3D 模型的导入。

WebGL 的模型通过顶点、线段形成一个个的三角形平面去构建立体模型。当然 CSS 也可以通过类似的操作去还原出一个立体模型，但两者在复杂度和性能上天差地别。

因此，需要注意的是，**CSS** **3D 基本上只能实现一些能够通过简单平面构造出来的立体模型。对于需要大量的顶点的图形（如球体、圆锥、连续的曲面），想要利用 CSS 3D 实现，是非常非常困难的，不是说不行，但是其投入产出比太低，复杂度太高。** 因此，通常不会有人这么去做。

理解了这一点后，你就能够快速地判读出什么图形是 CSS 3D 能够绘制出来的，什么图形是 CSS 3D 无法实现的。

当然，充满智慧的 CSSer 经常会通过一些讨巧的方式，简单模拟复杂立体模型。

譬如，我们尝试来实现一个球体：

    <ul class="sphere-inner">
      <li class="a"></li>
      <li class="b"></li>
      <li class="c"></li>
      <li class="d"></li>
    </ul>
    

    .sphere-inner {
        position: relative;
        transform-style: preserve-3d;
        animation: ballRotate 6s linear infinite;
    }
    
    .sphere-inner > li {
        width: 50px;
        height: 50px;
        position: absolute;
        top: 0;
        left: 0;
        border-radius: 100%;
        background: radial-gradient(transparent 30%, rgba(0,0,0,.3) 100%);
    }
    .a {
        transform: rotateY(0deg)
    }
    .b {
        transform: rotateY(90deg)
    }
    .c {
        transform: rotateY(180deg)
    }
    .d {
        transform: rotateY(270deg)
    }
    @keyframes ballRotate {
        0% {
            transform: rotateY(0deg)
        }
    
        100% {
            transform: rotateY(360deg)
        }
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4d5488cb832147d8a1e763243ffbeb7f~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=219&h=190&s=255590&e=gif&f=27&b=f1f0ef)

这里我们仅仅只是用了 4 个圆，通过旋转不同的角度，使得 4 个圆的叠加看上去像是一个球形。

又或者，在之前，我尝试过另外一种方式，利用 CSS 3D 来实现一个球形，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2eed9e993c474b868b3b4f41d0fb8881~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1344&h=471&s=4303421&e=gif&f=67&b=010101)

所做的，也只是利用 3D 空间的线条，尽可能模拟一个球形的轮廓，无法实现球形的立体曲面。

因此，与纯粹的 3D 球模型相比，一眼也能看出非常大的差距。因此需要再次强调，CSS 3D 是存在它的局限性的！

CSS 3D 更适合没有复杂曲面的 3D 场景，或者是将一个平面放置在一个 3D 空间之中进行 3D 变换。下面，我们就具体来看看 CSS 3D 的一些实际使用场景。

基于 CSS 3D 实现元素的 3D 化
--------------------

3D 的第一类场景就是让元素 3D 化。来看这么一个例子：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1441018c85bf403bbc1a6812c78344b4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=395&h=372&s=1214375&e=gif&f=21&b=f5f0ef)

我们实现了一种图片的 3D Hover 效果。这个要如何实现呢？其实运用了一个非常有意思的 3D 技巧。

其核心在于：

1.  **我们设置两个旋转容器，然后给两个容器，添加相反方向的旋转，绕 Z 轴旋转的动画**；
2.  其后，**给其中一层，再添加一个绕 X 轴或者 Y 轴的旋转**。

什么意思呢？假设，我们有这样一层结构：

    <div class="reverseRotate">
        <div class="rotate">
            <div class="content">
                <img src="https://picsum.photos/800/800?random=100" alt="">
            </div>
        </div>
    </div>
    

`.content` 即是最后实际内容的 DOM 元素，我们主要改造两个父容器。

我们给两个父容器，**添加相反方向的旋转，绕 Z 轴旋转的动画。**

    .rotate {
        animation: rotate 5s linear infinite;
    }
    .reverseRotate {
        animation: reverseRotate 5s linear infinite;
    }
    @keyframes rotate {
        100% {
            transform: rotate(360deg);
        }
    }
    @keyframes reverseRotate {
        100% {
            transform: rotate(-360deg);
        }
    }
    

由于正反两个方向的旋转动画会互相抵消，所以，实际上，我们得到的还是一个静态的元素。

什么意思？思考一下，下面两个动画，如何合并在同一个元素上，会发生什么？

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e954e7fee62241fdbab85b0650c49e5e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=745&h=385&s=1075499&e=gif&f=107&b=ffffff)

是的，最内部的**元素会静止！**

此时，**再添加一个绕 X 轴或者 Y 轴的旋转，破坏这种稳定性。**

首先，我们先给这几个元素添加 CSS 3D 转换：

    div {
        transform-style: preserve-3d;
        perspective: 100px;
    }
    

接着，尝试修改上面的旋转动画，在内层旋转上额外添加一个 rotateX：

    @keyframes rotate {
        0% {
            transform: rotateX(0deg) rotateZ(0deg);
        }
        50% {
            transform: rotateX(40deg) rotateZ(180deg);
        }
        100% {
            transform: rotateX(0deg) rotateZ(360deg);
        }
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/abaad20c13624b0293e891f25df8e25e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=395&h=372&s=8331055&e=gif&f=105&b=f5f0ef)

嘿，是不是挺有意思？这里需要好好理解一下。由于内容 `.content` 层是静止的，但其实外层两个图层都在旋转，通过设置额外的 `rotateX(40deg)`，相当于叠加多了一个动画，由于正反旋转抵消了，所有整个动画只能看到旋转的 `rotateX(40deg)` 这个动画，产生了上述的效果。

基于这份代码，稍微改造一下，就能得到上述的 Hover 效果了。

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS 动画正反旋转 3D 效果](https://codepen.io/Chokcoco/pen/zYMGEdw "https://codepen.io/Chokcoco/pen/zYMGEdw")

但是，我们如果想更进一步，实现类似于这样的效果，又该怎么办呢？

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3d8e1a9525df49f799fbbc4666357ea7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=239&s=940862&e=gif&f=147&b=41638a)

简化掉多余的元素，整个效果就会是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1541bcc68f16445a82c93d2c7592d10b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=200&h=177&s=390908&e=gif&f=166&b=fefbff)

这个效果中，由于元素的 3D 效果和鼠标的坐标有着强关联。因此必须要借助一定的 JavaScript 代码，当然，核心还是 CSS 3D。

我们需要处理好如下几个核心点：

1.  元素能够进行 3D 变换；
2.  元素的 3D 变换基于当前鼠标与元素左上角的坐标关系。

厘清了这两点，剩下的就是通过尝试效果，达成目标！

首先实现一个 DIV 元素，设置好 3D 的基本代码：

    <div id="element"></div>
    

    body {
        width: 100vw;
        height: 100vh;
        transform-style: preserve-3d;
        perspective: 500px;
    }
    
    div {
        width: 200px;
        height: 200px;
        background: #000;
        transform-style: preserve-3d;
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e3dc10deeb5d460cb0f826ffbf61f29e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=425&h=234&s=866&e=png&b=ffffff)

为了更加容易理解，下面我们会把动画拆解分为 X、Y 两个方向上的效果。

首先看 X 方向上的移动，这里，我们需要以元素的中心为界：

1.  当鼠标在中心右侧连续移动，元素绕 Y 轴移动，并且值从 0 开始，越来越大，范围为 (0, +∞)deg；
2.  反之，当鼠标在中心左侧连续移动，元素绕 Y 轴移动，并且值从 0 开始，越来越小，范围为 (-∞, 0)deg。

这样，我们可以得到这样一个公式：

    rotateY = (鼠标 x 坐标 - 元素左上角 x 坐标 - 元素宽度的一半)deg
    

通过绑定 onmousemove 事件，我们尝试一下：

    const multiple = 20;
    const mouseOverContainer = document.getElementsByTagName("body")[0];
    const element = document.getElementById("element");
    
    mouseOverContainer.onmousemove = function(e) {
      let box = element.getBoundingClientRect();
      let calcY = (e.clientX - box.x - (box.width / 2)) / multiple;
        
      element.style.transform  = "rotateY(" + calcY + "deg) ";
    }
    

其中的 `multiple` 可以理解为控制旋转的力度，是经过不断地调试得到的一个比较合理的值，通过调试后的效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5bbcf5c2e566456982aeb331d804b45c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=141&s=286070&e=gif&f=275&b=fefbff)

同理，我们利用上述的方式，同样可以控制 Y 方向上的移动：

    const multiple = 20;
    const mouseOverContainer = document.getElementsByTagName("body")[0];
    const element = document.getElementById("element");
    
    mouseOverContainer.onmousemove = function(e) {
      let box = element.getBoundingClientRect();
      let calcX = (e.clientY - box.y - (box.height / 2)) / multiple;
        
      element.style.transform  = "rotateX(" + calcX + "deg) ";
    };
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/99a6221fee02435baae5fba4b61cf391~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=303&h=304&s=91314&e=gif&f=88&b=fdfcff)

当然，在这里，我们会发现方向是元素运动的方向是反的，所以需要做一下取反处理，修改下 `calcX` 的值，乘以一个 `-1` 即可：

    let calcX = (e.clientY - box.y - (box.height / 2)) / multiple * -1;
    

OK，到这里，我们只需要把上述的结果合并一下即可，同时，上面我们使用的是 `onmousemove` 触发每一次动画移动。现代 Web 动画中，我们更倾向于使用 `requestAnimationFrame` 去优化我们的动画，确保每一帧渲染一次动画即可。

完整的改造后的代码如下：

    const multiple = 20;
    const mouseOverContainer = document.getElementsByTagName("body")[0];
    const element = document.getElementById("element");
    
    function transformElement(x, y) {
      let box = element.getBoundingClientRect();
      let calcX = -(y - box.y - (box.height / 2)) / multiple;
      let calcY = (x - box.x - (box.width / 2)) / multiple;
      
      element.style.transform  = "rotateX("+ calcX +"deg) "
                            + "rotateY("+ calcY +"deg)";
    }
    
    mouseOverContainer.addEventListener('mousemove', (e) => {
      window.requestAnimationFrame(function(){
        transformElement(e.clientX, e.clientY);
      });
    });
    

至此，我们就能简单地实现题图所示的鼠标跟随 3D 旋转动效：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dbf96cf265c5479fb8609d8015b408da~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=303&h=304&s=470269&e=gif&f=167&b=ffffff)

现在，还有最后一个问题，就是当我们的鼠标离开活动区域时，元素的 transform 将停留在最后一帧，正确的表现应该是复原到原状。

因此，我们还需要添加一些事件监听做到元素的平滑复位。

通过一个 `mouseleave` 事件配合元素的 `transition` 即可：

    div {
        // 与上述保持一致...
        transition: all .2s;
    }
    

    mouseOverContainer.addEventListener('mouseleave', (e) => {
        window.requestAnimationFrame(function(){
          element.style.transform = "rotateX(0) rotateY(0)";
        });
    });
    

至此，我们就可以完美地实现平滑出入，整体效果最终如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/be1b635595f64ecdbb60f42cf73ca0b0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=350&h=396&s=216351&e=gif&f=166&b=010101)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS 3D Rotate With Mouse Move](https://codepen.io/Chokcoco/pen/mdpGXjj "https://codepen.io/Chokcoco/pen/mdpGXjj")

基于 CSS 3D 实现视差效果
----------------

CSS 3D 另外一个非常强悍的技巧，就是实现视差效果。

> 什么是视差效果？**视差滚动**（Parallax Scrolling）是指让多层背景以不同的速度移动，形成立体的运动效果，带来非常出色的视觉体验。 作为网页设计的热点趋势，越来越多的网站应用了这项技术。

利用 CSS 3D 实现视差效果的原理如下：

1.  我们给容器设置上 `transform-style: preserve-3d` 和 `perspective: xpx`，那么处于这个容器的子元素就将位于 3D 空间中；
2.  再给子元素设置不同的 `transform: translateZ()`，这个时候，不同元素在 3D Z 轴方向距离屏幕（我们的眼睛）的距离也就不一样；
3.  滚动滚动条，由于子元素设置了不同的 `transform: translateZ()`，那么它们滚动的上下距离 `translateY` 相对屏幕（我们的眼睛），也是不一样的，这就达到了滚动视差的效果。

我们来看一个最简单的例子：

    <div class="g-container">
        <div class="section-one">translateZ(-1)</div>
        <div class="section-two">translateZ(-2)</div>
        <div class="section-three">translateZ(-3)</div>
    </div>
    

    body {
        perspective: 1px;
        transform-style: preserve-3d;
    }
     .section-one {
        transform: translateZ(-1px);
    }
    .section-two {
        transform: translateZ(-2px);
    }
    .section-three {
        transform: translateZ(-3px);
    }
    

再简单解释一下，核心就在于两点：

1.  父元素设置 `transform-style: preserve-3d` 和 `perspective: 1px`；
2.  子元素设置不同的 `transform: translateZ`。

这样，当我们滚动页面的滚动条时，效果如下，由于 `transform-style: preserve-3d;` 在元素内部形成了一个 3D 空间，因此不同的 `translateZ()` 元素在滚动时，滚动的距离因为远近原因，距离是不一致的。

基于这一点，很明显，当滚动滚动条时，不同子元素的位移程度从视觉上看是不一样的，也就达到了所谓的滚动视差效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1fcd614c072b4b869e133d80ecaafe10~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=596&h=260&s=198975&e=gif&f=35&b=fefefe)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS 3D parallax](https://codepen.io/Chokcoco/pen/EpOeRm "https://codepen.io/Chokcoco/pen/EpOeRm")

那么，运用 translate3d 的视差效果，又能有一些什么好玩的效果呢？下面这个滚动视差文字阴影/虚影效果很有意思：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6c235421037f44ba801163002714ed27~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=574&h=358&s=1346569&e=gif&f=83&b=000000)

> 完整代码，戳这里：[CodePen Demo -- CSS translate3d Parallax](https://codepen.io/Chokcoco/pen/XBgBBp "https://codepen.io/Chokcoco/pen/XBgBBp")

当然，通过调整参数（`perspective: ?px` 以及 `transform: translateZ(-?px);`），还能有其他很有意思的效果出现：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/23a82b826a6e49e49b10803cdb844743~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=503&h=122&s=1722861&e=gif&f=128&b=000000)

> 完整代码，戳这里：[CodePen Demo -- CSS translate3d Parallax 2](https://codepen.io/Chokcoco/pen/PBXwdX "https://codepen.io/Chokcoco/pen/PBXwdX")

掌握了利用 CSS 3D 实现的视差效果之后，我们可以把这个技巧应用于实战中。

我们可以利用视差效果，创建特殊的照片墙浏览效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/725eb22431c649048714d367d6b04752~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=508&s=7242178&e=gif&f=116&b=d4cebc)

核心代码就在于上述的技巧，简单列一下核心代码：

    <div class="g-container">
        <div class="section-one">
            <img src="https://picsum.photos/800/800?random=100" alt="">
        </div>
        // ... 多图片结构
        <div class="section-ten">
            <img src="https://picsum.photos/800/800?random=800" alt="">
        </div>
    </div>
    

核心在于，给每个不同的图片容器，添加不一样的 `translateZ()`，再让它们分散在容器中：

    body {
        perspective: 2px;
        transform-style: preserve-3d;
    }
    .g-container {
        position: relative;
        transform-style: preserve-3d;
        height: 150%;
        
        .section-one {
            transform: translateZ(-1.3px) translateX(60vw) translateY(-60vh);
        }
        .section-two {
            transform: translateZ(-4.7px) translateX(-20vw) translateY(-20vh);
        }
        .section-three {
            transform: translateZ(-2px) translateX(30vw) translateY(15vh);
        }
        .section-four {
            transform: translateZ(-1.7px) translateX(-23vw) translateY(51vh);
        }
        .section-five {
            transform: translateZ(-1.8px) translateX(25vw) translateY(95vh);
        }
        .section-six {
            transform: translateZ(-2.5px) translateX(65vw) translateY(125vh);
        }
        .section-seven {
            transform: translateZ(-1.9px) translateX(85vw) translateY(153vh);
        }
        .section-eight {
            transform: translateZ(-3.8px) translateX(-45vw) translateY(205vh);
        }
        .section-night {
            transform: translateZ(-1.2px) translateX(35vw) translateY(235vh);
        }
        .section-ten {
            transform: translateZ(-2.9px) translateX(65vw) translateY(270vh);
        }
    }
    

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS 3D parallax 照片墙效果](https://codepen.io/Chokcoco/pen/mdQJqpe "https://codepen.io/Chokcoco/pen/mdQJqpe")

基于 CSS 3D 进行创意展示
----------------

CSS 3D 也非常适用于给我们的页面增添一抹亮色，添加一些特点。

譬如，一些可视化图表页面上，很多带有科技感的元素。

假设我们设计实现了一套 CSS 的数字展示效果，效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/94c1fff5107e4938839f48144d5506f7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=702&h=166&s=586841&e=gif&f=28&b=010b09)

2D 的也挺有意思，但是如果把 2D 变成 3D 呢？是不能更能吸引用户的眼球？

基于 CSS 3D 改造一下，我们就能得到如下效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ad3107a9497847e8b37a58c147b1fbe1~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=700&h=192&s=8424772&e=gif&f=211&b=010e0c)

> 完整的代码，你可以戳这里：[CodePen Demo -- 3d Number Count](https://codepen.io/Chokcoco/pen/ExOjbMJ?editors=1100 "https://codepen.io/Chokcoco/pen/ExOjbMJ?editors=1100")

在我自己的[个人网站的 404](https://csscoco.com/404 "https://csscoco.com/404") 页面，就使用 CSS 3D 实现的立方体制作的一个 404 效果，毫无疑问，这种 3D 效果是非常吸人眼球的。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b6382736a14747d791bb30c4088b7226~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=325&s=676162&e=gif&f=65&b=fefefe)

其核心就在于在一个 CSS 3D 立方体的基础上：

1.  添加立方体的滚动动画；
2.  控制下落的缓动函数，及落地的震荡动画（为了效果更为逼真，运用了设计动画中的预备动作、跟随和重叠动画等技巧）；
3.  控制立方体及地面数字画面的平移；
4.  控制动画的无限循环。

整体制作还是非常有难度的，但是用在自己的 404 页面，确实也是非常的酷炫。这个效果，我最早见于 [Yusuke Nakaya](https://codepen.io/YusukeNakaya "https://codepen.io/YusukeNakaya") 大神，完整的代码你可以戳这里：[CodePen -- Only CSS: 404 Rolling Box](https://codepen.io/YusukeNakaya/pen/YLPVER "https://codepen.io/YusukeNakaya/pen/YLPVER") 。

基于 CSS 3D 构建立体全景动画
------------------

最后，再介绍一种基于 CSS 3D 构建的 3D 空间动画，利用 CSS 3D 的能力，尽可能地绘制一些非常具有空间美感的效果。

我们先来热热身，快速绘制一幅具有空间美感的 CSS 3D 作品。

首先，我们借助 Grid/Flex 等布局，在屏幕上布满格子（item），随意点就好：

    <ul class="g-container">
      <li></li>
      <li></li>
      // ... 很多子 li
      <li></li>
    </ul>
    

这里，我们设置初始的背景色为黑色，每个 item 填充为白色。

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f0e2cd898bad433b8d01b45a9eadfa0a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1182&h=301&s=20343&e=png&b=fefefe)

接着，改变下每个 item 的形状，让它变成长条形的，可以通过改变 item 宽度、使用渐变填充部分等等方式：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6b97bb719991422095ee01cf44a443fe~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=921&h=273&s=10561&e=png&b=000000)

接下来这两步非常重要：

1.  父容器设置 `transform-style: preserve-3d` 和 `perspective`；
2.  子元素设置 `transform: rotateX(45deg)`。

神奇的事情就发生了，我们得到了如下一幅非常 Amazing 的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/625974aa22bf424a8685e76c46cc75a5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=988&h=377&s=62868&e=png&b=010101)

仅仅几步，我们就初步得到了一副具有空间美感的图形。让我们再回到每个子 item 的颜色设置，给它们随机填充不同的颜色，并且加上一个 `transform: translate3d()` 的动画，一个简单的 CSS 3D 作品就绘制完成了：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6dc8a3454a94419ab4c46edc984136b5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=700&h=315&s=3612130&e=gif&f=43&b=030303)

基于这个技巧的变形和延伸，我们就可以绘制非常多类似的效果。

在这里，我简单推荐一下 [CSS-Doodle](https://css-doodle.com/ "https://css-doodle.com/") 这个工具，它可以帮助我们快速创造复杂的 CSS 效果。

> CSS-doodle 是一个基于 Web-Component 的库，允许我们快速地创建基于 CSS Grid 布局的页面，以实现各种 CSS 效果（或许可以称之为 CSS 艺术）。

我们可以把上述的线条切换成圆弧：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b42ae964e1f648b99341d21016a2e803~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=242&s=3265342&e=gif&f=81&b=030303)

> 完整的代码可以戳这里，利用 CSS-Doodle 也就几十行：[CodePen Demo - CSS-Doodle Random Circle](https://codepen.io/Chokcoco/pen/MWyJZQY "https://codepen.io/Chokcoco/pen/MWyJZQY")

基于上述技巧，我们可以尝试把用到线条、圆弧等元素，替换成图片。利用一些本身已经很有艺术感的图片再借助 3D 效果，碰撞出不一样的火花！

假设我们有这样一张图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7e18c03146094aa69d12271f0ce1e8e1~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=314&h=206&s=145075&e=png&b=1b0b3a)

在使用这张图之前，我们会先绘制这样一个图形：

    <div class="g-container">
        <div class="g-group">
            <div class="item item-right"></div>
            <div class="item item-left"></div>   
            <div class="item item-top"></div>
            <div class="item item-bottom"></div> 
            <div class="item item-middle"></div>    
        </div>
    </div>
    

CSS 代码如下：

    body {
      background: #000;
    }
    .g-container {
      position: relative;
    }
    .g-group {
      position: absolute;
      width: 100px;
      height: 100px;
      left: -50px;
      top: -50px;
      transform-style: preserve-3d;
    }
    .item {
      position: absolute;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, .5);
    }
    .item-right {
      background: red;
      transform: rotateY(90deg) translateZ(50px);
    }
    .item-left {
      background: green;
      transform: rotateY(-90deg) translateZ(50px);
    }
    .item-top {
      background: blue;
      transform: rotateX(90deg) translateZ(50px);
    }
    .item-bottom {
      background: deeppink;
      transform: rotateX(-90deg) translateZ(50px);
    }
    .item-middle {
      background: rgba(255, 255, 255, 0.5);
      transform: rotateX(180deg) translateZ(50px);
    }
    

一共设置了 5 个子元素，不过仔细看 CSS 代码，其中 4 个子元素都设置了 `rotateX/Y(90deg/-90deg)`，也就是绕 X 轴或者 Y 轴旋转了 90°，在视觉上是垂直屏幕的一张平面。

所以到目前为止，直观视觉上我们是看不到有什么特殊效果的，只能看到一个平面 `.item-middle`。

我将 5 个子 item 设置了不同的背景色，结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ad867afcafdc465fb12981ba0c80c9b4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=211&h=181&s=1406&e=png&b=000000)

现在看来，好像平平无奇，确实也是。

不过，见证奇迹的时候来了，此时，我们给父元素 `.g-container` 设置一个极小的 `perspective`，譬如，设置一个 `perspective: 4px`，看看效果：

    .g-container {
      position: relative;
    + perspective: 4px;
    }
    // ...其余样式保持不变
    

此时，画风骤变，整个效果就变成了这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1786db69c8314722bdfd9c7e65971816~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=477&h=224&s=5891&e=png&b=008000)

由于 `perspective` 生效，原本的平面效果变成了 3D 的效果。接下来，我们使用上面准备好的星空图，替换一下上面的背景颜色，全部都换成同一张图，神奇的事情发生了：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2fbdb374223b4563b5fc85a74821247b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=557&h=239&s=133309&e=png&b=140d38)

由于设置的 `perspective` 非常之下，而每个 item 的 `transform: translateZ(50px)` 设置得又比较大，所以图片在视觉上被拉伸得非常厉害。但是整体是充满整个屏幕的。

接下来，我们只需要让视角动起来，给父元素增加一个动画，通过控制父元素的 `translateZ()` 进行变化即可：

    .g-container{
      position: relative;
      perspective: 4px;
      perspective-origin: 50% 50%;
    }
    
    .g-group{
      position: absolute;
      // ... 一些定位高宽代码
      transform-style: preserve-3d;
      + animation: move 8s infinite linear;
    }
    
    @keyframes move {
      0%{
        transform: translateZ(-50px) rotate(0deg);
      }
      100%{
        transform: translateZ(50px) rotate(0deg);
      }
    }
    

看看，神奇美妙的星空穿梭效果就出来了，Amazing！

美中不足之处在于，动画没能无限衔接上，开头和结尾都有很大的问题。

当然，这难不倒我们，我们可以：

1.  通过叠加两组同样的效果，一组比另一组通过负的 `animation-delay` 提前行进，使两组动画衔接起来（一组结束的时候另外一组还在行进中）；
2.  再通过透明度的变化，隐藏掉 `item-middle` 迎面飞来的突兀感；
3.  最后，可以通过父元素的滤镜 `hue-rotate` 控制图片的颜色变化。

我们尝试修改 HTML 结构如下：

    <div class="g-container">
        <div class="g-group">
            <div class="item item-right"></div>
            <div class="item item-left"></div>   
            <div class="item item-top"></div>
            <div class="item item-bottom"></div> 
            <div class="item item-middle"></div>    
        </div>
        <!-- 增加一组动画 -->
        <div class="g-group">
            <div class="item item-right"></div>
            <div class="item item-left"></div>   
            <div class="item item-top"></div>
            <div class="item item-bottom"></div>   
            <div class="item item-middle"></div>    
        </div>
    </div>
    

修改后的核心 CSS 如下：

    .g-container{
      perspective: 4px;
      position: relative;
      // hue-rotate 变化动画，可以让图片颜色一直变换
      animation: hueRotate 21s infinite linear;
    }
    
    .g-group{
      transform-style: preserve-3d;
      animation: move 12s infinite linear;
    }
    // 设置负的 animation-delay，让第二组动画提前进行
    .g-group:nth-child(2){
      animation: move 12s infinite linear;
      animation-delay: -6s;
    }
    .item {
      background: url(https://z3.ax1x.com/2021/08/20/fLwuMd.jpg);
      background-size: cover;
      opacity: 1;
      // 子元素的透明度变化，减少动画衔接时候的突兀感
      animation: fade 12s infinite linear;
      animation-delay: 0;
    }
    .g-group:nth-child(2) .item {
      animation-delay: -6s;
    }
    @keyframes move {
      0%{
        transform: translateZ(-500px) rotate(0deg);
      }
      100%{
        transform: translateZ(500px) rotate(0deg);
      }
    }
    @keyframes fade {
      0%{
        opacity: 0;
      }
      25%,60%{
        opacity: 1;
      }
      100%{
        opacity: 0;
      }
    }
    @keyframes hueRotate {
      0% {
        filter: hue-rotate(0);
      }
      100% {
        filter: hue-rotate(360deg);
      }
    }
    

最终完整的效果如下，我们利用 CSS 3D 的能力，竟然绘制出了一幅星空穿梭的动画。更为重要的是，这是一个首尾相连，可以一直无限下去的动画效果，几乎没有破绽，效果非常的赞：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/53d09904076748c1aaa88eeaa32c0ea3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=550&h=226&s=8113779&e=gif&f=121&b=280b3b)

> 上述的完整代码，你可以猛击这里：[CodePen Demo -- 3D 宇宙时空穿梭效果](https://codepen.io/Chokcoco/pen/abWeNEV "https://codepen.io/Chokcoco/pen/abWeNEV")

总结一下
----

在本章中，我们彻底放飞了想象，基于 CSS 3D 的能力，构建出了各种神奇、有趣且非常 Amazing 的交互及动效。它们包括了：

1.  基于 CSS 3D 实现元素的 3D 化；
2.  基于 CSS 3D 实现视差效果；
3.  基于 CSS 3D 进行创意展示；
4.  基于 CSS 3D 构建立体全景动画。

当然，CSS 3D 的能力远不止于此。本文更多的是抛砖引玉，更希望的是读者们可以真正理解 CSS 3D，在平时的业务中发现可以使用 CSS 3D 的场景。合理利用它们，我们将有效地增强用户体验、提升页面交互感受。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
这一章，我们来具体聊聊 CSS 中非常重要的一个知识点：CSS 动画渲染及性能优化。

很多同学在创建 CSS 动画的过程中，更多的关注在动画效果本身，譬如，我们需要实现将一个元素物体从 A 移动到 B，那么此时，可选的方案可能有：

*   利用 margin，改变元素位置；
*   利用 padding，改变元素位置；
*   利用定位属性，譬如 left，改变元素位置；
*   利用 transform 属性，譬如 `transform: translate(10px, 0)`，改变元素位置。

上述方式都可以，但是哪一种方式是更好的方式？

又譬如，我们想改变一个物体的显示与隐藏的切换，下面哪一种方式是更好的选择：

*   `display: block` 与 `display: none` 的切换；
*   `opacity: 0` 与 `opacity: 1` 的切换。

又譬如，CSS 中，每一种属性的动画变换，消耗的性能是一样的吗？对不同的属性进行动画变换，有没有一些不一样的技巧？

带着这些疑问，我们开启今天的篇章。

浏览器渲染页面过程
---------

以 Chrome 为例子，一个 Web 页面的展示，简单来说可以认为经历了以下几个不同的步骤，看看下面这张经典的渲染图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/142323469e9b42d08f40e2f1d3750bc0~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=720&h=110&s=9908&e=jpg&b=fefcfb)

*   JavaScript：一般来说，我们会使用 JavaScript 来实现一些视觉变化的效果。比如做一个动画或者往页面里添加一些 DOM 元素等。
    
*   Style：计算样式，这个过程是根据 CSS 选择器，对每个 DOM 元素匹配对应的 CSS 样式。这一步结束之后，就确定了每个 DOM 元素上该应用什么 CSS 样式规则。
    
*   Layout：布局，上一步确定了每个 DOM 元素的样式规则，这一步就是具体计算每个 DOM 元素最终在屏幕上显示的大小和位置。Web 页面中元素的布局是相对的，因此一个元素的布局发生变化，会联动地引发其他元素的布局发生变化。比如，元素宽度的变化会影响其子元素的宽度，其子元素宽度的变化也会继续对其孙子元素产生影响。因此对于浏览器来说，布局过程是经常发生的。
    
*   Paint：绘制，本质上就是填充像素的过程。包括绘制文字、颜色、图像、边框和阴影等，也就是一个 DOM 元素所有的可视效果。一般来说，这个绘制过程是在多个层上完成的。
    
*   Composite：渲染层合并，由上一步可知，对页面中 DOM 元素的绘制是在多个层上进行的。在每个层上完成绘制过程之后，浏览器会将所有层按照合理的顺序合并成一个图层，然后显示在屏幕上。对于有位置重叠的元素的页面，这个过程尤其重要，因为一旦图层的合并顺序出错，将会导致元素显示异常。
    

在页面性能优化的技巧中，大家一定听过，尽可能地减少页面的重绘和重排。

上面的 Layout，也就是对应浏览器渲染过程中的重排的过程，而 Paint，对应的就是重绘的过程，而 Composite 就是最后的渲染层合并。

对于 CSS 性能优化（对于页面的每一帧渲染其实也是一样），我们可以来看这么一张图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5e4dafce2a3344fba5cbf7b512346489~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=408&h=263&s=8398&e=png&b=f4ece6)

我们把上面页面的每一帧渲染过程，想象成一个金字塔。而如果我们改变了底部的某些东西，金字塔就必须从底部开始重建。

什么意思呢？在某一帧中，如果只有元素的 Paint，那么只需要经历 `Paint --> Composite` 的过程。

而如果有元素的 `Layout`，则页面需要经历 `Layout --> Paint --> Composite` 的过程。

而如果我们能寻找到只有 `Composite` 变换的渲染，则页面无需经历 `Paint` 和 `Layout`，此时页面渲染性能就是最好的！

因此，**我们想要高性能的** **CSS** **动画，也是需要尽可能地减少页面的重排与重绘！**

那么，再看到上面的这一问 —— 我们想改变一个物体的显示与隐藏的切换，下面哪一种方式是更好的选择：

*   `display: block` 与 `display: none` 的切换；
*   `opacity: 0` 与 `opacity: 1` 的切换。

对于 `display: block` 与 `display: none` 的切换，是会引起页面的重排（Layout），而 `opacity` 的变换，仅仅只会导致页面的重绘，因此，`opacity` 方案是更好的选择。

理解浏览的 Composite Layers 与 GraphicsLayer
--------------------------------------

我们再来看一个非常重要的概念：浏览器的 Layer Border。

首先，我们构建一个非常简单的 Demo，上下两个 DIV，以不同的方式向右侧运动：

1.  divA 使用 left 向右侧进行动画；
2.  divB 使用 `transfrom: translate()` 向右侧进行动画。

简单的代码如下：

    <div></div>
    <div></div>
    

    div {
        position: relative;
        width: 200px;
        height: 200px;
        border: 5px solid #000;
    }
    
    div:nth-child(1) {
        animation: moveMargin 3s infinite linear;
    }
    div:nth-child(2) {
        animation: moveTransform 3s infinite linear;
    }
    
    @keyframes moveMargin {
        0% {
            left: 0;
        }
        100% {
            left: 300px;
        }
    }
    
    @keyframes moveTransform {
        0% {
            transform: translate3d(0, 0, 0);
        }
        100% {
            transform: translate3d(300px, 0, 0);
        }
    }
    

可以得到这样一种，两个 div 元素的向右运动动画：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1d440ffd729c46988fa62bdf7535a498~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=443&s=152423&e=gif&f=64&b=d6fafe)

这样一看没有什么特殊的。

接下来，我们打开 Chrome 开发者工具，点击右上角的三个小点，选择 `More tools`，选择 `Rendering`，最后，勾选上前面三个选项（Chrome > More tools > Rendering）：

1.  Paint flashing；
2.  Layout Shift Regions；
3.  Layer borders。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/19c384573dc048458ac091c159fae97f~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1622&h=610&s=114872&e=png&b=fefefe)

此时，再观察我们的两个 div 元素，就会出现不一样的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/782f9cdc1ae34da592e4ff83cf3ff00c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=429&s=183361&e=gif&f=65&b=fefefe)

分析一下上面的效果，有几处是我们需要注意的：

1.  上方的 div 元素，周围有一圈绿色的边框，而下方的 div，周围有一圈黄色的边框；
2.  上方的 div 在移动的过程中，一直存在绿色区域，表示其一直处于重绘中（Paint flahing）；
3.  上方的 div 在动画结尾处，回归原位时，会触发一次蓝色区域，这表示其触发了一次重排（Layout）。

我们再来看一次我们勾选的三个选项：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bf76a1aba6114041ab0bf7b0a65bfc3c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=937&h=170&s=16608&e=png&b=fffefe)

先说结论，上述使用 `transform: translate3d()` 进行位移的元素，其在运动过程中不会触发页面的重绘重排，只有页面的 `Composite` 的过程！

这就非常有意思了，这里有一个非常非常重要的概念：Composite Layers 与 GraphicsLayer。

**简单来说，浏览器为了提升动画的性能，为了在动画的每一帧的过程中不必每次都重新绘制整个页面，在特定方式下可以触发生成一个合成层（Composite Layers），合成层拥有单独的 GraphicsLayer。**

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fb73f0819ef04840b6badabbb0beba65~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=620&h=290&s=62948&e=png&b=edebe0)

需要进行动画的元素包含在这个合成层之下，这样动画的每一帧只需要去重新绘制这个 GraphicsLayer 即可，从而达到提升动画性能的目的。

如果我们想尽可能地优化我们的 CSS 动画，或者在日常 CSS 开发中，尽可能地提升 CSS 的性能，这是一个非常重要的概念。**通过生成独立的 GraphicsLayer，让此层内的重绘重排不引起整个页面的重绘重排。**

这也就是我们常说的，CSS 3D 硬件加速的最本质的原因。

那么，一个元素什么时候会触发创建一个 Graphics Layer 层？

从目前来说，满足以下任意情况便会创建层：

*   硬件加速的 iframe 元素（比如 iframe 嵌入的页面中有合成层）；
*   硬件加速的插件，比如 flash 等等；
*   使用加速视频解码的；
*   3D 或者硬件加速的 2D Canvas 元素；
*   3D 或透视变换（perspective、transform）的 CSS 属性；
*   对自己的 opacity 做 CSS 动画或使用一个动画变换的元素；
*   拥有加速 CSS 过滤器的元素；
*   元素有一个包含复合层的后代节点（换句话说，就是一个元素拥有一个子元素，该子元素在自己的层里）；
*   元素有一个 z-index 较低且包含一个复合层的兄弟元素。

因此，通常最为常见的创建一个复合层的方式就是：

1.  transform；
2.  opacity。

我们可以通过合理使用这两个元素，有效提升页面的性能，譬如**使用 transform 代替 left、top，实现位移动画。**

### 避免错误使用 GraphicsLayer

当然，GraphicsLayer 也不是完全没有缺点。

在使用 GraphicsLayer 时，首先我们要明确两点：

1.  我们希望页面的动画/过渡效果得到性能优化，所以我们会利用类似 `transform: translate3d()` 这样的方式生成一个 Graphics Layer 层。
2.  Graphics Layer 虽好，但不是越多越好，每一帧的渲染内核都会去遍历计算当前所有的 Graphics Layer ，并计算它们下一帧的重绘区域，所以过量的 Graphics Layer 计算也会给渲染造成性能影响。

理解了这两点之后，我们再来看一个有趣的例子。假设我们有一个轮播图，有一个 ul 列表，结构如下：

    <div class="container">
      <div class="swiper">轮播图</div>
      <ul class="list">
        <li>列表li</li>
        <li>列表li</li>
        <li>列表li</li>
        <li>列表li</li>
      </ul>
    </div>
    

假设给它们定义如下 CSS：

    .swiper {
        position: static;
        animation: 10s move infinite;
    }
        
    .list {
        position: relative;
    }
    
    @keyframes move {
        100% {
            transform: translate3d(10px, 0, 0);
        }
    }
    

由于给 `.swiper` 添加了 `translate3d(10px, 0, 0)` 动画，所以它会生成一个 Graphics Layer，如下图所示，用开发者工具可以打开层的展示，图形外的黄色边框即代表生成了一个独立的复合层，拥有独立的 Graphics Layer 。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cd0cddcc69da4a569a86ba8f8e0cb3de~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=799&h=492&s=61698&e=png&b=fcfcfc)

但是！在上面的图中，我们并没有给下面的 `list` 也添加任何能触发生成 Graphics Layer 的属性，但是它也同样也有黄色的边框，生成了一个独立的复合层。

原因在于上面那条**元素有一个 z-index 较低且包含一个复合层的兄弟元素**。我们并不希望 `list` 元素也生成 Graphics Layer ，但是由于 CSS 层级定义原因，下面的 list 的层级高于上面的 swiper，所以它被动地也生成了一个 Graphics Layer 。

使用 Chrome，我们也可以观察到这种层级关系，可以看到 `.list` 的层级高于 `.swiper`：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/eefa55bfd63e407d9521111564a5c6b2~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1279&h=367&s=48484&e=png&b=f9f9f9)

所以，下面我们修改一下 CSS，改成：

    .swiper {
        position: relative;
        z-index: 100;
    }
        
    .list {
        position: relative;
    }
    

这里，我们明确使得 `.swiper` 的层级高于 `.list` ，再打开开发者工具观察一下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/fe8a63f8ebc6431b891d88aa268b87f5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=609&h=371&s=16078&e=png&b=ffffff)

可以看到，这一次，`.list` 元素已经没有了黄色外边框，说明此时没有生成 Graphics Layer。再看看层级图：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e5613dc1a3244248be006acc56105532~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=794&h=353&s=21750&e=png&b=fefefe)

此时，层级关系才是我们希望看到的，`.list` 元素没有触发生成 Graphics Layer。而我们希望需要 Graphics Layer 来优化渲染的 `.swiper` 保持在最上方，每次动画过程中只会独立重绘这部分的区域。

这个坑最早见于张云龙发布的这篇文章：[CSS3 硬件加速也有坑](https://div.io/topic/1348 "https://div.io/topic/1348")。这里还要总结补充的是：

*   GPU 硬件加速也会有坑，当我们希望使用利用类似 `transform: translate3d()` 这样的方式开启 GPU 硬件加速，一定要注意元素层级的关系，尽量保持让需要进行 CSS 动画的元素的 `z-index` 保持在页面最上方。
*   Graphics Layer 不是越多越好，每一帧的渲染内核都会去遍历计算当前所有的 Graphics Layer ，并计算它们下一帧的重绘区域，所以过量的 Graphics Layer 计算也会给渲染造成性能影响。
*   可以使用 Chrome ，用上面介绍的两个工具对自己的页面生成的 Graphics Layer 和元素层级进行观察然后进行相应修改。
*   上面观察页面层级的 Chrome 工具非常吃内存？好像还是一个处于实验室的功能，分析稍微大一点的页面容易直接卡死，所以要多学会使用第一种观察黄色边框的方式查看页面生成的 Graphics Layer 这种方式。

理解 CSS 中的耗性能样式
--------------

理解了 Graphics Layer 后，我们再来看看 CSS 中另外一个与性能相关有意思的知识点。

在 CSS 中，不同的样式在消耗性能方面是不同的，改变一些属性的开销比改变其他属性要多，因此更可能使动画卡顿。

例如，与改变元素的文本颜色相比，改变元素的 `box-shadow` 将需要开销大很多的绘图操作。 改变元素的 `width` 可能比改变其 `transform` 要多一些开销。如 `box-shadow` 属性，从渲染角度来讲十分耗性能，原因就是与其他样式相比，它们的绘制代码执行时间过长。

> 还记得我们在阴影章节中介绍的一种优化盒阴影过渡效果的性能优化手段吗！其核心就在于避免大量使用 `box-shadow` 变换，转而使用代价更小的 `opacity` 变换替代 `box-shadow` 优化。

在这个页面 [very few CSS properties](https://csstriggers.com/ "https://csstriggers.com/")，列举了不同属性在改变属性值时，对页面重排、重绘的影响：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3d6e0afec33847acaab038efef0447f4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=868&h=262&s=22611&e=png&b=fbfbfb)

> 这个页面经历过几次改变，当前可能缺失了一些属性值的罗列。

我们需要对不同的属性，有更深刻的理解。

再举个例子，例如，实际上`height`可能会是一个非常耗性能的属性，因为在流式布局中，它会影响整个布局。当一个元素的高度缩小时，会引起连锁反应，它的所有后代兄弟元素也需要向上移动，以填补空间！

理解硬件加速，合理使用 will-change 属性
--------------------------

在 CSS 中，还有一个非常有意思的属性：`will-change`。

根据 MDN，属性 `will-change` 为 Web 开发者提供了一种告知浏览器该元素会有哪些变化的方法，这样浏览器可以在元素属性真正发生变化之前提前做好对应的优化准备工作。这种优化可以将一部分复杂的计算工作提前准备好，使页面的反应更为快速灵敏。

譬如：

    .sidebar {
      will-change: transform;
    }
    

这会使声明了该样式属性的元素生成一个图形层，告诉浏览器接下来该元素将会进行 transform 变换，让浏览器提前做好准备。

是的，这个属性是 CSS 中，除了 `transform: translateZ(0)` 外，**另外一种强制开启硬件加速的方式。**

这里，我们就得到了两种，强制可以让元素开启硬件加速的方式。

如何更好地理解硬件加速？我尝试讲讲我的理解。

当我们使用 `transform` 和 `opacity` 对元素进行动画时，浏览器会尝试优化这段动画。浏览器将所有内容作为纹理（texture）传输到 GPU，而不是对每一帧上的像素进行光栅化。GPU 非常擅长执行此类基于纹理的转换，因此，我们得到了非常流畅、高性能的动画，这称为“硬件加速”。

而有趣的是，GPU 和 CPU 对页面的渲染效果略有不同。当 CPU 将渲染任务交给 GPU 时，我们有时会看到页面动画有一些轻微的变化（譬如动画的抖动）。

而此时，`will-change` 就非常适合成为 GPU 和 CPU 之间的桥梁。通过 `will-change` 属性，提前告知浏览器，让浏览器提前做好准备。

当然，通过将元素的渲染委托给 GPU，它将消耗更多的内存资源，而这种资源是有限的，尤其是在低端移动设备上。

因此，想使用好 `will-change` 属性并不是很容易。

*   在一些低端盒子上，`will-change` 会导致很多小问题，譬如会使图片模糊，有的时候很容易适得其反，所以使用的时候还需要多加测试。
    
*   不要将 `will-change` 应用到太多元素上：浏览器已经尽力尝试去优化一切可以优化的东西了。有一些更强力的优化，如果与 `will-change` 结合在一起的话，有可能会消耗很多机器资源，如果过度使用的话，可能导致页面响应缓慢或者消耗非常多的资源。
    
*   有节制地使用：通常，当元素恢复到初始状态时，浏览器会丢弃掉之前做的优化工作。但是如果直接在样式表中显式声明了 will-change 属性，则表示目标元素可能会经常变化，浏览器会将优化工作保存得比之前更久。所以，最佳实践是当元素变化之前和之后通过脚本来切换 `will-change` 的值。
    
*   不要过早应用 `will-change` 优化：如果你的页面在性能方面没什么问题，则不要添加 `will-change` 属性来榨取一丁点的速度。 `will-change` 的设计初衷是作为最后的优化手段，用来尝试解决现有的性能问题。它不应该被用来预防性能问题。过度使用 `will-change` 会导致生成大量图层，进而导致大量的内存占用，并会导致更复杂的渲染过程，因为浏览器会试图准备可能存在的变化过程，这会导致更严重的性能问题。
    
*   给它足够的工作时间：这个属性是用来让页面开发者告知浏览器哪些属性可能会变化的。然后浏览器可以选择在变化发生前提前去做一些优化工作。所以给浏览器一点时间去真正做这些优化工作是非常重要的。使用时需要尝试去找到一些方法、提前一定时间获知元素可能发生的变化，然后为它加上 `will-change` 属性。
    

流程动画的标准，理解 FPS
--------------

最后，我们再来谈谈 FPS。

FPS 可以理解为我们常说的**刷新率**（单位为 Hz），例如我们常在游戏里说的“FPS 值”。在浏览器渲染页面的过程中，也有 FPS 这一概念。

理论上说，FPS 越高，动画会越流畅，目前大多数设备的屏幕刷新率为 60 次/秒，所以通常来讲 FPS 为 60 frame/s 时动画效果最好，也就是每帧的消耗时间为 16.67ms。

页面**不同帧率下，用户的直观体验：**

*   帧率能够达到 50 ～ 60 FPS 的动画将会相当流畅，让人倍感舒适；
*   帧率在 30 ～ 50 FPS 之间的动画，因各人敏感程度不同，舒适度因人而异；
*   帧率在 30 FPS 以下的动画，让人感觉到明显的卡顿和不适感；
*   帧率波动很大的动画，亦会使人感觉到卡顿。

我们经常说页面很卡、动画很卡。其本质含义就是页面渲染过程中 FPS 太低了。对于 FPS 很低的页面，我们需要去想办法优化它们。但是，优化之前，我们需要准确地知道，页面的 FPS 到底是多少。

那么，在今天，我们可以如何有效地去计算页面的 FPS 值呢？

在页面开发的过程中，我们可以打开这个面板（Chrome > More tools > Rendering > Frame Rendering Stats）：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8873837c9a0f4241aa72bc153cb08c7a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=196&h=187&s=15330&e=png&b=262626)

此时，页面上就会出现这么一个面板，右上角的绿色数字就会实时展现当前页面的 FPS 值。

> 我当前写作用的显示器，是支持 144FPS 高刷新率的显示器，因此页面静止状态下 FPS 能达到 144。

但是很多时候，我们想知道我们的动画效果在用户设备上的 FPS，这种方式显然是不适用的。（我们没法在页面的设备上一一打开这个界面，又或者如果是移动端页面，该怎么办呢？）

此时，我们需要另辟蹊径。

这里介绍一种基于 `requestAnimationFrame` 的方式。我们借助这个 API，可以近似地得到页面任意运行时的帧率。

原理是，正常而言 `requestAnimationFrame` 会在页面渲染的每一帧执行一次。因此，我们只需要计算 1s 内，这个方法被调用了多少次，就能近似地得到页面当前的 FPS 值。

假设动画在时间 A 开始执行，在时间 B 结束，耗时 x ms。而中间 `requestAnimationFrame` 一共执行了 n 次，则此段动画的帧率大致为：n / (B - A)。

核心代码如下：

    var rAF = function () {
        return (
            window.requestAnimationFrame ||
            window.webkitRequestAnimationFrame ||
            function (callback) {
                window.setTimeout(callback, 1000 / 60);
            }
        );
    }();
    
    var fps = 0;
    var frame = 0;
    var lastTime = Date.now();
    var lastFameTime = Date.now();
     
    var loop = function () {
        var now = Date.now();
     
        lastFameTime = now;
        frame++;
     
        if (now > 1000 + lastTime) {
            console.log(1)
            fps = Math.round((frame * 1000) / (now - lastTime));
            console.log('fps', fps); // 每秒 FPS
            frame = 0;
            lastTime = now;
        };
    
        rAF(loop);
    }
    
    loop();
    

可以将此段代码，复制到控制台，然后运行，再打开上面的 `Frame Rendering Stats` 面板，对比一下两者 FPS 展示的差异，可以看到两者的数据非常接近。因此，我们可以在实际业务中，通过这种方式统计页面的 FPS 值。

当然，实际使用的时候可能需要基于上述代码进行二次优化定制，譬如有的时候我们只需要统计某个动画过程中的 FPS 值，而不需要页面每时每刻的 FPS 值，以节省性能。

总结一下
----

OK，到此，我们已经介绍了非常多有关页面渲染以及 CSS 动画性能优化的知识点，我们再快速回顾一下：

1.  理解浏览器渲染页面（每一帧的渲染）过程，理解页面的性能优化的金字塔模型，尽可能减少页面的重绘和重排；
2.  理解浏览的 Composite Layers 与 GraphicsLayer，并且避免错误使用 GraphicsLayer；
3.  理解 CSS 中的耗性能样式；
4.  理解硬件加速，合理使用 will-change 属性；
5.  学会如何计算页面的 FPS 值，在优化前做到心中有“数据”，基于实际数据进行优化才能体现优化价值。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
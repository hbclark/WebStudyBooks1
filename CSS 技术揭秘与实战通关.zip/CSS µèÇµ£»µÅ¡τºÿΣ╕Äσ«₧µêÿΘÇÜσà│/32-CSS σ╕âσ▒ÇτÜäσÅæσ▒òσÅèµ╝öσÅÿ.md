CSS 随前端的发展日新月异，其中布局也经历了几次比较大的变迁，而布局又属于 CSS 中非常非常重要的一部分。万丈高楼平地起，如何更快、更轻松地把设计稿重构成页面，就非常考验一名 FEer 的水平与技巧。

布局的演进大致可以划分为：

> 表格布局 --> 定位布局 --> 浮动布局 --> Flex 布局 --> Grid 布局

当然，上述只是一个大概的演进路线，到了今天，**表格布局**、**定位布局**、**浮动布局**的地位虽然逐渐被 `flex`、`Grid` 布局取掉，但依然占据了非常重要的角色。

我们说的布局演进，更合适的理解方法是，过去的一些复杂布局，随着新的布局属性诞生及浏览器的大面积支持，有了更为轻松的解法。

“有时，常识虽易知而难行，有时，常识须推陈而出新”。人的想象力和创造力很容易在对常识的一贯认知中被削弱。

过去是最好的解法，今天可能有了新的替代解法，未来也有被其他新的更好的解法替代的可能。

像是下面这几个这样。

不拘一格的线条：

![](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4504a7f498b94c82ab09402f27b8a6ae~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1280&h=610&s=243537&e=png&b=0f0e17)

文字随图片的边缘排列：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a2efab4a7cbc42f4b50783301634a6d8~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=738&h=550&s=294018&e=png&b=f8f7f7)

不再是横平竖直：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/72d9ada6365247b8aa616200fb63a71c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=871&h=716&s=323005&e=png&b=c3a339)

又或者造型怪异的网格：

![](https://p9-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e206d4f263bc4706a9309951a560086e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=500&h=591&s=342438&e=png&b=080808)

是不是很有意思？不拘一格的布局能够给页面吸引更多的目光和流量，当然这也需要我们对 CSS 掌握得足够好，才能在有限的属性中创造更多不同的可能性。

我们一起来看看，在今天，基于布局的发展及演变，出现的一些有趣的布局技巧及方式。

flex 布局
-------

flex 布局（也被称为弹性布局），是当下最流行、适用性最广泛的布局方式，也是大伙在今天最应该完全掌握的布局方式。

其相对于之前的浮动布局和定位布局具有如下优势：

1.  **简洁直观**：Flex 布局采用了更加简单直观的语法，通过父容器设置 flex 属性来控制子元素的排布方式，不需要涉及浮动和定位等复杂的概念和属性。
    
2.  **自适应性强**：Flex 布局非常适合构建响应式的布局，它可以根据容器的大小自动调整子元素的大小和位置，使得布局更具弹性和适应性。
    
3.  **空间分配灵活**：Flex 布局通过 flex 属性来控制子元素在主轴方向上的空间分配比例，可以精确地设置每个子元素的占比，实现灵活的布局效果。而在浮动布局和定位布局中，通常需要手动计算和设置宽度或使用百分比布局。
    
4.  **直观的可视化效果**：Flex 布局可以简单直观地实现子元素的水平和垂直居中、两端对齐等效果，而在浮动布局和定位布局中，可能需要使用额外的技巧和属性来实现相同的效果。
    
5.  **性能优化**：相比于浮动布局，Flex 布局的性能更好。浮动布局在复杂布局中可能会引起性能问题，而 Flex 布局则更加高效且使用简单。
    

flex 布局的基础教学，不是本章的内容，市面上相关的教程多如春笋，本文将聚焦于 flex 布局中一些有意思的技巧。我们一起来看看。

### 巧用 margin：auto 分配剩余空间

来看这么一个最简单的例子。

在 `display:flex` 布局出现之前，我们如果想实现水平，也就是横轴方向元素的居中，可以使用 `margin: 0 auto`：

        <div class="g-container">
            <div class="g-box"></div>
        </div>
    

        .g-container {
            height: 300px;
            display: block;
            background: #000;
        }
    
        .g-box {
            width: 100px;
            height: 100px;
            background: #fff;
            margin: 0 auto;
        }
    

结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5545226e5e4742b99cc443df3ab049f8~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=200&s=755&e=png&b=000000)

我们实现了元素 `.g-box` 在水平方向的居中。

那么，有意思的问题来了，如何让 `margin: auto` 在垂直方向上生效？

换句话说，传统的 `display: block` 容器下，为什么 `margin: auto` 在水平方向可以居中元素在垂直方向却不行？

通常我们会使用这段代码：

        div {
            width: 100px;
            height: 100px;
            margin: 0 auto;
        }
    

让元素相对父元素水平居中。但是如果我们想让元素相对父元素垂直居中的话，使用 `margin: 0 auto` 是不生效的。

查看 CSS 文档，原因如下，在 `display: block` 下：

If both margin-left and margin-right are auto, their used values are equal, causing horizontal centring.

> —CSS2 Visual formatting model details: 10.3.3

If margin-top, or margin-bottom are auto, their used value is 0.

> —[CSS2 Visual formatting model details: 10.6.3](https://www.w3.org/TR/CSS2/visudet.html#Computing_heights_and_margins "https://www.w3.org/TR/CSS2/visudet.html#Computing_heights_and_margins")

简单翻译下，在 `display: block` 中，如果 `margin-left` 和 `margin-right` 都是 auto，则它们的表达值相等，从而导致元素的水平居中（这里的计算值为元素剩余可用剩余空间的一半）。

而如果 `margin-top` 和 `margin-bottom` 都是 auto，则它们的值都为 0，当然也就无法造成垂直方向上的居中。

这里要使单个元素使用 `margin: auto` 在垂直方向上能够居中元素，需要让该元素处于 FFC（flex formatting context），或者 GFC（grid formatting context）上下文中，也就是这些取值中：

        {
            display: flex;
            display: inline-flex;
            display: grid;
            display: inline-grid;
        }
    

什么意思呢？

也就是在今天，**我们可以利用 `display: flex`** **等 flex、** **grid** **布局上下文下，利用** **`margin: auto`** **实现元素的水平垂直居中！**

代码如下：

        <div class="g-container">
            <div class="g-box"></div>
        </div>
    

        .g-container {
            display: flex;
        }
    
        .g-box {
            margin: auto;
        }
    

> 上面的 `display: flex` 替换成 `display: inline-flex | grid | inline-grid` 也是可以的。

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/08d8e081354d43e9a39f35682eaed9ac~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=410&h=289&s=1156&e=png&b=000000)

> 相关代码，戳这里：[CodePen Demo -- 使用 margin auto 水平垂直居中元素](https://codepen.io/Chokcoco/pen/GarPev "https://codepen.io/Chokcoco/pen/GarPev")

原理是什么？查看 CSS 文档，原因如下，在 `dispaly: flex` 下：

> Prior to alignment via justify-content and align-self, any positive free space is distributed to auto margins in that dimension.

> [CSS Flexible Box Layout Module Level 1 -- 8.1. Aligning with auto margins](https://www.w3.org/TR/2018/CR-css-flexbox-1-20181119/#auto-margins "https://www.w3.org/TR/2018/CR-css-flexbox-1-20181119/#auto-margins")

简单翻译一下，大意是在 **flex 格式化上下文**中，设置了 `margin: auto` 的元素，在通过 `justify-content` 和 `align-self` 进行对齐之前，任何正处于空闲的空间都会分配到该方向的自动 margin 中去。

这里，很重要的一点是，margin auto 的生效不仅是水平方向，垂直方向也会自动去分配这个剩余空间。

无论是多个方向的自动 margin，抑或是单方向的自动 margin，都是非常有用的。

再来看几个有意思的例子。

### 使用 `margin-left: auto` 实现不规则两端对齐布局

假设我们需要有如下布局：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ffac60a334f54a5594cddcb72dc2a11e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=2080&h=190&s=20042&e=png&b=367b66)

DOM 结构如下：

        <ul class="g-nav">
          <li>导航A</li>
          <li>导航B</li>
          <li>导航C</li>
          <li>导航D</li>
          <li class="g-login">登陆</li>
        </ul>
    

对最后一个元素使用 `margin-left: auto`，可以很容易实现这个布局：

        .g-nav {
            display: flex;
        }
    
        .g-login {
            margin-left: auto;
        }
    

此时， `auto` 的计算值就是水平方向上容器排列所有 li 之后的剩余空间。

当然，不一定是要运用在第一个或者最后一个元素之上，例如这样的布局，也是完全一样的实现：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/78fe402a124346e6ba471910bb0e7e30~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=2078&h=190&s=22263&e=png&b=367b66)

        <ul class="g-nav">
          <li>导航A</li>
          <li>导航B</li>
          <li>导航C</li>
          <li>导航D</li>
          <li class="g-login">登陆</li><li>注册</li>
        </ul>
    

        .g-nav {
            display: flex;
        }
    
        .g-login {
            margin-left: auto;
        }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8a90ed60c860445cbe22efed99eb350a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1001&h=231&s=36371&e=gif&f=20&b=047d65)

是不很有意思？记住一点核心关键点：**在通过** **`justify-content`** **和** **`align-self`** **进行对齐之前，任何正处于空闲的空间都会分配到该维度中的自动 margin 中去。**

> 完整的代码，你可以戳这里：[Codepen Demo -- nav list by margin left auto](https://codepen.io/Chokcoco/pen/eaGmyv "https://codepen.io/Chokcoco/pen/eaGmyv")

不仅如此，在了解了 flex 布局下的 `margin:auto` 的特性后，就可以**使用自动 margin 实现 flex 布局下的** **`space-between | space-around`。**

### 自动 margin 实现 `space-around`

对于这样一个 flex 布局：

        <ul class="g-flex">
          <li>liA</li>
          <li>liB</li>
          <li>liC</li>
          <li>liD</li>
          <li>liE</li>
        </ul>
    

如果它的 CSS 代码是：

        .g-flex {
            display: flex;
            justify-content: space-around;
        }
    
        li { ... }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/42e42dffa0194ba58db413f8b397dc3e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1820&h=194&s=11240&e=png&b=367b66)

那么下面的 CSS 代码与上面的效果是完全等同的：

        .g-flex {
            display: flex;
            // justify-content: space-around;
        }
    
        li { 
            margin: auto;
        }
    

> 完整的代码，你可以戳这里：[CodePen Demo -- margin auto 实现 flex 下的 space-around](https://codepen.io/Chokcoco/pen/rgYOVo "https://codepen.io/Chokcoco/pen/rgYOVo")

### 自动 margin 实现 `space-between`

同理，使用自动 margin，也很容易实现 flex 下的 `space-between`，下面两份 CSS 代码的效果的一样的：

        .g-flex {
            display: flex;
            justify-content: space-between;
        }
    
        li {...}
    

与下面这份代码，布局效果是一样的：

        .g-flex {
            display: flex;
            // justify-content: space-between;
        }
    
        li {
            margin: auto;
        }
    
        li:first-child {
            margin-left: 0;
        }
    
        li:last-child {
            margin-right: 0;
        }
    

> 完整的代码，你可以戳这里：[CodePen Demo -- margin auto 实现 flex 下的 space-between](https://codepen.io/Chokcoco/pen/gJXawm "https://codepen.io/Chokcoco/pen/gJXawm")

当然，值得注意的是，很重要的一点：

Note: If free space is distributed to auto margins, the alignment properties will have no effect in that dimension because the margins will have stolen all the free space left over after flexing.

> [CSS Flexible Box Layout Module Level 1 -- 8.1. Aligning with auto margins](https://www.w3.org/TR/2018/CR-css-flexbox-1-20181119/#auto-margins "https://www.w3.org/TR/2018/CR-css-flexbox-1-20181119/#auto-margins")

意思是，如果任意方向上的可用空间分配给了该方向的自动 margin ，则对齐属性（justify-content/align-self）在该维度中不起作用，因为 margin 将在排布后窃取该纬度方向剩余的所有可用空间。

也就是使用了自动 margin 的 flex 子项目，它们父元素设置的 `justify-content` 以及它们本身的 `align-self` 将不再生效，也就是这里存在一个优先级的关系。

### 使用 margin: auto 需要注意的点

自动 margin 还是很实用的，可以使用的场景也很多，有一些上面提到的点还需要再强调下：

*   **块格式化上下文**中`margin-top` 和 `margin-bottom` 的值如果是 auto，则它们的值都为 0。
*   **flex 格式化上下文**中，在通过 `justify-content` 和 `align-self` 进行对齐之前，任何正处于空闲的空间都会分配到该方向的自动 margin 中去。
*   单个方向上的自动 margin 也非常有用，它的计算值为该方向上的剩余空间。
*   使用了自动 margin 的 flex 子项目，它们父元素设置的 `justify-content` 以及它们本身的 `align-self` 将不再生效。

### 利用 gap 快速生成布局间隙

有一种快速设置 flex-item 及 grid-item 间隙的方式，还有很多人不清楚。那就是 `gap` 属性。

CSS 属性 `gap` 用于设置容器中子元素之间的间隔（或称为缝隙）。它是一个简洁且灵活的方式来控制元素之间的空隙，尤其在使用 Flexbox 或 Grid 布局时非常实用。

> 在最早期，gap 其实是只适用于 grid 布局的。`grid-gap` 是 `gap` 属性的旧写法，自 CSS Grid Layout Level 1 被引入。而 `gap` 是 CSS Grid Layout Level 2 新增的更简化的写法，不仅适用于 grid 布局，也同样能在 flex 布局中使用。

来看这么一个简单的布局：

        <ul>
            <li>1</li>
            <li>2</li>
            <li>3</li>
            <li>4</li>
            <li>5</li>
            <li>6</li>
            <li>7</li>
            <li>8</li>
        </ul>
    

        ul {
            width: 420px;
            height: 300px;
            background: #fff;
            display: flex;
            flex-wrap: wrap;
        }
        li {
            flex-shrink: 0;
            width: 100px;
            height: 100px;
            background: #000;
        }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/484dcac62cce4a3e86e2611a2e4fd777~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=419&h=298&s=2174&e=png&b=000000)

可以使用 `gap` 快速给 flex-item 添加间距效果：

        ul{
          //...
          gap: 10px;
        }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/008177a78d7444eba5b50f1cf2749895~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=441&h=248&s=2419&e=png&b=000000)

可以看到，每个 flex-item 之间添加了 `10px` 的间隙。需要注意的是，flex-item 与容器的边缘是不会产生 gap 的，这一点在使用的过程中需要十分注意。

同时，`gap` 还有一种写法：

        ul{
          //...
          gap: 5px 20px;
        }
    

如果提供两个值，第一个值将应用于行间距，第二个值将应用于列间距。效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ec9c586b16cd491ba1537c6d32e85473~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=460&h=212&s=2088&e=png&b=000000)

grid 布局
-------

说到新时代布局和创意布局，就不得不提到 Grid 的布局。

CSS Grid 布局的二维特性，让我们相较于传统的 float 布局、定位布局、flex 布局有了对页面更强大的掌控力。

### 利用 Grid 布局，切割页面进行分块

Grid 想必大家也不陌生了，需要注意的是，它是一种**二维网格系统**，可以更灵活地控制元素在容器中的布局和对齐方式。

使用 Grid 布局可以将页面划分为多个行和列，然后通过定义网格单元格的大小、位置和间距来放置和调整元素。

相对于 Flex 布局，Grid 布局具有以下核心优势：

1.  **二维布局**：Grid 布局支持二维的网格系统，可以同时控制行和列的布局。这意味着你可以更方便地在水平和垂直方向上进行布局控制，更灵活地实现复杂的页面布局。
    
    这里，有一个非常重要的知识点。Grid 是一个二维的网格系统，而 Flex 只是一维的网格系统。虽然 `flex` 布局中存在 `flex-direction` 可以选择主轴方向，但是，`flex` 相对于交叉轴的控制力会弱上许多。
    
    *   flexbox 是一维布局，它只能在一条直线上放置你的内容区块；
    *   而 grid 是一个二维布局，它除了可以灵活地控制水平方向之外，还能轻易地控制垂直方向的布局模式。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/8f41d1c8868345ce9039765cdaecb465~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1662&h=463&s=73861&e=png&b=ffffff)

2.  **自动对齐**：Grid 布局提供了丰富的对齐和对齐方式的控制选项。你可以设置元素在网格单元格内的对齐方式（如顶部对齐、居中对齐、底部对齐），以及元素之间的对齐方式（如水平对齐、垂直对齐）。这使得对齐更加简单和精确。
3.  **网格线和轨道**：Grid 布局引入了网格线和轨道的概念。网格线可以用来定义网格单元格的边界和位置，而轨道是相邻网格线之间的区域。这使得元素的大小和位置控制更加直观和精细。
4.  **控制单元格大小**：Grid 布局允许你通过设置网格单元格的大小和跨越多个单元格来控制元素的布局。你可以指定每个单元格的大小，也可以使用 `span` 属性来跨越多个单元格。这为实现灵活的自适应布局提供了更强大的能力。
5.  **响应式布局**：与 Flex 布局类似，Grid 布局也可以用于创建响应式布局。你可以通过媒体查询或自动放置单元格来调整网格布局，以适应不同的屏幕尺寸和设备。

需要注意的是，Flex 布局和 Grid 布局并不是互斥的，它们可以结合使用，根据具体的布局需求选择合适的工具。Flex 布局更适用于一维布局（如水平或垂直排列的元素），而 Grid 布局更适用于二维布局（如网格状排列的元素）。

利用 Grid 布局的特性，可以将页面按照我们的所想任意切割成不同的块状区域。由于 Grid 布局肯定也不是一章能够展开说完的，本章节更多的是讲一讲现阶段或者未来，一些使用 Grid 进行布局更优势的地方。

首先，推荐一些能够方便我们进行 Grid 布局的工具：[快速进行 Grid 布局 - Grid Layoutit](https://grid.layoutit.com/ "https://grid.layoutit.com/")。

利用这个工具，可以快速创建得到自己想要 Grid 布局，并且拿到对应的 CSS，非常的简单便捷。

这里我利用工具，将页面切割成了 A、B、C、D、E、F 6 块区域：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/68218e22c257436c99a15e7fc7277610~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1223&h=544&s=89395&e=png&b=fcfcfc)

复制右侧的 HTML 和 CSS，可以快速得到这样一个布局，我把代码拷贝到了 CodePen，简单添加了一下底色，我们就可以基于这个布局再去做任何事情：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f6a61596aeeb4e6f8091693c4db435fd~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=757&h=484&s=4461&e=png&b=ff246d)

> 完整代码，戳这里：[CodePen Demo -- Grid Layout Demo](https://codepen.io/Chokcoco/pen/ExWWevq "https://codepen.io/Chokcoco/pen/ExWWevq")

### 利用 Grid 布局配合 clip-path 实现 GTA5 封面

这里，我们可以利用 Grid 布局配合 clip-path 实现 GTA5 封面，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f743c9bdaba045f08b8eb4e7f89d9a19~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=311&h=495&s=237898&e=png&b=dfd8b6)

我们将一个 4x4 的 Grid 网格，分割为 9 个不同的部分：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/80813683ad1b4ec0b1dad7db0688f440~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=720&h=372&s=23734&e=png&b=5ed2d2)

再利用 clip-path，根据封面图片的的造型，对每一块 Gird item 进行二次裁剪：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/20bd99eda47d4c208fe6d4f393f6de21~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1107&h=375&s=38197&e=png&b=59d5c9)

OK，最后把里面的色块替换成具体的图片即可：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/4fa746dffc854168b1120d653e5a2b4c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1479&h=370&s=221644&e=png&b=59d5cd)

> 完整代码，戳这里：[CodePen Demo -- GTA 5 poster ( Grid and Clip Path)](https://codepen.io/Chokcoco/pen/jOVjxjo "https://codepen.io/Chokcoco/pen/jOVjxjo")

当然这里有一个槽点，最终还是用了 9 张图片，那为什么不一开始直接用一张图片呢？

Grid 是在进行复杂布局的过程中非常好的帮手，它非常适合各种不规则网格块的布局，这里再提供一个 Demo：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c3f437fc6b32444cb159cfde77285662~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=686&h=305&s=53001&e=png&b=f1e9c7)

> 作者是 [Olivia Ng](https://codepen.io/oliviale "https://codepen.io/oliviale")，Demo 的链接 -- [CodePen Demo -- CSS Grid: Train Ticket](https://codepen.io/oliviale/pen/MZZYyO "https://codepen.io/oliviale/pen/MZZYyO")

瀑布流布局在现代布局中也非常常见，通常在一些照片墙中使用。像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ba20ec02f3594e1c9bde71894738f95c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=831&h=548&s=503553&e=png&b=efe9e6)

在之前，不借助 JavaScript，我们有 3 种纯 CSS 的方式可以实现**伪瀑布流**布局（注意，这里是伪瀑布流），分别是：

*   [使用 CSS column 实现瀑布流布局](https://chokcoco.github.io/CSS-Inspiration/#/./layout/masonry-layout-colum "https://chokcoco.github.io/CSS-Inspiration/#/./layout/masonry-layout-colum")
*   [使用 CSS flex 实现瀑布流布局](https://chokcoco.github.io/CSS-Inspiration/#/./layout/masonry-layout-flex "https://chokcoco.github.io/CSS-Inspiration/#/./layout/masonry-layout-flex")
*   [使用 CSS grid 实现瀑布流布局](https://chokcoco.github.io/CSS-Inspiration/#/./layout/masonry-layout-grid "https://chokcoco.github.io/CSS-Inspiration/#/./layout/masonry-layout-grid")

你可以点进 Demo 看看，利用上述三种方式实现的瀑布流布局，缺点比较明显：

*   对于 flex 和 column 布局而言，只能实现竖直排布的瀑布流布局，第一列填充满了填充第二列，以此类推；
*   对于 Grid 布局而言，缺点则是无法自动适配不同的高度，需要手动指定每一个元素区块大小。

而在未来，标准基于 Grid 布局实现了 `grid-template-rows: masonry`，利用该标准，我们可以快速利用 Grid 实现水平排布的瀑布流布局，目前，你可以在 Firefox 体验该功能。

### 使用 `grid-template-rows: masonry` 实现水平方向排布的瀑布流布局

`grid-template-rows: masonry` 是 firefox 在 firefox 87 开始支持的一种基于 grid 布局快速创建瀑布流布局的方式，并且 firefox 一直在推动该属性进入标准当中。

从 firefox 87 开始，在浏览器输入网址栏输入 `about:config` 并且开启 `layout.css.grid-template-masonry-value.enabled` 配置使用。

截止到本文写作的今天（2023-08-06），我们来看看它的[兼容性](https://caniuse.com/?search=grid-template-rows%3A%20masonry "https://caniuse.com/?search=grid-template-rows%3A%20masonry")：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1af34daa126b47b5acff3e4e99992c6c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1375&h=664&s=96913&e=png&b=eadabb)

正常而言，我们想要实现瀑布流布局还是需要花费一定的功夫的，即便是基于 grid 布局。在之前，我们通过 grid 布局，通过精细化控制每一个 `grid item`，可以实现竖直方向的瀑布流布局：

        <div class="g-container">  
          <div class="g-item">1</div>
          <div class="g-item">2</div>
          <div class="g-item">3</div>
          <div class="g-item">4</div>
          <div class="g-item">5</div>
          <div class="g-item">6</div>
          <div class="g-item">7</div>
          <div class="g-item">8</div>
        </div>
    

        .g-container {   
          height: 100vh;    
          display: grid;    
          grid-template-columns: repeat(4, 1fr);    
          grid-template-rows: repeat(8, 1fr);
        }
        .g-item {    
          &:nth-child(1) {        
            grid-column: 1;        
            grid-row: 1 / 3;    
          }    
          &:nth-child(2) {        
            grid-column: 2;        
            grid-row: 1 / 4;    
          }    
          &:nth-child(3) {        
            grid-column: 3;        
            grid-row: 1 / 5;    
          }    
          &:nth-child(4) {        
            grid-column: 4;        
            grid-row: 1 / 6;    
          }    
          &:nth-child(5) {        
            grid-column: 1;        
            grid-row: 3 / 9;   
          }    
          &:nth-child(6) {        
            grid-column: 2;        
            grid-row: 4 / 9;    
          }    
          &:nth-child(7) {        
            grid-column: 3;        
            grid-row: 5 / 9;    
          }    
          &:nth-child(8) {        
            grid-column: 4;       
            grid-row: 6 / 9;    
          }
        }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/cdcc316da14b47078ddd3fbc7298fdff~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1360&h=259&s=6219&e=png&b=7c19c8)

> 完整代码，戳这里：[CodePen Demo -- CSS Grid 实现伪瀑布流布局](https://codepen.io/Chokcoco/pen/KGXqyo "https://codepen.io/Chokcoco/pen/KGXqyo")

在上述 Demo 中，使用 `grid-template-columns`、`grid-template-rows` 分割行列，使用 `grid-row` 控制每个 `grid item` 的所占格子的大小，但是这样做的成本太高了，元素一多，计算量也非常大，并且还是在我们提前知道每个元素的高宽的前提下。

而在有了 `grid-template-rows: masonry` 之后，一切都会变得简单许多，对于一个不确定每个元素高度的 4 列的 grid 布局：

        .container {  
          display: grid;  
          grid-template-columns: repeat(4, 1fr);
        }
    

正常而言，看到的会是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c0409225d026488283aed291d0662fe2~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=965&h=524&s=6491&e=png&b=ffffff)

简单地给容器加上 `grid-template-rows: masonry`，表示竖方向上，采用瀑布流布局：

        .container {  
          display: grid;  
          grid-template-columns: repeat(4, 1fr);
        + grid-template-rows: masonry;
        }
    

便可以轻松地得到这样一种水平方向顺序排布元素的瀑布流布局：

![](https://p6-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/560e9442255f42809ef296655f2fca56~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=982&h=432&s=6104&e=png&b=ffffff)

如果你在使用 firefox，并且开启了 `layout.css.grid-template-masonry-value.enabled` 配置，可以戳进下面的 Demo 感受一下：

> [CodePen Demo -- grid-template-rows: masonry 实现瀑布流布局](https://codepen.io/Chokcoco/pen/NWdBojd "https://codepen.io/Chokcoco/pen/NWdBojd")

多栏布局
----

多栏布局也属于现在我们能够掌控的布局之一，利用 CSS 较为新的特性 [Multiple-column Layout Properties](https://drafts.csswg.org/css-multicol-1/ "https://drafts.csswg.org/css-multicol-1/")。

最简单的多栏布局，我们只需要用到 `column-count` 或者 `column-width`。

假设我们有如下 HTML：

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit...</p>
    

简单的 3 列布局：

        p {    width: 800px;    column-count: 3;    font-size: 16px;    line-height: 2;}
    

通过 `column-count: 3` 指定 3 栏。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dda563c4fb4844d58309299baee3b63b~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=742&h=145&s=16213&e=png&b=fdfdfd)

### column-gap 控制间距 & column-rule 控制列与列间样式

接下来，我们再了解下 `column-gap` 和 `column-rule`。

*   column-gap：控制列与列之间的间隔，默认为关键字 `normal`，数值上为 `1em`。
*   column-rule：控制列与列之间的样式规则，其写法与 `border` 类似，指定列之间的装饰线。

还是如下 HTML：

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit...</p>
    

简单的 3 列布局：

    p {    
        width: 800px;    
        column-count: 3;    
        font-size: 16px;    
        line-height: 2;
      + column: 1px solid #999;
      + column-gap: 2em;
    }
    

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d1c67cf85ba64dd7b0b44727657aaf4d~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=761&h=139&s=23134&e=png&b=fefefe)

> 完整代码，戳这里：[CodePen Demo -- CSS multi column Layout Demo](https://codepen.io/Chokcoco/pen/PoppVKx "https://codepen.io/Chokcoco/pen/PoppVKx")

### column-span 设置跨列

接着，还有一个很有意思的属性 `column-span`，用于设置元素的跨列展示。

我们首先利用多列布局，实现这样一个类似于报纸排版的布局样式。

    <div class="g-container">
      <p>Lorem ipsum dolor sit amet ... </p>
      <h2>Title Lorem ipsum dolor sit amet consectetur adipisicing elit title</h2>    
      <p>Lorem ipsum dolor sit amet ... </p>
    </div>
    

    .g-container {    
      width: 800px;    
      column-count: 3;    
      column-rule: 1px solid #aaa;    
      column-gap: 2em;
    }
      
    h2 {    
      margin: 14px 0;    
      font-size: 24px;    
      line-height: 1.4;
    }
    

大概就是多列布局中嵌套标题，标题加粗并且字号大一点：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0442fabf2b654ce6abdd1956a201cbb6~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=812&h=262&s=61558&e=png&b=fdfdfd)

通过给 `h2` 设置 `column-span: all`，让 `h2` 标题跨列多列进行展示，改动一下 CSS：

    h2 {    
      margin: 14px 0;    
      font-size: 24px;    
      line-height: 1.4;
    + column-span: all;
    + text-align: center;
    }
    

即可得到这样一个布局：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/90ada57d61844c4d9aa7c8f0dec4f3ee~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=768&h=321&s=57795&e=png&b=fdfdfd)

> 完整代码，戳这里：[CodePen Demo -- CSS multi column Layout Demo 2](https://codepen.io/Chokcoco/pen/QWpvgqK "https://codepen.io/Chokcoco/pen/QWpvgqK")

### 多栏布局搭配其他布局实现更复杂的布局

当然，`column-span` 有个缺陷，就是它的取值只有 `column-span: all` 或者是 `column-span: none`，也就是要么横跨所有的列，要么不跨列。

如果现在我有一个 3 列布局，但是只希望其中的标题横跨两列，`column-span: all` 就无法实现了。

但是，通过嵌套其他布局，我们可以巧妙地对多列布局再进行升华，譬如 [rachelandrew](https://codepen.io/rachelandrew "https://codepen.io/rachelandrew") 就实现了这样一种嵌套布局：

    <div class="container"> 
      <article>    
        <p>By way of precaution ...</p>    
        <h2>the first that ever burst Into that silent sea;</h2>    
        <p>and with what ...</p>  
      </article>  
      <aside>      
        <img src="demo.jpg">      
        <figcaption>The Authoress, her Father and Mr. Spencer making an ascent</figcaption>
      </aside>
    </div>
    

通过一个 2 列的 Grid 布局，嵌套一个两列的 multi-column 布局，大致的 CSS 如下：

    .container {  
      max-width: 800px;  
      display: grid;  
      grid-gap: 1em;  
      grid-template-columns: 2fr 1fr; 
      align-items: start;
    }
    h2 {  
      column-span: all;  
      text-align: center;
    }
    .container article {  
      column-count: 2;  
      column-gap: 2em;  
      column-rule: 1px solid #ccc;
    }
    .container aside {  
      border-left: 1px solid #ccc;  
      padding: 0 1em;
    }
    

这样，我们就能实现视觉上的横跨任意列的标题：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/97dc308e386449f3a9095824f57dfec5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=804&h=367&s=172396&e=png&b=fbfbfb)

> 完整的 Demo 代码，你可以戳这里：[CodePen Demo -- Smashing Multicol: mixing layout methods -- By rachelandrew](https://codepen.io/rachelandrew/pen/aPRjzL "https://codepen.io/rachelandrew/pen/aPRjzL")

shape-outside 让布局插上想象的翅膀
------------------------

OK，进入下一个模块，主角是 `shape-outside`。

在之前，我也有写过一篇关于 `shape-outside` 的文章[《奇妙的 CSS shapes》](https://github.com/chokcoco/iCSS/issues/18 "https://github.com/chokcoco/iCSS/issues/18")，感兴趣的同学也可以先看看。

[shape-outside](https://developer.mozilla.org/zh-CN/docs/Web/CSS/shape-outside "https://developer.mozilla.org/zh-CN/docs/Web/CSS/shape-outside") CSS 属性定义了一个可以是非矩形的形状，相邻的内联内容应围绕该形状进行包装。

利用它，我们就能够很好地实现各种非横平竖直的布局，让布局真正地**活**起来。

图文排列的交界处，可以是斜的，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/87920e8a87eb4106b696532194ef4e15~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=724&h=334&s=139835&e=png&b=1a1717)

> 完整代码，戳这里：[CodePen Demo -- FCC: Build a Tribute Page - Michel Thomas by Stephanie](https://codepen.io/StuffieStephie/pen/ZLmzKG "https://codepen.io/StuffieStephie/pen/ZLmzKG")

也可以是弯曲的，像是这样：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/9c8528cbbc0843db984f54274366db30~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=861&h=485&s=185158&e=png&b=000000)

> 完整代码，戳这里：[CodePen Demo -- shape-outside: circle Demo](https://codepen.io/Chokcoco/pen/LYWyOaa "https://codepen.io/Chokcoco/pen/LYWyOaa")

甚至，它还可以是动态变化的不规则容器：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3c01174755184d368436547a447d2d23~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=337&s=3785599&e=gif&f=56&b=fdf5fc)

> 完整代码，戳：[CodePen Demo -- shape-outside animation](https://codepen.io/Chokcoco/pen/RwpgmaK "https://codepen.io/Chokcoco/pen/RwpgmaK")

合理使用，我们就可以如报纸般创造各种花式布局效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a8ed2cb9eaa345c1a8ae50831f0c9bb2~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1839&h=940&s=1553885&e=png&b=e8e8e8)

不仅如此，[袁川老师](https://twitter.com/yuanchuan23 "https://twitter.com/yuanchuan23")甚至使用 `shape-outside` 进行了一些 CSS 艺术创作，一起欣赏一下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a18b569bfdbe451bbb97baccc09c4e84~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=500&h=422&s=3604558&e=gif&f=29&b=ad3485)

> 完整代码，戳这里：[CodePen Demo -- shape-outside -- Face By yuanchuan](https://codepen.io/yuanchuan/pen/xoKMKj "https://codepen.io/yuanchuan/pen/xoKMKj")

以开篇的这张图为例子：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/129f8643efe74118a4834d37d03f2f7e~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=537&h=472&s=176531&e=png&b=efebd1)

就是巧妙地运用 `shape-outside` 的例子，它将整个布局分为了 7 块，每一块分别使用 `shape-outside` 进行精细化的控制，实际上完整的布局是这样的：

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bfe9bffa977a4e258353248686bfe7ec~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=592&h=556&s=150478&e=png&b=f0f0f0)

在这篇文章中，对这个 Demo 进行了非常详细的阐述：[A CSS Venn Diagram](https://adrianroselli.com/2018/12/a-css-venn-diagram.html "https://adrianroselli.com/2018/12/a-css-venn-diagram.html")。

如果你也对 `shape-outside` 感兴趣，在这份收藏夹里，收藏了 CodePen 上非常多精良的 `shape-outside` 布局 Demo，不妨一看学习学习 —— [CSS Shapes Experiments](https://codepen.io/collection/DYeRBR?cursor=ZD0wJm89MCZwPTEmdj00 "https://codepen.io/collection/DYeRBR?cursor=ZD0wJm89MCZwPTEmdj00")。

总结一下
----

到了今天，**表格布局**、**定位布局**、**浮动布局**的地位虽然逐渐被 flex、Grid 布局取掉，但依然占据了非常重要的角色。

想在今天实现一些复杂、有创意的布局，需要我们掌握更多的 CSS 属性与技巧，本文介绍了几种基于布局的发展及演变，出现的一些有趣的布局技巧及方式。

*   利用 Flex 布局中的自动 margin，分配剩余空间。
*   利用 gap 快速生成 flex-item、grid-item 元素之间间距 gap。
*   Grid 布局全家桶以及利用 Grid 实现瀑布流布局。
*   多栏布局 multiple-column 及多栏布局嵌套其他布局。
*   `shape-outside` 的各种应用。
*   在上述布局中穿插使用 `clip-path`、`transform` 等属性以增强各种布局。

当然，CSS 能实现的远不止如此，像是滚动视差、3D 变换等等都是可以利用 CSS 实现并且再融合进布局当中的属性。当然这也需要我们有创造和发现美的眼睛和思维。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
本章节，我们将开启 CSS 中数学函数相关内容的学习。

在 CSS 世界中，其实存在非常多的函数，在之前的章节中，我们其实已经接触过了譬如 `Filter functions` 滤镜函数、`Transform functions` 变换函数中的 `translate()`、`rotate()` 等等。

而整个 CSS 函数家族中，还有一类能非常有效提升我们开发效率的，辅助我们写出健壮性更强的 CSS 代码的**数学函数**。在本章节中，我们将具体探讨已经被大规模兼容的如下几个数学函数：

*   calc()
*   min()
*   max()
*   clamp()
*   三角函数 sin()
*   三角函数 cos()
*   三角函数 tan()

其中，又可以分为三组：

1.  calc() 为一组，这个大家用得也比较多了，属于`基础运算类的数学函数`；
2.  min()、max()、clamp() 分为一组，意为`比较函数`，常作用于范围限定的场景；
3.  最后是 sin()、cos()、tan() 分为一组，就如它们的名字般，属于`三角函数类`。

下面，我们将逐一进行讲解。

calc() 运算函数
-----------

`calc()` 运算函数的作用是进行基本的算术运算。此 [CSS](https://developer.mozilla.org/zh-CN/docs/Web/CSS "https://developer.mozilla.org/zh-CN/docs/Web/CSS") 函数允许在声明 CSS 属性值时执行一些计算。

最简单的语法如下：

    div {
        width: calc(100% - 80px);
    }
    

在使用 `calc` 时，一些需要注意的点：

*   `+` 和 `-` 运算符的两边必须要有空白字符。比如，`calc(50% -8px)` 会被解析成为一个无效的表达式，必须写成`calc(8px + -50%)`。
*   `*` 和 `/` 这两个运算符前后不需要空白字符，但如果考虑到统一性，仍然推荐加上空白符。
*   用 0 作除数会使 HTML 解析器抛出异常。
*   涉及自动布局和固定布局的表格中的表列、表列组、表行、表行组和表单元格的宽度和高度百分比的数学表达式，auto 可视为已指定。
*   calc() 函数支持嵌套，但支持的方式是：把被嵌套的 calc() 函数全当成普通的括号。（所以，函数内直接用括号就好了。）
*   calc() 支持与 CSS 变量混合使用。

我们通过一个常见的例子，理解 `calc()` 的作用。

假设页面结构如下：

    <div class="g-container">
      <div class="g-content">Content</div>
      <div class="g-footer">Footer</div>
    </div>
    

页面的 `g-footer` 高为 80px，我们希望不管页面多长，`g-content` 部分都可以占满剩余空间，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/33f9b9c5bd1b48738c488a835070e9c6~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=403&h=337&s=5138&e=png&b=dddddd)

这种布局使用 flex 的弹性布局可以轻松实现，当然，也可以使用 `calc()` 实现：

    .g-container {
        height: 100vh;
    }
    .g-content {
        height: calc(100vh - 80px);
    }
    .g-footer {
        height: 80px;
    }
    

下面罗列一些 Calc() 的进阶技巧。

### Calc 中的加减法与乘除法的差异

注意，calc() 中的加减法与乘除法的差异：

    {
        font-size: calc(1rem + 10px);
        width: calc(100px + 10%);
    }
    

可以看到，加减法两边的操作数都是需要单位的，而乘除法，需要一个无单位数，仅仅表示一个倍率：

    {
        width: calc(100% / 7);
        animation-delay: calc(1s * 3);
    }
    

这是由于，在 CSS 中，是可以存在类似于 `-6px`、`-.5s` 这样的负数属性值的。为了避免与减法中的 `-` 减号混淆。在 `calc()` 中使用加减法时，加减法符号两边，一定需要一个空格。

### Calc 的嵌套

calc() 函数是可以嵌套使用的，像是这样：

    {
      width: calc(100vw - calc(100% - 64px));
    }
    

此时，内部的 calc() 函数可以退化写成一个括号即可，所以上述代码等价于：

    {
      width: calc(100vw - (100% - 64px));
    }
    

**也就是嵌套内的 calc()，calc 几个函数字符可以省略**。

### Calc 内不同单位的混合运算

calc() 支持不同单位的混合运算，对于长度，只要是属于长度相关的单位都可以进行混合运算，包含这些：

*   px
*   %
*   em
*   rem
*   in
*   mm
*   cm
*   pt
*   pc
*   ex
*   ch
*   vh
*   vw
*   vmin
*   vmax

这里有一个有意思的点，运算肯定是消耗性能的，早年间，有这样一段 CSS 代码，可以直接让 Chrome 浏览器崩溃 Crash：

    <div></div>
    

CSS 样式如下：

    div {
      --initial-level-0: calc(1vh + 1% + 1px + 1em + 1vw + 1cm);
    
      --level-1: calc(var(--initial-level-0) + var(--initial-level-0));
      --level-2: calc(var(--level-1) + var(--level-1));
      --level-3: calc(var(--level-2) + var(--level-2));
      --level-4: calc(var(--level-3) + var(--level-3));
      --level-5: calc(var(--level-4) + var(--level-4));
      --level-6: calc(var(--level-5) + var(--level-5));
      --level-7: calc(var(--level-6) + var(--level-6));
      --level-8: calc(var(--level-7) + var(--level-7));
      --level-9: calc(var(--level-8) + var(--level-8));
      --level-10: calc(var(--level-9) + var(--level-9));
      --level-11: calc(var(--level-10) + var(--level-10));
      --level-12: calc(var(--level-11) + var(--level-11));
      --level-13: calc(var(--level-12) + var(--level-12));
      --level-14: calc(var(--level-13) + var(--level-13));
      --level-15: calc(var(--level-14) + var(--level-14));
      --level-16: calc(var(--level-15) + var(--level-15));
      --level-17: calc(var(--level-16) + var(--level-16));
      --level-18: calc(var(--level-17) + var(--level-17));
      --level-19: calc(var(--level-18) + var(--level-18));
      --level-20: calc(var(--level-19) + var(--level-19));
      --level-21: calc(var(--level-20) + var(--level-20));
      --level-22: calc(var(--level-21) + var(--level-21));
      --level-23: calc(var(--level-22) + var(--level-22));
      --level-24: calc(var(--level-23) + var(--level-23));
      --level-25: calc(var(--level-24) + var(--level-24));
      --level-26: calc(var(--level-25) + var(--level-25));
      --level-27: calc(var(--level-26) + var(--level-26));
      --level-28: calc(var(--level-27) + var(--level-27));
      --level-29: calc(var(--level-28) + var(--level-28));
      --level-30: calc(var(--level-29) + var(--level-29));
    
      --level-final: calc(var(--level-30) + 1px);
    
        border-width: var(--level-final);                                 
        border-style: solid;
    }
    

可以看到，从 `--level-1` 到 `--level-30`，每次的运算量都是成倍的增长，最终到 `--level-final` 变量，展开将有 2^30 = **1073741824** 个 `--initial-level-0` 表达式的内容。

并且，每个 `--initial-level-0` 表达式的内容 —— `calc(1vh + 1% + 1px + 1em + 1vw + 1cm)`，在浏览器解析的时候，也已经足够复杂。

混合在一起，就导致了浏览器的 BOOM（Chrome 70 之前的版本），为了能看到效果，我们将上述样式赋给某个元素被 hover 的时候，得到如下效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0ff89338907a40f7b084df1c8a6e53af~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=521&h=295&s=46305&e=gif&f=20&b=232629)

当然，这个 Bug 目前已经被修复了，我们也可以通过这个小 Demo 了解到，一是 calc 是可以进行不同单位的混合运算的，另外一个就是注意具体使用的时候，如果计算量巨大，可能会导致性能上较大的消耗。

当然，**不要**将长度单位和非长度单位混合使用，像是这样：

    {
        animation-delay: calc(1s + 1px);
    }
    

### Calc 搭配 CSS 自定义变量使用

calc() 函数非常重要的一个特性就是，能够搭配 CSS 自定义以及 CSS @Property 变量一起使用。

最简单的一个 Demo：

    :root {
        --width: 10px;
    }
    div {
        width: calc(var(--width));
    }
    

当然，这样看上去，根本看不出这样的写法的作用，好像没有什么意义。实际应用场景中，会比上述的 Demo 要稍微复杂一些。

假设我们要实现这样一个 loading 动画效果，一开始只有 3 个球：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/102632f78ca8406882891b1cce404558~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=164&h=135&s=212336&e=gif&f=85&b=fefefe)

可能的写法是这样，我们给 3 个球都添加同一个旋转动画，然后分别控制它们的 `animation-delay`：

    <div class="g-container">
      <div class="g-item"></div>
      <div class="g-item"></div>
      <div class="g-item"></div>
    </div>
    

    .item:nth-child(1) {
        animation: rotate 3s infinite linear;
    }
    .item:nth-child(2) {
        animation: rotate 3s infinite -1s linear;
    }
    .item:nth-child(3) {
        animation: rotate 3s infinite -2s linear;
    }
    

如果有一天，这个动画需要扩展成 5 个球的话，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/0e46dd3290974209b1512ad3381d2e78~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=184&h=128&s=179139&e=gif&f=61&b=fefefe)

我们就不得已，得去既添加 HTML，又修改 CSS。而如果借助 Calc 和 CSS 变量，这个场景就可以稍微简化一下。

假设只有 3 个球：

    <div class="g-container">
        <div class="g-item" style="--delay: 0"></div>
        <div class="g-item" style="--delay: 1"></div>
        <div class="g-item" style="--delay: 2"></div>
    </div>
    

我们通过 HTML 的 Style 标签，传入 `--delay` 变量，在 CSS 中直接使用它们：

    .g-item {
        animation: rotate 3s infinite linear;
        animation-delay: calc(var(--delay) * -1s);
    }
    @keyframes rotate {
        to {
            transform: rotate(360deg);
        }
    }
    

而当动画修改成 5 个球时，我们就不需要修改 CSS，直接修改 HTML 即可，像是这样：

    <div class="g-container">
        <div class="g-item" style="--delay: 0"></div>
        <div class="g-item" style="--delay: 0.6"></div>
        <div class="g-item" style="--delay: 1.2"></div>
        <div class="g-item" style="--delay: 1.8"></div>
        <div class="g-item" style="--delay: 2.4"></div>
    </div>
    

核心的 CSS 还是这一句，不需要做任何修改：

    .g-item {
        animation-delay: calc(var(--delay) * -1s);
    }
    

> 完整的 Demo，你可以戳这里：[CodePen Demo -- Calc & CSS Variable Demo](https://codepen.io/Chokcoco/pen/OJzarJL "https://codepen.io/Chokcoco/pen/OJzarJL")

### calc 搭配自定义变量时候的默认值

还是上述的 Loading 动画效果，如果我的 HTML 标签中，有一个标签忘记填充 `--delay` 的值了，那会发生什么？

像是这样：

    <div class="g-container">
        <div class="g-item" style="--delay: 0"></div>
        <div class="g-item" style="--delay: 0.6"></div>
        <div class="g-item"></div>
        <div class="g-item" style="--delay: 1.8"></div>
        <div class="g-item" style="--delay: 2.4"></div>
    </div>
    

    .g-item {
        animation-delay: calc(var(--delay) * -1s);
    }
    

由于 HTML 标签没有传入 `--delay` 的值，并且在 CSS 中向上查找也没找到对应的值，此时，`animation-delay: calc(var(--delay) * -1s)` 这一句其实是无效的，相当于 `animation-delay: 0`，效果也就是少了个球的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a89bbff0974c46eaba25b3f64b641ad7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=239&h=259&s=8794&e=png&b=ffffff)

所以，基于这种情况，可以利用 CSS 自定义变量 `var()` 的 fallback 机制：

    .g-item {
        // (--delay, 1) 中的 1 是个容错机制
        animation-delay: calc(var(--delay, 1) * -1s);
    }
    

此时，如果没有读取到任何 `--delay` 值，就会使用默认的 1 与 `-1s` 进行运算。

### Calc 字符串拼接

很多人在使用 CSS 的时候，会尝试字符串的拼接，像是这样：

    <div style="--url: 'bsBD1I.png'"></div>
    

    :root {
        --urlA: 'url(https://s1.ax1x.com/2022/03/07/';
        --urlB: ')';
    }
    div {
        width: 400px;
        height: 400px;
        background-image: calc(var(--urlA) + var(--url) + var(--urlB));
    }
    

这里想利用 `calc(var(--urlA) + var(--url) + var(--urlB))` 拼出完整的在 `background-image` 中可使用的 URL `url(https://s1.ax1x.com/2022/03/07/bsBD1I.png)`。

然而，这是不被允许的（无法实现的）。**calc 没有字符串拼接的能力**。

唯一可能完成字符串拼接的是在元素的伪元素的 `content` 属性中。但是也不是利用 calc。

来看这样一个例子，这是**错误**的：

    :root {
        --stringA: '123';
        --stringB: '456';
        --stringC: '789';
    }
    
    div::before {
        content: calc(var(--stringA) + var(--stringB) + var(--stringC));
    }
    

此时，不需要 calc，直接使用自定义变量相加即可。

因此，**正确**的写法：

    :root {
        --stringA: '123';
        --stringB: '456';
        --stringC: '789';
    }
    div::before {
        content: var(--stringA) + var(--stringB) + var(--stringC);
    }
    

> `content: var(--stringA) + var(--stringB) + var(--stringC)` 中的加号可以省略。

此时，内容可以正常展示：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/5136c54169064aa689d574bfb3d0778d~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=171&h=40&s=3312&e=png&b=fcfcfc)

再强调一下，**calc 没有字符串拼接的能力**，如下的使用方式都是无法被识别的错误语法：

    .el::before {
      // 不支持字符串拼接
      content: calc("My " + "counter");
    }
    .el::before {
      // 更不支持字符串乘法
      content: calc("String Repeat 3 times" * 3);
    }
    

### Calc 实战演练：消除渐变锯齿

下面，再举个 calc 实际中用得比较多的场景。

在[小册第 2 讲](https://juejin.cn/book/7052964245259943948/section/7053291022368915488 "https://juejin.cn/book/7052964245259943948/section/7053291022368915488")对背景 `background` 的介绍中，讲到了利用渐变绘制出来的图形，容易产生锯齿。

看下面这样一种场景：

    div {
        width: 400px;
        height: 400px;
        background: radial-gradient(#9c27b0 0%, #9c27b0 47%, #ffeb3b 47%, #ffeb3b 100%);
    }
    

使用 `radial-gradient(#9c27b0 0%, #9c27b0 47%, #ffeb3b 47%, #ffeb3b 100%)` 生成的一个图形，从一种颜色直接到另外一种颜色，但是，仔细看看衔接处，会发现有非常明显的锯齿效果。

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7714c105824b4f4fb06aada57da6322c~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=415&h=411&s=6214&e=png&b=ffeb3b)

遇到此类问题的解决方案是：**在衔接处，适当留出一些渐变空间**。我们简单改造一下上述代码：

    div {
        width: 400px;
        height: 400px;
        background: radial-gradient(#9c27b0 0%, #9c27b0 47%, #ffeb3b 47.3%, #ffeb3b 100%);
    }
    

仔细看上面的代码，将从 47% 到 47% 的一个变化，改为了 从 47% 到 47.3%，这多出来的 0.3% 就是为了消除锯齿的。实际改变后的效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b064cf963a6145398215db306bab0142~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=413&h=412&s=10112&e=png&b=ffeb3b)

> 完整的代码你可以戳这里：[CodePen Demo -- Remove aliasing from gradients](https://codepen.io/Chokcoco/pen/wvPErBo "https://codepen.io/Chokcoco/pen/wvPErBo")

这里有一个问题，那就是在使用百分比的情况下，如果当整个元素非常之大的时候，`0.3%` 可能也会是一个非常大的绝对值，譬如，在 `2000px x 2000px` 的元素上，上面的圆形图形的衔接处可能就是这样的效果，我们放大了看看：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f95f3f6dc96145869330944e0af7a189~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1041&h=398&s=77904&e=png&b=ffffff)

所以，更好的写法，我们可以利用 `calc()`，改造成如下的代码，无论图形元素大小，恒定添加一个 `1px` 的过渡间隙：

    div {
      background: 
        radial-gradient(#9c27b0 0%, #9c27b0 47%, #ffeb3b calc(47% + 1px), #ffeb3b 100%);
    }
    

这样，无论图形大小，都能得到清晰的衔接处效果以消除锯齿，效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/298fb9f4adfa4fb7b575f8a44b1db948~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1254&h=483&s=88031&e=png&b=ffffff)

min()、max()、clamp() 比较函数
------------------------

min()、max()、clamp() 适合放在一起讲，因为它们的作用彼此之间有所关联。

*   max()：从一个逗号分隔的表达式列表中选择最大（正方向）的值作为属性的值。
*   min()：从一个逗号分隔的表达式列表中选择最小的值作为属性的值。
*   clamp()：把一个值限制在一个上限和下限之间，当这个值超过最小值和最大值的范围时，在最小值和最大值之间选择一个值使用。

由于在现实中，有非常多元素的属性不是一成不变的，而是会根据上下文、环境的变化而变化。

譬如这样一个布局：

    <div class="container"></div>
    

    .container {
        height: 100px;
        background: #000;
    }
    

效果如下，`.container` 块它会随着屏幕的增大而增大，始终占据整个屏幕：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ac6d05d50e7747f4802b6689515b2e25~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=109&s=500&e=png&b=010101)

对于一个响应式的项目，我们肯定不希望它的宽度会一直变大，而是当达到一定的阈值时，宽度从相对单位变成了绝对单位，这种情况就适用于 `min()`，简单改造下代码：

    .container {
        width: min(100%, 500px);
        height: 100px;
        background: #000;
    }
    

容器的宽度值会在 `width: 100%` 与 `width: 500px` 之间做选择，选取相对小的那个。

在屏幕宽度不足 500px 时候，也就表现为 `width: 100%`，反之，则表现为 `width: 500px`：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7373d3c184a14a718d3cc2eb7aa844d8~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=600&h=219&s=614393&e=gif&f=91&b=1f2122)

同理，在类似的场景，我们也可以使用 `max()` 从多个值中，选取相对更大的值。

### min()、max() 支持多个值的列表

min()、max() 支持多个值的列表，譬如 `width: max(1px, 2px, 3px, 50px)`。

当然，对于上述表达式 `width: max(1px, 2px, 3px, 50px)` 而言，其实它的结果就等于 `width: 50px`。

因此，对于 min()、max() 的具体使用而言，最多应该只包含一个具体的绝对单位。否则，像上述这种代码，虽然语法支持，但是任何情况下，计算值都是确定的，其实没有意义。

### 比较函数配合 calc() 一起使用

min()、max()、clamp() 都可以配合 calc 一起使用。

譬如：

    div {
        width: max(50vw, calc(300px + 10%));
    }
    

在这种情况下，calc 和相应包裹的括号可以省略，因此，上述代码又可以写成：

    div {
        width: max(50vw, 300px + 10%);
    }
    

### 基于 max、min 模拟 clamp

现在有这样一种场景，如果我们不仅需要限制最大值，同时也需要限制最小值，怎么办呢？

举个实际可能的场景案例：字体的大小，最小是 12px，随着屏幕的变大，逐渐变大，但是为了避免老人机现象（随着屏幕变大，无限制变大），我们还需要限制一个最大值 20px。

我们可以利用 vw 来实现给字体赋动态值，假设在移动端，设备宽度的 CSS 像素为 320px 时，页面的字体宽度最小为 12px，换算成 vw 即是 `320 / 100 = 3.2`，也就是 1vw 在屏幕宽度为 320px 时候，表现为 3.2px，12px 约等于 3.75 vw。

同时，我们需要限制最大字体值为 20px，对应的 CSS 如下：

    p {
        font-size: max(12px, min(3.75vw, 20px));
    }
    

看看效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6502bf0eaff84f00830303aad8891c81~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=740&h=245&s=1065952&e=gif&f=149&b=1d1f20)

通过 `max()`、`min()` 的配合使用，以及搭配一个相对单位 vw，我们成功地给字体设置了上下限，而在这个上下限之间实现了动态变化。

当然，上面核心的这一段 `max(12px, min(3.75vw, 20px))` 看上去有点绕，因此，CSS 推出了 `clamp()` 简化这个语法，下面两个写法是等价的：

    p {
        font-size: max(12px, min(3.75vw, 20px));
        // 等价于
        font-size: clamp(12px, 3.75vw, 20px);
    }
    

### clamp()

`clamp()` 函数的作用是把一个值限制在一个上限和下限之间，当这个值超过最小值和最大值的范围时，在最小值和最大值之间选择一个值使用。它接收三个参数：最小值、首选值、最大值。

有意思的是，`clamp(MIN, VAL, MAX)` 其实就是表示 `max(MIN, min(VAL, MAX))`。

### 实战演练：使用 vw 配合 clamp 实现响应式布局

我们继续上面的话题。

在之前，移动端的适配方面，使用更多的 rem 适配方案，可能会借助一些现成的库，类似于 flexible.js、hotcss.js 等库。rem 方案比较大的一个问题在于需要一段 JavaScript 响应视口变化，重设根元素的 `font-size`，并且，使用 rem 多少有点 hack 的感觉。

在现在，在移动端适配，我们更为推崇的是 vw 纯 CSS 方案，与 rem 方案类似，它的本质也是页面的等比例缩放。它的一个问题在于，如果仅仅使用 vw，随着屏幕的不断变大或者缩小，内容元素将会一直变大变小下去，这也导致了在大屏幕下，许多元素看着实在太大了！

因此，我们需要一种能够控制最大、最小阈值的方式，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1654f4ece4664e80bc17404ac160b9b3~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=2000&h=1196&s=240113&e=png&a=1&b=1c192c)

此时，clamp 就能非常好的派上用场，还是我们上述的例子，这一段代码 `font-size: clamp(12px, 3.75vw, 20px)`，就能将字体限制在 `12px - 20px` 的范围内。

**因此，对于移动端页面而言，所有涉及长度的单位，我们都可以使用 vw 进行设置。而诸如字体、内外边距、宽度等不应该完全等比例缩放的，采用** **`clamp()`** **控制最大最小阈值**。

因此，在今天，对于移动端页面，可以基于 vw 为主、配合 clamp() 为辅的方式，完成整个移动端布局的适配。它的优势在于：

*   **没有额外** **JavaScript** **代码的引入，纯** **CSS** **解决方案**；
*   **能够很好地控制边界阈值，合理地进行缩放展示，避免传统的老人机现象（部分场景下字体过大）**。

### 实战演练：反向响应式变化

还有一个技巧，利用 `clamp()` 配合负值，我们也可以反向操作，得到一种屏幕越大、字体越小的反向响应式效果：

    p {
        font-size: clamp(20px, -5vw + 96px, 60px);
    }
    

看看效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3dfe24f32b5248a5a1198568313f3639~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=1200&h=225&s=9538964&e=gif&f=237&b=1d1f20)

这个技巧挺有意思的，由于 `-5vw + 96px` 的计算值会随着屏幕的变小而增大，实现了一种反向的字体响应式变化。

sin()、cos()、tan() 三角函数
----------------------

三角函数是什么应该就不必多说了。在此之前，CSS 中是没有此类数学公式函数的。有了三角函数之后，我们可以轻松地实现一些之前比较麻烦的效果。

首先，我们来看看在 CSS 中，使用三角函数的使用方式：

    div {
      /* 设置元素的宽度为 sin(30deg) 的值 * /
      width : calc ( sin ( 30deg ) 100px);
    
      /* 设置元素的高度为 cos(45deg) 的值 * /
      height : calc ( cos ( 45deg ) 100%);
    
      /* 设置元素的透明度为 tan(60deg) 的值 */
      opacity: calc(tan(60deg));
    }
    

上述代码中，我们使用 calc() 函数进行了计算，然后通过 sin()、cos() 和 tan() 函数对计算结果进行了进一步的处理，从而实现了不同的效果。

需要注意的是，三角函数在 CSS3 中仅对弧度（radian）单位进行支持。如果想要在开发中使用三角函数，可以借助转换函数 deg() 和 rad() 将角度（degree）和弧度进行转换。

CSS3 的这些函数使得开发者可以更加方便处理一些复杂的数学问题，增强了 CSS 的表现力。

以正弦、余弦函数为例，其函数图形如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/db7684aa0c8c4e3cb26ebe2117d97f2a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=495&h=319&s=21367&e=png&a=1&b=090909)

我们通过一个简单的例子，还原三角函数的图形，以此来感受三角函数的作用。

首先，我们利用 div 实现一个黑色圆球：

    <div class='g-single'></div>
    

    .g-single {
        width: 20px;
        height: 20px;
        background: #000;
        border-radius: 50%;
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/a251580038b5448b867afda8431a6e53~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=73&h=68&s=1136&e=png&b=ffffff)

我们可以通过 `transfrom`，借助 CSS @Property 属性，来构造一个三角函数的使用场景：

    .g-single {
        width: 20px;
        height: 20px;
        background: #000;
        border-radius: 50%;
        animation: move 5s infinite ease-in-out;
        transform: translate(
            calc(var(--dis) - 40vw),calc(5 * sin(var(--angle)) * 1em)
        );
    }
    
    @keyframes move {
        0% {
            --dis: 0px;
            --angle: 0deg;
        }
        100% {
            --dis: 80vw;
            --angle: 1080deg;
        }
    }
    

上述的核心在于这一段代码 -- `transform: translate(calc(var(--dis) - 40vw), calc(5 * sin(var(--angle)) * 1em))`，内部使用了两个 CSS @Property 变量：

1.  x 轴方向是 `0px` 到 `80vw` 的水平位移动画；
2.  y 轴方向是 `5 * sin(0deg) * 1em` 到 `5 * sin(1080deg) * 1em` 的竖直动画。

通过动画，动态地修改这两个变量的值，我们就可以得到一个三角函数曲线动画图形：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/080a618c1ea94711b8a51d7cb0edd323~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=900&h=195&s=32071&e=gif&f=145&b=fdfcff)

如果我们设定多个一模一样的小球，同一个运动轨迹，设定不同的 `animation-delay`，效果会是怎么样呢？

    <ul class="g-multi">
      <li> </li>
      // ... 一共 80 个 li
      <li> </li>
    </ui>
    

    li {
        animation: move 5s infinite ease-in-out;
        transform: translate(
            calc(var(--dis) - 40vw),calc(5 * sin(var(--angle)) * 1em);
    }
    @for $i from 1 to $count {
        li:nth-child(#{$i}) {
            animation-delay: #{$i * 5 / $count * -1s};
        }
    }
    @keyframes move {
        0% {
            --dis: 0px;
            --angle: 0deg;
        }
        100% {
            --dis: 80vw;
            --angle: 1080deg;
        }
    }
    

这样，就得到了这么一个动画，非常类似三角函数动画的曲线：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/083d91c4d05b4410b7a8458c1192b446~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=900&h=195&s=911315&e=gif&f=151&b=fdfcff)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS Cos/Sin Math function](https://codepen.io/Chokcoco/pen/dyqggwK "https://codepen.io/Chokcoco/pen/dyqggwK")

如果我们把每个点大小调小，并调整动画的连贯性（时长），控制好每一个元素的 `animation-delay`，我们就可以基于这个技巧，得到一个有趣的波浪线 Loading 动画。

完整的代码如下：

    <ul class="g-multi">
      <li> </li>
      // ... 一共 200 个 li
      <li> </li>
    </ui>
    

    $count: 200;
    @property --angle {
      syntax: '<angle>';
      inherits: false;
      initial-value: 0deg;
    }
    @property --dis {
      syntax: '<length>';
      inherits: false;
      initial-value: 0px;
    }
    .g-multi {
        position: relative;
        width: 5px;
        height: 5px;
        animation: colorChange 10s infinite linear;
        
        li {
            position: absolute;
            inset: 0;
            background: #65b7f9;
            border-radius: 50%;
            animation: move 1.8s infinite ease-in-out;
            transform: translate(
                calc(var(--dis) - 40vw),
                calc(2 * sin(var(--angle)) * 1em)
            );
        }
        
        @for $i from 1 to $count {
            li:nth-child(#{$i}) {
                animation-delay: #{$i * 1 / $count * -.5s};
            }
        }
    }
    @keyframes move {
        0% {
            --dis: 0px;
            --angle: 0deg;
        }
        100% {
            --dis: 400px;
            --angle: 1080deg;
        }
    }
    @keyframes colorChange {
        100% {
            filter: hue-rotate(360deg);
        }
    }
    

这样，我们就得到了这样一个 Loading 动画效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ce27ec2d73d1436d8ec2b5f1e18b426a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=450&h=122&s=157564&e=gif&f=225&b=000000)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS Cos/Sin Math function Loading Animation](https://codepen.io/Chokcoco/pen/MWzvqNL?editors=1100 "https://codepen.io/Chokcoco/pen/MWzvqNL?editors=1100")

好，我们继续，在之前，我们想实现一个圆弧动画，如下所示，还是稍微有点点麻烦的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1e8bdd802acc4a0882d526ffe1d615df~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=200&h=190&s=31953&e=gif&f=178&b=fdfcfa)

有了三角函数之后，类似的动画，可以节省部分代码实现：

    <div></div>
    

    @property --angle {
      syntax: '<angle>';
      inherits: false;
      initial-value: 0deg;
    }
    
    .g-single {
        background: #000;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        animation: move 3s infinite linear;
        transform: translate(
            calc(sin(var(--angle)) * 10vmin),calc(cos(var(--angle)) * 10vmin)
        );
    }
    
    @keyframes move {
        0% {
            --angle: 0deg;
        }
        100% {
            --angle: 360deg;
        }
    }
    

核心就在于 `transform: translate(calc(sin(var(--angle)) * 10vmin), calc(cos(var(--angle)) * 10vmin));`，简化一下这段代码，表达式为：

*   `transform: translate(sinX, conX)`，其中 X 为角度变化。

如此，我们只需要动态设置 X 从 `0deg` 到 `360deg` 的变化即可，就可以得到一个圆形动画效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2297bd5c60ff42b5aed5b807b45e10f5~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=200&h=190&s=31953&e=gif&f=178&b=fdfcfa)

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS Cos/Sin Math function - arc animation](https://codepen.io/Chokcoco/pen/jOedxXJ "https://codepen.io/Chokcoco/pen/jOedxXJ")

### 实战演练：实现 Loading 动画

基于上面的讲解及技巧，我们再来尝试实现一个旋转的 Loading 动画，代码非常简单：

    <ul>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
    </ul>
    

    @property --angle {
      syntax: '<angle>';
      inherits: false;
      initial-value: 0deg;
    }
    ul {
        position: relative;
    }
    li {
        position: absolute;
        inset: 0;
        border-radius: 50%;
        animation: move 3s infinite ease-in-out;
        transform: translate(
            calc(sin(var(--angle)) * 60px),calc(cos(var(--angle)) * 60px)
        );
    }
    @for $i from 1 to 11 {
        li:nth-child(#{$i}) {
            animation-delay: #{ $i * -0.15 }s;
            background: #{hsl(100 + $i * 15, 80%, 60%)};
        }
    }
    @keyframes move {
        0% {
            --angle: 0deg;
        }
        100% {
            --angle: 360deg;
        }
    }
    

借助 SASS 完成了部分重复性代码，核心就是让小圆以不同的速率进行旋转动画，结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/f77e84dd625b47eab94d9561d6d8473d~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=177&h=154&s=283523&e=gif&f=178&b=fdfcff)

> 完整的代码，你可以戳这里：[CSS Cos/Sin Math function - Loading animation](https://codepen.io/Chokcoco/pen/PoyVyEL "https://codepen.io/Chokcoco/pen/PoyVyEL")

### 使用三角函数实现波浪线

那么，三角函数还有什么作用吗？

我们来尝试点新奇的，借助三角函数实现曲线（波浪线）。

对 `box-shadow` 足够了解的同学应该知道，`box-shadow` 是支持多重阴影的，借助这个特性，出现了很多单标签，借助 `box-shadow` 来绘图的案例。

借助**三角函数**以及`box-shadow` 是支持多重阴影的这两个特性，我们就可以利用它们来实现波浪线。

当然，可以还需要借助 SASS 简化手动书写的代码量。我们来看一个 Demo：

    <div></div>
    <div></div>
    <div></div>
    

    @function shadowSet($vx, $vy, $color) {
        $shadow: 0 0 0 0 $color;
    
        @for $i from 0 through 50 {
            $x: calc(2 * sin(#{$i * 15 * 1deg}) * #{$vy});
            $y: $i * $vy;
    
            $shadow: $shadow, #{$x} #{$y} 0 0 $color;
        }
    
        @return $shadow;
    }
    
    div {
        margin: auto;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #f00;
        box-shadow: shadowSet(3px, 3px, #f00);
    }
    div:nth-child(2) {
        width: 6px;
        height: 6px;
        background: #fc0;
        box-shadow: shadowSet(3px, 3px, #fc0);
    }
    div:nth-child(3) {
        width: 4px;
        height: 4px;
        background: #000;
        box-shadow: shadowSet(2px, 2px, #000);
    }
    

这样，我们就能得到 3 条波浪线：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/d095bdbc420247eba26ed63dadcb6791~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=302&h=186&s=7363&e=png&b=ffffff)

单独看其中一个，其实是这样一坨 `box-shadow` 代码：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/119d81fdcefa45e296cc5a36c0cc9eaf~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=784&h=460&s=208512&e=png&b=ffffff)

好吧，这个方法确实一定程度上弥补了之前 CSS 无法有效绘制波浪线的缺陷，但是，缺点也非常明显，编译后的代码量太多了！

> 完整的代码，你可以戳这里：[CSS Cos/Sin Math And box-shadow](https://codepen.io/Chokcoco/pen/oNPaayq "https://codepen.io/Chokcoco/pen/oNPaayq")

有了绘制曲线的能力，我们就能利用它在 CSS 中创造许多有美感、艺术性的效果。

我们可以尝试使用这些曲线，来制作书签图案：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/39cdd63313e74dcc8e90bc6d71466b71~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=605&h=392&s=148572&e=png&b=ffffff)

> 代码也不复杂，我就不贴完整的代码了，感兴趣的可以戳这里：[CodePen Demo - CSS Cos/Sin Math And box-shadow - bookmark](https://codepen.io/Chokcoco/pen/oNamQyr "https://codepen.io/Chokcoco/pen/oNamQyr")

总结一下
----

在本章节中，我们详述了 CSS 中，当前已经被兼容的几个非常强力的数学函数：

1.  `calc()` ：属于基础运算类的数学函数；
2.  `min()、max()、clamp()` ：比较函数，常作用于范围限定的场景；
3.  `sin()、cos()、tan()`： 三角函数类。

并且，深入理解了它们的一些特性及使用技巧。在今天，CSS 已经不再是纯粹的样式表现层，基于 CSS 的强大功能，已经开始能够利用这些数学函数，去实现一些过往一定是需要依靠 JavaScript 计算的逻辑。

掌握它们，能够有效帮助我们更好地提升效率，简化复杂逻辑。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。
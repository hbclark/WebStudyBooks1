CSS 自定义属性（CSS Custom properties），也有很多人喜欢称其为 CSS 变量，属于现代 CSS 中非常重要的一环。接下来两章，我们将详细学习 CSS 自定义属性的方方面面，一起感受它的强大。

对于 CSS 自定义属性（CSS 变量）相关的内容，我们的学习路径将会是：

1.  理解 CSS 变量最基础的内容，学会使用 CSS 变量，理解其设计理念，并且逐步掌握一些变量使用的高级技巧；
2.  基于 CSS 变量，学习 CSS @property，理解其对整体 CSS 功能（CSS 动画）带来的革命性提升，掌握多种实战技巧；
3.  最后，进阶学习 **CSS** **Houdini 之 CSS Paint** **API**，掌握强大的 CSS 绘图技巧。

而本文，我们将重点放在 1、2 两点之上，由浅及深，从 CSS 变量到 CSS @property。下一章讲解 **CSS** **Houdini 之 CSS Paint** **API**。

首先，我们来了解一下 CSS 自定义属性。

了解 CSS 自定义属性
------------

在 CSS 自定义属性相关规范推出之前，CSS 中是没有变量这种说法的，想要使用 CSS 变量，我们只能借助诸如 SASS 、LESS 这类 CSS 预处理库。

CSS 自定义属性的诞生，其核心作用是**对整个文档中重复使用、重复出现的 CSS 属性值，进行统一维护、管理，方便统一修改。**

### CSS 自定义属性的使用

首先，看个最简单的例子：

    :root{
      --bgColor: #000;
    }
    

这里出现了一个新的选择器 `:root{}`。`:root` 这个 CSS [伪类](https://developer.mozilla.org/zh-CN/docs/Web/CSS/Pseudo-classes "https://developer.mozilla.org/zh-CN/docs/Web/CSS/Pseudo-classes")匹配文档树的根元素。对于 HTML 来说，`:root` 表示 `<html>` 元素，它的优先级比 `<html>` 更高，其余方面与 `html` 选择器相同。

在使用 CSS 自定义属性的时候，我们习惯于将全局性的 CSS 自定义属性，定义在 `:root{}` 伪类中。因此，`:root{}` 中定义的自定义变量可以被全局的选择访问到。

定义完自定义属性后，则是具体使用：

    .main{
      background: var(--bgColor);
    }
    

CSS 自定义属性的使用方式非常简单，通过 `var(定义的变量名)` 来调用。步骤如下：

1.  使用双横杆 `--` 加上变量名，定义一个自定义属性，如 `--bgColor`；
2.  在需要使用的地方，通过 `var(定义的变量名)` 进行调用，如 `var(--bgColor)`。

这样，上述 `.main` 元素的背景色，就相当于 `background: #000`，也就是黑色。

### CSS 自定义属性的层叠与作用域

CSS 自定义属性是支持继承的，不过这里说成级联或者层叠应该更贴切。

我们可以把这里的继承理解为作用域，通俗一点就是局部变量会在作用范围内覆盖全局变量。

在 CSS 中，一个元素的实际属性是由其自身属性以及其祖先元素的属性层叠得到的，CSS 自定义属性也支持层叠的特性，当一个属性没有在当前元素内被定义，则会转而使用其祖先元素的属性。在当前元素定义的属性，将会覆盖祖先元素的同名属性。

来看这么一个例子：

    :root{
      --color: #00;
    }
    
    div {
      --color: #fff;
      color:var(--color);
    }
    

上面示例中最终生效的变量是 `--color: #fff`，可以将 div 内定义的 `--color` 理解为局部变量，而 `:root` 内定义的 `--color` 理解为全局变量。此时，局部变量的优先级更高。

通过这个例子，我们需要理解 CSS 自定义属性的作用范围，与 JavaScript 变量存在块级作用域类似，CSS 中，CSS 变量也是存在作用域的。

### CSS 自定义属性的默认值

CSS 自定义属性是可以设置默认值的。

来看这么一个例子：

    <ul>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>
    

    ul {
        display: flex;
        justify-content: space-between;
    }
    li {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: var(--bgColor, #000);
    }
    li:nth-child(1) {
        --bgColor: #f00;
    }
    li:nth-child(3) {
        --bgColor: #fc0;
    }
    li:nth-child(5) {
        --bgColor: #690;
    }
    

上述的 Demo 中，有 5 个圆形 div，我们统一设置了 `background-color: var(--bgColor, #000)`，意思是如果存在 `--bgColor` 变量，则使用这个变量的值作为背景色，否则，使用 `#000` 作为默认兜底值。

在下方，我们定义了序号 1、3、5 的 `li` 的 `--bgColor` 变量，因此，最终的效果是这样的：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2cc7791198f24b94b9a6d34e04cad8d6~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=347&h=86&s=3442&e=png&b=ffffff)

第 2、4 个，使用了 `var(--bgColor, #000)` 中的黑色作为默认兜底值。

### CSS 自定义属性与计算属性 calc( )

更有趣的是，CSS 自定义属性可以结合 CSS3 新增的函数 calc( ) 一起使用，考虑下面这个例子：

    <div> CSS Varialbe </div>
    

    :root{
      --margin: 10px;
    }
    
    div{
      text-indent: calc(var(--margin) * 10);
    }
    

上面的例子，CSS 变量配合 calc 函数，得到的最终结果是 `text-indent:100px` 。

> 完整的代码，你可以看这里：[CodePen Demo戳我 -- CSS 变量与 Calc 函数的组合](http://codepen.io/Chokcoco/pen/MbezbR "http://codepen.io/Chokcoco/pen/MbezbR")

### CSS 自定义属性的组合

那么，结合 `calc`，是否可以实现字符串的拼接呢？

看这么一个例子：

    <div style="--url: 'bsBD1I.png'"></div>
    

    :root {
        --urlA: 'url(https://s1.ax1x.com/2022/03/07/';
        --urlB: ')';
    }
    div {
        width: 400px;
        height: 400px;
        background-image: calc(var(--urlA) + var(--url) + var(--urlB));
    }
    

在上述的代码中，想利用 `calc(var(--urlA) + var(--url) + var(--urlB))` 拼出完整的在 `background-image` 中可使用的 URL `url(https://s1.ax1x.com/2022/03/07/bsBD1I.png)`。

遗憾的是，这在 CSS 中是不被允许的（无法实现的）。

**需要记住的一点：calc() 数学函数没有字符串拼接的能力。**

唯一可能完成字符串拼接的是在元素的伪元素的 `content` 属性中。但是也不是利用 `calc`。

来看这样一个例子，这是**错误**的：

    :root {
        --stringA: '123';
        --stringB: '456';
        --stringC: '789';
    }
    
    div::before {
        content: calc(var(--stringA) + var(--stringB) + var(--stringC));
    }
    

此时，不需要 calc，直接使用自定义变量相加即可。

因此，**正确**的写法如下：

    :root {
        --stringA: '123';
        --stringB: '456';
        --stringC: '789';
    }
    div::before {
        content: var(--stringA) + var(--stringB) + var(--stringC);
    }
    

甚至乎，`content: var(--stringA) + var(--stringB) + var(--stringC)` 中的加号都是可以省略的。

此时，效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7e299e6be4c04dcea0d03de197bade69~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=171&h=40&s=3312&e=png&b=fcfcfc)

再强调一下，**calc 的没有字符串拼接的能力**，如下的使用方式都是无法被识别的错误语法：

    .el::before {
      // 不支持字符串拼接
      content: calc("My " + "counter");
    }
    .el::before {
      // 更不支持字符串乘法
      content: calc("String Repeat 3 times" * 3);
    }
    

CSS 自定义属性的传值方式
--------------

了解完 CSS 自定义属性最基础的内容之后，我们再来看看 CSS 自定义属性的传值方式。

这一点我们在动画章节其实也有提到，快速复习一遍。我们有三种给 CSS 变量赋值（传递值）的方式：

1.  通过 CSS 代码进行 CSS 变量值的传递；
2.  通过元素的 style 属性进行 CSS 变量值的传递；
3.  通过 JavaScript 改写 style 属性进行 CSS 变量值的传递。

解释一下，假设，我们有这么一段代码：

    <div id="g-element"></div>
    

    #g-element {
        width: 100px;
        height: 100px;
        background: var(--bgColor);
    }
    

我们在 background 中使用了一个 CSS，`background: var(--bgColor)`，但是我们没有在 CSS 代码中定义 `--bgColor` 的值。

最简单的方式，就是在 CSS 代码中赋值，也就是第一种传值方式：**通过 CSS 代码进行 CSS 变量值的传递**。

    :root {
        --bgColor: #000;
    }
    
    // 或者
    #g-element {
        --bgColor: #000;
        width: 100px;
        height: 100px;
        background: var(--bgColor);
    }
    

其次，第二种传值方式：**通过元素的 style 属性进行** **CSS** **变量值的传递**。我们修改 HTML 元素的 style 属性：

    <div id="g-element" style="--bgColor: #000"></div>
    

最后，第三种传值方式：也可以**通过** **JavaScript** **改写 style 属性进行** **CSS** **变量值的传递**。

    const bgColor = '#000';
    
    document.querySelector('#g-element')
        .setAttribute('style', `--bgColor: ${bgColor}`);
    

掌握这三种定义、传递 CSS 自定义属性的值，就可以非常好地对它们进行更高效的利用。

强大的 CSS @property
-----------------

好，CSS 自定义属性铺垫完之后，接下来的 CSS @property，其实才是本文的核心。

大部分同学还是对 CSS 自定义属性有所了解并且使用过的，但是，只有很少一部同学能够灵活使用 CSS @property 变量。那么，什么是 CSS @property 呢？

### 初识 CSS @property

文档对其的描述是：CSS **@Property** at-rule 是 CSS Houdini API 的一部分，它允许开发者显式地定义他们的 CSS 自定义属性，允许进行属性类型检查、设定默认值以及定义该自定义属性是否可以被继承。

只看上面一段文档，大部分同学肯定是一脸懵的。

我们从一个例子快速上手，正常而言，定义 CSS 自定义属性的方法是这样的：

    :root {
        --whiteColor: #fff;
    }
    
    div {
        color: (--whiteColor);
    }
    

而有了 `CSS @property` 之后，我们还可以像下述代码这样定义一个 CSS 自定义属性（CSS 变量）：

    @property --property-name {
      syntax: '<color>';
      inherits: false;
      initial-value: #fff;
    }
    
    div {
        color: var(--property-name);
    }
    

简单解读下：

*   `@property --property-name` 中的 `--property-name` 就是自定义属性的名称，定义后可在 CSS 中通过 `var(--property-name)` 进行引用。

接下来，在 `@property` 规则中，像对象一样的，存在 3 属性，我们分别解读下：

*   syntax：该自定义属性的语法规则，也可以理解为表示定义的自定义属性的类型。
*   inherits：是否允许继承。
*   initial-value：初始值。

其中，`@property` 规则中的 syntax 和 inherits 描述符是必需的。

### 支持的 syntax 语法类型

在进入 CSS @property 实战环节之前，我们还有一些基础内容需要铺垫，这一段大家可以快速过掉。

上面提到，**syntax** 描述符是一个 `@property` 规则必需的。那么，syntax 有哪些可取值呢？

`syntax` 支持的语法类型非常丰富，基本涵盖了所有你能想到的类型。

*   length
*   number
*   percentage
*   length-percentage
*   color
*   image
*   url
*   integer
*   angle
*   time
*   resolution
*   transform-list
*   transform-function
*   custom-ident (a custom identifier string)

定义的 CSS `@property` 变量的 syntax 语法还接受一些特殊的类型定义。

*   `syntax: '<color#>'` ：接受逗号分隔的颜色值列表。
*   `syntax: '<length+>'` ：接受以空格分隔的长度值列表。
*   `syntax: '<length | length+>'`：接受单个长度或者以空格分隔的长度值列表。

这一块，对于初学者而言会有一点繁琐。通俗的来说，CSS 中属性的值有各种各样的取值，譬如：

    {
        width: 100%;
        height: 95px;
        color: #fff;
        border-radius: 10% 20% 30% 40%;
        background-image: url(image.png);
        transition-duration: 1s;
    }
    

上面这一段 CSS 代码，不同属性的不同取值，其实就对应了 CSS @property syntax 属性包含了的可取值：

*   `width: 100%` -- 其中 `100%` 对应 percentage。
*   `height: 95px` -- 其中 `95px` 对应 length。
*   `color: #fff` -- 其中 `#fff` 对应 color。
*   `border-radius: 10% 20% 30% 40%` -- 其中 `10% 20% 30% 40%` 对应的是 percentage，但是这里是多个百分比取值，所以可以利用 `+` 号规则，表示为 `percentage+`，接受以空格分隔的百分比值列表。

剩下的 `background-image`、`transition-duration` 也对应了不同的取值，不再赘述。

我们只需要理解，当我们要利用 CSS @property 自定义变量的时候，需要事先定义好它接下来的类型 syntax。

OK，铺垫了这么多，那么为什么要使用这么麻烦的语法定义 CSS 自定义属性呢？CSS Houdini 定义的自定义变量的优势在哪里？下面我们一一娓娓道来。

### CSS @Property 的优势

为什么要使用这么麻烦的语法定义 CSS 自定义属性呢？CSS Houdini 定义的自定义变量的优势在哪里？

我们来看这样一个例子，假设，我们有这样一个渐变的图案：

    <div></div>
    

    div {
        background: linear-gradient(45deg, #fff, #000);
    }
    

其效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/638b14aaa948436cbf42258c7fc24da2~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=209&h=211&s=7674&e=png&b=838383)

我们改造下上述代码，改为使用 CSS 自定义属性：

    :root {
        --colorA: #fff;
        --colorB: #000;
    }
    div {
        background: linear-gradient(45deg, var(--colorA), var(--colorB));
    }
    

> 注意，这里我们还没有使用到 CSS @property。

结果如下，上述代码得到的还是同一个渐变图案：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/bac1f8b056074f68b39a55a21af66d94~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=209&h=211&s=7674&e=png&b=838383)

我们尝试给上述效果，再加上一个过渡效果：

    :root {
        --colorA: #fff;
        --colorB: #000;
    }
    div {
        background: linear-gradient(45deg, var(--colorA), var(--colorB));
        transition: 1s background;
        
        &:hover {
            --colorA: yellowgreen;
            --colorB: deeppink;
        }
    }
    

根据我们的代码，我们希望当鼠标 Hover 的图形的时候，颜色会产生过渡效果，但是结果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e339896a7066436ea6768dda666ab335~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=280&s=438531&e=gif&f=88&b=eeeaee)

虽然我们设定了 1s 的过渡动画 `transition: 1s background`，但是很可惜，CSS 是不支持背景渐变色的直接过渡变化的，我们得到的只是两帧之间的直接变化。

### 使用 @Property 进行改造

OK，接下来就轮到 CSS @property 变量出场了，我们使用 CSS @Property 自定义属性替换原本的 CSS 自定义属性。

简单进行改造一下，这里，由于 CSS 变量代表的是颜色，我们需要使用 `color` syntax 语法类型：

    @property --houdini-colorA {
      syntax: '<color>';
      inherits: false;
      initial-value: #fff;
    }
    @property --houdini-colorB {
      syntax: '<color>';
      inherits: false;
      initial-value: #000;
    }
    .property {
        background: linear-gradient(45deg, var(--houdini-colorA), var(--houdini-colorB));
        transition: 
          1s --houdini-colorA, 
          1s --houdini-colorB;
        
        &:hover {
            --houdini-colorA: yellowgreen;
            --houdini-colorB: deeppink;
        }
    }
    

我们使用了 `@property` 语法，定义了两个 CSS Houdini 自定义变量 `--houdini-colorA` 和 `--houdini-colorB`，在 hover 变化的时候，改变这两个颜色。

需要关注的是，我们设定的过渡语句 `transition: 1s --houdini-colorA, 1s --houdini-colorB`，这里非常重要，上述代码**是针对** **CSS** **Houdini 自定义变量设定过渡，而不是针对** **`background`** **这个属性设定过渡动画。**

这一次，再来看看效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/c78201c49a564971b81211c3000da8d7~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=280&s=2974095&e=gif&f=135&b=f9f6f9)

神奇的事情发生了，渐变色的变化从生硬的切换效果，变成了补间动画，实现了从一个渐变色过渡到另外一个渐变色的效果！**而这，都得益于** **CSS** **Houdini 自定义变量的强大能力**！

> 完整的代码，你可以戳这里：[CodePen Demo -- CSS Houdini 自定义变量实现渐变色过渡动画](https://codepen.io/Chokcoco/pen/eYgyWLB?editors=1100 "https://codepen.io/Chokcoco/pen/eYgyWLB?editors=1100")

总结一下，**CSS @Property 规则的强大之处在于，在 CSS 中，有许多属性的变化，是不支持过渡变化，你可以理解为有很多属性是不支持动画效果的。但是，借助 CSS @Property 自定义属性，我们可以将原本定义在属性上的过渡（动画）效果嫁接到了针对单个的长度、颜色之上，而幸运的是，CSS 是支持单个颜色或者单个长度的变换的。这样，我们巧妙地实现了渐变背景色的过渡动画**。

这一点非常重要，在现在 CSS 动画中，CSS @property 存在相当规模的使用。

CSS @property 实战
----------------

掌握了上述的技巧，我们就可以利用 CSS @property 自定义属性的这个能力，去填补修复以前无法直接过渡动画的一些效果了。

### 文字下划线动画

首先，来看这么一个例子。

在过往，我们想实现这样一个文字下划线的 Hover 效果：

    p {
        text-underline-offset: 1px;
        text-decoration-line: underline;
        text-decoration-color: #000;
        transition: all .3s;
        
        &:hover {
            text-decoration-color: orange;
            text-underline-offset: 10px;
            color: orange;
        }
    }
    

因为 `text-underline-offset` 不支持过渡动画，因此，只能得到如下效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/626523b49f5a48ab916303f2ee52aab4~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=59&s=247943&e=gif&f=116&b=fdfafe)

接下来，使用 CSS @property 自定义属性进行改造：

    @property --offset {
      syntax: '<length>';
      inherits: false;
      initial-value: 0;
    }
    div {
        text-underline-offset: var(--offset, 1px);
            text-decoration: underline;
            transition: --offset 400ms, text-decoration-color 400ms;
        
        &:hover {
            --offset: 10px;
            color: orange;
            text-decoration-color: orange;
        }
    }
    

可以得到丝滑的过渡效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/83b378ccbaf6440d94a953bf9316f134~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=400&h=59&s=93126&e=gif&f=115&b=fefbff)

正如我们上面所说的，我们利用 CSS @property 自定义属性，将原本针对 `text-underline-offset` 属性的动画效果，转移到了针对单个长度属性 `--offset` 之上，从而实现了该交互效果。

> 完整的代码，你可以戳：[CodePen Demo - Underlines hover transition](https://codepen.io/Chokcoco/pen/jOymJZR "https://codepen.io/Chokcoco/pen/jOymJZR")

### Loading 线条动画

我们再来看一个非常具有代表性的例子。

在本小册中，我们其实已经多次说到了一点，那就是：正常而言，背景渐变是无法进行动画效果的。如下所示：

    <div></div>
    

    div {
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background: conic-gradient(
          yellowgreen, 
          yellowgreen 25%, 
          transparent 25%, 
          transparent 100%
        ); 
        transition: background 300ms;
    }
    div:hover {
        background: conic-gradient(
            yellowgreen,
            yellowgreen 60%,
            transparent 60.1%,
            transparent 100%
        ); 
    }
    

由于 `conic-gradient` 角向渐变是不支持过渡动画的，因此，我们会得到一帧向另外一帧的直接变化，而看不到动画效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/2d5d1caf7cd34768bbf8ae7d4fa37554~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=287&s=78854&e=gif&f=102&b=fffcff)

好，使用 CSS **@Property** 自定义变量改造一下，把针对于 `conic-gradient` 角向渐变的变换，转移到针对渐变色值百分比 `percentage` 之上：

    @property --per {
      syntax: '<percentage>';
      inherits: false;
      initial-value: 25%;
    }
    div {
        background: conic-gradient(
          yellowgreen, 
          yellowgreen var(--per), 
          transparent var(--per), 
          transparent 100%
        ); 
        transition: --per 300ms linear;
    }
    div:hover {
        --per: 60%;
    }
    

看看改造后的效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1bc7544580534682a8c244af5a2ed451~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=300&h=287&s=177011&e=gif&f=130&b=fffcff)

利用上述技巧，我们再引入 mask，将饼图的中间部分裁切掉，就可以得到一条弧线，代码如下：

    @property --per {
      syntax: '<percentage>';
      inherits: false;
      initial-value: 25%;
    }
    div {
        width: 100px;
        height: 100px;
        background: conic-gradient(
          yellowgreen, 
          yellowgreen var(--per), 
          transparent var(--per), 
          transparent 100%
        ); 
        mask: radial-gradient(transparent, transparent 46.5px, #000 47px, #000);
    }
    

利用 mask，把饼图中间镂空，得到一条弧线：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/6c9770de22a34c019f7ee831587ef992~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=154&h=85&s=1512&e=png&b=ffffff)

接下来，我们如果可以结合 animation，在 animation 中动态改变 `--per` 的值，我们就能得到一条伸缩的弧线。

最终，经过改造，我们就能够实现一条非常有意思的 Loading 弧线动画效果，完整的代码如下：

    <div></div>
    

    @property --per {
        syntax: "<percentage>";
        inherits: false;
        initial-value: 10%;
    }
    
    div {
        position: relative;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        animation: rotate 11s infinite ease-in-out;
    
        &::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 50%;
            background: conic-gradient(transparent, transparent var(--per), #fa7 var(--per), #fa7);
            mask: radial-gradient(transparent, transparent 46.5px, #000 47px, #000);
            animation: change 3s infinite cubic-bezier(0.57, 0.29, 0.49, 0.76);
        }
    }
    
    @keyframes change {
        50% {
            transform: rotate(270deg);
            --per: 98%;
        }
        100% {
            transform: rotate(720deg);
        }
    }
    
    @keyframes rotate {
        100% {
            transform: rotate(360deg);
            filter: hue-rotate(360deg);
        }
    }
    

这里，我顺便加上了 `filter: hue-rotate()`，让线条在旋转的同时，颜色也跟着变化，最终效果如下，这是一个纯 CSS 解决方案：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/3b5919ee83e84574b1aab91cd259b779~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=193&h=172&s=792649&e=gif&f=293&b=ffffff)

> 完整的代码你可以猛击这里：[Linear Loading Animation](https://codepen.io/Chokcoco/pen/vYVvjQd "https://codepen.io/Chokcoco/pen/vYVvjQd")

### 解决动画合成问题

在动画 animation 的章节，我们有讲到这么一种现象，下面快速复习一下。

利用 CSS 实现一个抛物线效果，像是这样：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/7c1e38eb904042a986996af9ed85f711~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=310&s=10991&e=gif&f=52&b=fdfcff)

拆解一下这个动画，它是由：

1.  一个水平向右的位移动画，速度为匀速；
2.  一个垂直向下的位移动画，速度为逐渐加速。

用 CSS 大致模拟：

    <div class="container">
        <div class="x"></div>
    </div> 
    <div class="container">
        <div class="y"></div>
    </div> 
    

    .container .x {
        animation: translateX 3s infinite linear;
    }
    .container .y {
        animation: translateY 3s infinite cubic-bezier(.55, 0, .9, .4);
    }
    
    @keyframes translateX {
        0%,
        20% {
            transform: translateX(0);
        }
        80%,
        100% {
            transform: translateX(280px);
        }
    }
    
    @keyframes translateY {
        0%,
        20% {
            transform: translateY(0);
        }
        80%,
        100% {
            transform: translateY(280px);
        }
    }
    

效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/effc45bbe50242d4a4168302f450bfc6~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=750&h=337&s=43890&e=gif&f=79&b=fdfcf9)

好，接下来，尝试把两个动画合在一个元素上：

    <div></div>
    

    div {
        animation: 
            translateX 3s infinite linear,
            translateY 3s infinite cubic-bezier(.55, 0, .9, .4);
    }
    

预想中的抛物线动画，并没有出现，只有单个的向下动画：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/dfa2b56d305a4885a11baf9221915234~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=320&h=341&s=27775&e=gif&f=84&b=fdfcff)

究其原因，在于后定义的 `translateY 3s infinite cubic-bezier(.55, 0, .9, .4)` 的垂直方向的动画效果 `transform: translateY(280px)` 的效果覆盖了在之前定义的 `transform: translateX(280px)` 动画效果。

我们想得到一个抛物线动画，除了使用动画章节中的 `animation-composition` 进行动画合成设定之外，也可以使用 CSS @property 自定义属性进行改造，一样可以在单个标签内实现抛物线效果。

代码如下：

    <div></div>
    

    @property --x {
      syntax: '<length>';
      inherits: false;
      initial-value: 0;
    }
    @property --y {
      syntax: '<length>';
      inherits: false;
      initial-value: 0;
    }
    .container div {
        width: 20px;
        height: 20px;
        background: #000;
        border-radius: 50%;
        transform: translate(var(--x), var(--y));
        animation: 
            translateX 3s infinite linear,
            translateY 3s infinite cubic-bezier(.55, 0, .9, .4);
    }
    @keyframes translateX {
        0%,
        20% {
            --x: 0;
        }
        80%,
        100% {
            --x: 280px;
        }
    }
    @keyframes translateY {
        0%,
        20% {
            --y: 0;
        }
        80%,
        100% {
            --y: 280px;
        }
    }
    

这里的核心在于，我们将原本赋予给 `transform` 的动画效果，转移给了 `--x` 和 `--y` 两个变量，就没有所谓的覆盖问题。这样，我们也可以得到一个完美的抛物线效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/e6472973f3e24f50a364ffb8f7958a74~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=296&h=322&s=43012&e=gif&f=42&b=ffffff)

> 完整的代码，你可以戳这里：[CodePen Demo -- 使用 CSS @property 实现抛物线 DEMO](https://codepen.io/Chokcoco/pen/RweOooL "https://codepen.io/Chokcoco/pen/RweOooL")

### 实现复杂动画效果

最后，我们再来看一个借助 CSS @property 实现的超复杂动画场景。

我们最终希望实现这么一个图片 Hover 效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/1a05bafa67a94dbcaa641a1c79f62f94~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=362&h=322&s=700763&e=gif&f=94&b=e9e3db)

要实现这么一个效果，有两个需要解决的技术点：

1.  我们需要将一张图片切割成多个小块；
2.  基于（1），分别控制这些每个小块的独立隐藏和展示。

首先，如果整个图片只是一个小块，借助我们前面学习的 mask，以及本文的 CSS @property 变量，这个问题是非常容易解决的，看看代码：

    @property percentage {
       syntax: "<number>";
       initial-value: 1;
       inherits: false;
    }
    div {
        width: 300px;
        height: 300px;
        background: url(image.jpg);
        mask: linear-gradient(90deg, rgba(0, 0, 0, var(--percentage)), rgba(0, 0, 0, var(--percentage)));
        transition: --m-0 0.5s;
    }
    div:hover {
        --percentage: 0;
    }
    

这里，也有个核心技术点，我们解读一下：

mask 的是从 `mask: linear-gradient(rgba(0, 0, 0, 1), rgba(0, 0, 0, 1))` 向 `mask: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0))`，但是直接的 mask 变化是没有动画效果的，所以我们需要借助 CSS @property，将 mask 遮罩图形的百分比，通过 `--percentage` 进行控制，以实现动画的效果。

这样我们最终就可以得到这么一个动画效果：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/ae7a98b3f4e74678a158a3b9dc351867~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=334&h=308&s=2258760&e=gif&f=50&b=e7dedb)

有了这一步的铺垫后，后面的步骤理解起来就容易了很多。

继续复习一下 mask 的特性，mask 拥有和 background 一样的语法及特性。因此，mask 是可以设置多重 mask 的。也就是说，我们可以设置多个不同的 mask 遮罩效果给同一个元素。

因此，上面的效果只有一层 mask，尝试添加部分代码，让它变成 2 层 mask 效果：

    @property --m-0 {
       syntax: "<number>";
       initial-value: 1;
       inherits: false;
    }
    @property --m-1 {
       syntax: "<number>";
       initial-value: 1;
       inherits: false;
    }
    div {
        mask: 
            linear-gradient(90deg, rgba(0, 0, 0, var(--m-0)), rgba(0, 0, 0, var(--m-0))),linear-gradient(90deg, rgba(0, 0, 0, var(--m-1)), rgba(0, 0, 0, var(--m-1)));
        mask-size: 50% 100%;
        mask-position: left, right;
        mask-repeat: no-repeat;
        transition: 
            --m-0 0.3s,--m-1 0.25s 0.15s;
    }
    div:hover {
        --m-0: 0;
        --m-1: 0;
    }
    

这样，我们的步骤大概是：

1.  首先将 mask 一分为二，左右两边各一个；
2.  然后，设置了两个基于 CSS **@Property** 的变量，`--m-0` 和 `--m-0`；
3.  然后，给它们设置了不同的过渡时间和过渡延迟时间；
4.  在 hover 的一瞬间，再将这两个变量的值，都置为 0，也就是实现 `linear-gradient(90deg, rgba(0, 0, 0, 1), rgba(0, 0, 0, 1))` 到 `linear-gradient(90deg, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0))` 的变化，用于隐藏对应 mask 块；
5.  由于设置了不同的过渡时间和延迟时间，整体上看上去，整个动画就分成了两部分。

这样，整个效果就从图片的单块变化，变化到了两块的变化：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/369c8a5bcb2149c688574b07faeb089f~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=334&h=308&s=1117771&e=gif&f=38&b=e8e0dd)

依此类推，我们就可以到图片的 4、8、16 等等块数的变化效果。

当然，如果将图片切割到了 100、200 块，我们还是手写上述代码，那工作量可太大了，因此，我们需要借助 CSS 预处理器简化我们的代码。

这样，核心利用预处理器加上 CSS mask、加上 CSS @property，我们可以得到下面的代码：

    $count: 400;
    $sqrt: 20;
    $per: 100% / $sqrt;
    $width: 300px;
    $perWid: 15;
    
    @for $i from 1 to ($count + 1) {
        @property --m-#{$i} {
           syntax: "<number>";
           initial-value: 1;
           inherits: false;
        }
    }
    @function bgSet($n) {
        $bg : radial-gradient(rgba(0, 0, 0, var(--m-1)), rgba(0, 0, 0, var(--m-1)));
        
        @for $i from 2 through $n {         
            $bg: $bg, radial-gradient(rgba(0, 0, 0, var(--m-#{$i})), rgba(0, 0, 0, var(--m-#{$i})));
        }
        
        @return $bg;
    }
    @function positionSet($n) {
        $bgPosition: ();
    
        @for $i from 0 through ($n) {   
            @for $j from 0 through ($n - 1) {  
                $bgPosition: $bgPosition, #{$i * $perWid}px #{$j * $perWid}px;
            }
        }
        
        @return $bgPosition;
    }
    @function transitionSet($n) {
        $transition: --m-1 0.1s 0.1s;
    
        @for $i from 1 through $n {   
            $transition: $transition, --m-#{$i} #{random(500)}ms #{random(500)}ms;
        }
        
        @return $transition;
    }
    div {
        width: $width;
        height: $width;
        background: url(image.jpg);
        mask: bgSet($count);
        mask-size: $per $per;
        mask-repeat: no-repeat;
        mask-position: positionSet($sqrt); 
        transition: transitionSet($count);
    }
    div:hover {
        @for $i from 1 through $count {         
            --m-#{$i}: 0;
        }
    }
    

这里，我们解释一下上述代码，上述代码最终实现了一个将图片分割为 400 小块的例子。

1.  最上面的 CSS 预处理器 SCSS 变量定义中，每一个的含义如下：
    
    *   `$count` 是我们最终生成的块数；
    *   `$sqrt` 是每行以及每列会拥有的块数；
    *   `$per` 是每一块占整体图片元素的百分比值；
    *   `$width` 是整个图片的宽高值；
    *   `$perWid` 是每一块的宽高值。
2.  最上面的一段循环函数，批量生成 CSS **@property** 变量，从 `--m-0` 到 `--m-400`，共 400 个。
    
3.  `@function bgSet($n) {}` 是生成 400 块 mask 片段。
    
4.  `@function positionSet($n)` 是生成 400 块 mask 的 mask-position，也就是生成 400 段不同定位，让 400 块 mask 刚好覆盖整个图片。
    
5.  `@function transitionSet($n) {}` 是随机设置每个块的动画时间和延迟时间。
    
6.  代码最下面，还有一段循环函数，生成 400 个 CSS **@property** 变量的 hover 值，当 hover 的时候，全部变成 0。
    

这样，我们就实现了图片 400 分块的渐隐效果。最终效果如下：

![](https://p3-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/144c045fd61b4b7da3c4b3a443c8b42a~tplv-k3u1fbpfcp-jj-mark:1600:0:0:0:q75.image#?w=378&h=308&s=1471937&e=gif&f=92&b=f0e9e8)

> 完整的代码，你可以戳这里：[CodePen Demo -- 基于 @property 和 mask 的图片渐隐消失术](https://codepen.io/Chokcoco/pen/MWXEVEz "https://codepen.io/Chokcoco/pen/MWXEVEz")

这里，我们借助了 CSS @property 的特性，实现了一个超复杂的 CSS 交互 Hover 效果。这是一个原本看上去需要非常多 div 才能实现或者是需要借助 Canvas 才能实现的效果。

总结：CSS 自定义属性的作用及意义
------------------

好，总结一下。

从 CSS 变量到 CSS @property，它们的核心在于“**变量**”二字。提供了过往 CSS 中没有的变量抽象功能。其优势主要有这么几点：

**1\. 代码更加符合 DRY（Don‘t repeat yourself）原则，精简代码，减少冗余。**

通用属性的抽象提取，一是可以用于相同单个属性值重复出现的统一定义，更是可以用于譬如制作黑夜/白天模式此类需要统一修改大量相同属性值的场景。

**2\. CSS @property 解决了大量过往无法实现动画/过渡的交互场景。**

在 CSS 中，有许多属性的变化，是不支持过渡变化，你可以理解为有很多属性是不支持动画效果的。但是，借助 CSS @Property 自定义属性，我们可以将原本定义在属性上的过渡（动画）效果嫁接到了针对单个的长度、颜色之上。

**3\. 方便地从** **JS** **中读/写，统一修改，增强了** **JavaScript** **与** **CSS** **的联系。**

CSS 变量的出现，让 JavaScript 和 CSS 的联系更加紧密，修改一个属性的值不再变得那么麻烦。

到今天，其实强大的 CSS 已经能够支撑我们去做越来越多更有意思的动效。我们需要基于对它们的理解与掌握之上，去挖掘更多有意思的场景。

当然，CSS 变量到这里其实还没结束，在下一章，我们将继续介绍一种更为强大的 CSS 变量——**CSS Paint** **API**。它的出现，让 CSS 甚至有了媲美 Canvas 绘图的能力。

好的，本章节到此结束，大伙还有什么疑问，可以在评论区一起讨论。